import {randomBytes, createHash} from "crypto";
import http from "http";
import https from "https";
import zlib from "zlib";
import Stream, {PassThrough, pipeline} from "stream";
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
function getAugmentedNamespace(n) {
  if (n.__esModule)
    return n;
  var a = Object.defineProperty({}, "__esModule", {value: true});
  Object.keys(n).forEach(function(k) {
    var d = Object.getOwnPropertyDescriptor(n, k);
    Object.defineProperty(a, k, d.get ? d : {
      enumerable: true,
      get: function() {
        return n[k];
      }
    });
  });
  return a;
}
function createCommonjsModule(fn) {
  var module = {exports: {}};
  return fn(module, module.exports), module.exports;
}
var shams = function hasSymbols() {
  if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") {
    return false;
  }
  if (typeof Symbol.iterator === "symbol") {
    return true;
  }
  var obj = {};
  var sym = Symbol("test");
  var symObj = Object(sym);
  if (typeof sym === "string") {
    return false;
  }
  if (Object.prototype.toString.call(sym) !== "[object Symbol]") {
    return false;
  }
  if (Object.prototype.toString.call(symObj) !== "[object Symbol]") {
    return false;
  }
  var symVal = 42;
  obj[sym] = symVal;
  for (sym in obj) {
    return false;
  }
  if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) {
    return false;
  }
  if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) {
    return false;
  }
  var syms = Object.getOwnPropertySymbols(obj);
  if (syms.length !== 1 || syms[0] !== sym) {
    return false;
  }
  if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) {
    return false;
  }
  if (typeof Object.getOwnPropertyDescriptor === "function") {
    var descriptor = Object.getOwnPropertyDescriptor(obj, sym);
    if (descriptor.value !== symVal || descriptor.enumerable !== true) {
      return false;
    }
  }
  return true;
};
var origSymbol = typeof Symbol !== "undefined" && Symbol;
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_hasSymbols = function hasNativeSymbols() {
  if (typeof origSymbol !== "function") {
    return false;
  }
  if (typeof Symbol !== "function") {
    return false;
  }
  if (typeof origSymbol("foo") !== "symbol") {
    return false;
  }
  if (typeof Symbol("bar") !== "symbol") {
    return false;
  }
  return shams();
};
var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
var slice$1 = Array.prototype.slice;
var toStr$a = Object.prototype.toString;
var funcType = "[object Function]";
var implementation$2 = function bind(that) {
  var target = this;
  if (typeof target !== "function" || toStr$a.call(target) !== funcType) {
    throw new TypeError(ERROR_MESSAGE + target);
  }
  var args = slice$1.call(arguments, 1);
  var bound2;
  var binder = function() {
    if (this instanceof bound2) {
      var result = target.apply(this, args.concat(slice$1.call(arguments)));
      if (Object(result) === result) {
        return result;
      }
      return this;
    } else {
      return target.apply(that, args.concat(slice$1.call(arguments)));
    }
  };
  var boundLength = Math.max(0, target.length - args.length);
  var boundArgs = [];
  for (var i = 0; i < boundLength; i++) {
    boundArgs.push("$" + i);
  }
  bound2 = Function("binder", "return function (" + boundArgs.join(",") + "){ return binder.apply(this,arguments); }")(binder);
  if (target.prototype) {
    var Empty = function Empty2() {
    };
    Empty.prototype = target.prototype;
    bound2.prototype = new Empty();
    Empty.prototype = null;
  }
  return bound2;
};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_functionBind = Function.prototype.bind || implementation$2;
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_functionBind.call(Function.call, Object.prototype.hasOwnProperty);
var undefined$1;
var $SyntaxError$1 = SyntaxError;
var $Function = Function;
var $TypeError$f = TypeError;
var getEvalledConstructor = function(expressionSyntax) {
  try {
    return $Function('"use strict"; return (' + expressionSyntax + ").constructor;")();
  } catch (e) {
  }
};
var $gOPD$1 = Object.getOwnPropertyDescriptor;
if ($gOPD$1) {
  try {
    $gOPD$1({}, "");
  } catch (e) {
    $gOPD$1 = null;
  }
}
var throwTypeError = function() {
  throw new $TypeError$f();
};
var ThrowTypeError = $gOPD$1 ? function() {
  try {
    arguments.callee;
    return throwTypeError;
  } catch (calleeThrows) {
    try {
      return $gOPD$1(arguments, "callee").get;
    } catch (gOPDthrows) {
      return throwTypeError;
    }
  }
}() : throwTypeError;
var hasSymbols$5 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_hasSymbols();
var getProto$1 = Object.getPrototypeOf || function(x) {
  return x.__proto__;
};
var needsEval = {};
var TypedArray = typeof Uint8Array === "undefined" ? undefined$1 : getProto$1(Uint8Array);
var INTRINSICS = {
  "%AggregateError%": typeof AggregateError === "undefined" ? undefined$1 : AggregateError,
  "%Array%": Array,
  "%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined$1 : ArrayBuffer,
  "%ArrayIteratorPrototype%": hasSymbols$5 ? getProto$1([][Symbol.iterator]()) : undefined$1,
  "%AsyncFromSyncIteratorPrototype%": undefined$1,
  "%AsyncFunction%": needsEval,
  "%AsyncGenerator%": needsEval,
  "%AsyncGeneratorFunction%": needsEval,
  "%AsyncIteratorPrototype%": needsEval,
  "%Atomics%": typeof Atomics === "undefined" ? undefined$1 : Atomics,
  "%BigInt%": typeof BigInt === "undefined" ? undefined$1 : BigInt,
  "%Boolean%": Boolean,
  "%DataView%": typeof DataView === "undefined" ? undefined$1 : DataView,
  "%Date%": Date,
  "%decodeURI%": decodeURI,
  "%decodeURIComponent%": decodeURIComponent,
  "%encodeURI%": encodeURI,
  "%encodeURIComponent%": encodeURIComponent,
  "%Error%": Error,
  "%eval%": eval,
  "%EvalError%": EvalError,
  "%Float32Array%": typeof Float32Array === "undefined" ? undefined$1 : Float32Array,
  "%Float64Array%": typeof Float64Array === "undefined" ? undefined$1 : Float64Array,
  "%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined$1 : FinalizationRegistry,
  "%Function%": $Function,
  "%GeneratorFunction%": needsEval,
  "%Int8Array%": typeof Int8Array === "undefined" ? undefined$1 : Int8Array,
  "%Int16Array%": typeof Int16Array === "undefined" ? undefined$1 : Int16Array,
  "%Int32Array%": typeof Int32Array === "undefined" ? undefined$1 : Int32Array,
  "%isFinite%": isFinite,
  "%isNaN%": isNaN,
  "%IteratorPrototype%": hasSymbols$5 ? getProto$1(getProto$1([][Symbol.iterator]())) : undefined$1,
  "%JSON%": typeof JSON === "object" ? JSON : undefined$1,
  "%Map%": typeof Map === "undefined" ? undefined$1 : Map,
  "%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols$5 ? undefined$1 : getProto$1(new Map()[Symbol.iterator]()),
  "%Math%": Math,
  "%Number%": Number,
  "%Object%": Object,
  "%parseFloat%": parseFloat,
  "%parseInt%": parseInt,
  "%Promise%": typeof Promise === "undefined" ? undefined$1 : Promise,
  "%Proxy%": typeof Proxy === "undefined" ? undefined$1 : Proxy,
  "%RangeError%": RangeError,
  "%ReferenceError%": ReferenceError,
  "%Reflect%": typeof Reflect === "undefined" ? undefined$1 : Reflect,
  "%RegExp%": RegExp,
  "%Set%": typeof Set === "undefined" ? undefined$1 : Set,
  "%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols$5 ? undefined$1 : getProto$1(new Set()[Symbol.iterator]()),
  "%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined$1 : SharedArrayBuffer,
  "%String%": String,
  "%StringIteratorPrototype%": hasSymbols$5 ? getProto$1(""[Symbol.iterator]()) : undefined$1,
  "%Symbol%": hasSymbols$5 ? Symbol : undefined$1,
  "%SyntaxError%": $SyntaxError$1,
  "%ThrowTypeError%": ThrowTypeError,
  "%TypedArray%": TypedArray,
  "%TypeError%": $TypeError$f,
  "%Uint8Array%": typeof Uint8Array === "undefined" ? undefined$1 : Uint8Array,
  "%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined$1 : Uint8ClampedArray,
  "%Uint16Array%": typeof Uint16Array === "undefined" ? undefined$1 : Uint16Array,
  "%Uint32Array%": typeof Uint32Array === "undefined" ? undefined$1 : Uint32Array,
  "%URIError%": URIError,
  "%WeakMap%": typeof WeakMap === "undefined" ? undefined$1 : WeakMap,
  "%WeakRef%": typeof WeakRef === "undefined" ? undefined$1 : WeakRef,
  "%WeakSet%": typeof WeakSet === "undefined" ? undefined$1 : WeakSet
};
var doEval = function doEval2(name2) {
  var value;
  if (name2 === "%AsyncFunction%") {
    value = getEvalledConstructor("async function () {}");
  } else if (name2 === "%GeneratorFunction%") {
    value = getEvalledConstructor("function* () {}");
  } else if (name2 === "%AsyncGeneratorFunction%") {
    value = getEvalledConstructor("async function* () {}");
  } else if (name2 === "%AsyncGenerator%") {
    var fn = doEval2("%AsyncGeneratorFunction%");
    if (fn) {
      value = fn.prototype;
    }
  } else if (name2 === "%AsyncIteratorPrototype%") {
    var gen = doEval2("%AsyncGenerator%");
    if (gen) {
      value = getProto$1(gen.prototype);
    }
  }
  INTRINSICS[name2] = value;
  return value;
};
var LEGACY_ALIASES = {
  "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
  "%ArrayPrototype%": ["Array", "prototype"],
  "%ArrayProto_entries%": ["Array", "prototype", "entries"],
  "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
  "%ArrayProto_keys%": ["Array", "prototype", "keys"],
  "%ArrayProto_values%": ["Array", "prototype", "values"],
  "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
  "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
  "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
  "%BooleanPrototype%": ["Boolean", "prototype"],
  "%DataViewPrototype%": ["DataView", "prototype"],
  "%DatePrototype%": ["Date", "prototype"],
  "%ErrorPrototype%": ["Error", "prototype"],
  "%EvalErrorPrototype%": ["EvalError", "prototype"],
  "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
  "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
  "%FunctionPrototype%": ["Function", "prototype"],
  "%Generator%": ["GeneratorFunction", "prototype"],
  "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
  "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
  "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
  "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
  "%JSONParse%": ["JSON", "parse"],
  "%JSONStringify%": ["JSON", "stringify"],
  "%MapPrototype%": ["Map", "prototype"],
  "%NumberPrototype%": ["Number", "prototype"],
  "%ObjectPrototype%": ["Object", "prototype"],
  "%ObjProto_toString%": ["Object", "prototype", "toString"],
  "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
  "%PromisePrototype%": ["Promise", "prototype"],
  "%PromiseProto_then%": ["Promise", "prototype", "then"],
  "%Promise_all%": ["Promise", "all"],
  "%Promise_reject%": ["Promise", "reject"],
  "%Promise_resolve%": ["Promise", "resolve"],
  "%RangeErrorPrototype%": ["RangeError", "prototype"],
  "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
  "%RegExpPrototype%": ["RegExp", "prototype"],
  "%SetPrototype%": ["Set", "prototype"],
  "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
  "%StringPrototype%": ["String", "prototype"],
  "%SymbolPrototype%": ["Symbol", "prototype"],
  "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
  "%TypedArrayPrototype%": ["TypedArray", "prototype"],
  "%TypeErrorPrototype%": ["TypeError", "prototype"],
  "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
  "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
  "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
  "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
  "%URIErrorPrototype%": ["URIError", "prototype"],
  "%WeakMapPrototype%": ["WeakMap", "prototype"],
  "%WeakSetPrototype%": ["WeakSet", "prototype"]
};
var $concat = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_functionBind.call(Function.call, Array.prototype.concat);
var $spliceApply = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_functionBind.call(Function.apply, Array.prototype.splice);
var $replace$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_functionBind.call(Function.call, String.prototype.replace);
var $strSlice$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_functionBind.call(Function.call, String.prototype.slice);
var rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
var reEscapeChar = /\\(\\)?/g;
var stringToPath = function stringToPath2(string) {
  var first = $strSlice$1(string, 0, 1);
  var last = $strSlice$1(string, -1);
  if (first === "%" && last !== "%") {
    throw new $SyntaxError$1("invalid intrinsic syntax, expected closing `%`");
  } else if (last === "%" && first !== "%") {
    throw new $SyntaxError$1("invalid intrinsic syntax, expected opening `%`");
  }
  var result = [];
  $replace$1(string, rePropName, function(match2, number, quote2, subString) {
    result[result.length] = quote2 ? $replace$1(subString, reEscapeChar, "$1") : number || match2;
  });
  return result;
};
var getBaseIntrinsic = function getBaseIntrinsic2(name2, allowMissing) {
  var intrinsicName = name2;
  var alias;
  if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(LEGACY_ALIASES, intrinsicName)) {
    alias = LEGACY_ALIASES[intrinsicName];
    intrinsicName = "%" + alias[0] + "%";
  }
  if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(INTRINSICS, intrinsicName)) {
    var value = INTRINSICS[intrinsicName];
    if (value === needsEval) {
      value = doEval(intrinsicName);
    }
    if (typeof value === "undefined" && !allowMissing) {
      throw new $TypeError$f("intrinsic " + name2 + " exists, but is not available. Please file an issue!");
    }
    return {
      alias,
      name: intrinsicName,
      value
    };
  }
  throw new $SyntaxError$1("intrinsic " + name2 + " does not exist!");
};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic = function GetIntrinsic(name2, allowMissing) {
  if (typeof name2 !== "string" || name2.length === 0) {
    throw new $TypeError$f("intrinsic name must be a non-empty string");
  }
  if (arguments.length > 1 && typeof allowMissing !== "boolean") {
    throw new $TypeError$f('"allowMissing" argument must be a boolean');
  }
  var parts = stringToPath(name2);
  var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
  var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
  var intrinsicRealName = intrinsic.name;
  var value = intrinsic.value;
  var skipFurtherCaching = false;
  var alias = intrinsic.alias;
  if (alias) {
    intrinsicBaseName = alias[0];
    $spliceApply(parts, $concat([0, 1], alias));
  }
  for (var i = 1, isOwn = true; i < parts.length; i += 1) {
    var part = parts[i];
    var first = $strSlice$1(part, 0, 1);
    var last = $strSlice$1(part, -1);
    if ((first === '"' || first === "'" || first === "`" || (last === '"' || last === "'" || last === "`")) && first !== last) {
      throw new $SyntaxError$1("property names with quotes must have matching quotes");
    }
    if (part === "constructor" || !isOwn) {
      skipFurtherCaching = true;
    }
    intrinsicBaseName += "." + part;
    intrinsicRealName = "%" + intrinsicBaseName + "%";
    if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(INTRINSICS, intrinsicRealName)) {
      value = INTRINSICS[intrinsicRealName];
    } else if (value != null) {
      if (!(part in value)) {
        if (!allowMissing) {
          throw new $TypeError$f("base intrinsic for " + name2 + " exists, but the property is not available.");
        }
        return void 0;
      }
      if ($gOPD$1 && i + 1 >= parts.length) {
        var desc = $gOPD$1(value, part);
        isOwn = !!desc;
        if (isOwn && "get" in desc && !("originalValue" in desc.get)) {
          value = desc.get;
        } else {
          value = value[part];
        }
      } else {
        isOwn = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(value, part);
        value = value[part];
      }
      if (isOwn && !skipFurtherCaching) {
        INTRINSICS[intrinsicRealName] = value;
      }
    }
  }
  return value;
};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_callBind = createCommonjsModule(function(module) {
  var $apply2 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Function.prototype.apply%");
  var $call = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Function.prototype.call%");
  var $reflectApply = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Reflect.apply%", true) || C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_functionBind.call($call, $apply2);
  var $gOPD2 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Object.getOwnPropertyDescriptor%", true);
  var $defineProperty2 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Object.defineProperty%", true);
  var $max = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Math.max%");
  if ($defineProperty2) {
    try {
      $defineProperty2({}, "a", {value: 1});
    } catch (e) {
      $defineProperty2 = null;
    }
  }
  module.exports = function callBind(originalFunction) {
    var func = $reflectApply(C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_functionBind, $call, arguments);
    if ($gOPD2 && $defineProperty2) {
      var desc = $gOPD2(func, "length");
      if (desc.configurable) {
        $defineProperty2(func, "length", {value: 1 + $max(0, originalFunction.length - (arguments.length - 1))});
      }
    }
    return func;
  };
  var applyBind = function applyBind2() {
    return $reflectApply(C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_functionBind, $apply2, arguments);
  };
  if ($defineProperty2) {
    $defineProperty2(module.exports, "apply", {value: applyBind});
  } else {
    module.exports.apply = applyBind;
  }
});
var $indexOf$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_callBind(C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("String.prototype.indexOf"));
var callBound = function callBoundIntrinsic(name2, allowMissing) {
  var intrinsic = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic(name2, !!allowMissing);
  if (typeof intrinsic === "function" && $indexOf$1(name2, ".prototype.") > -1) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_callBind(intrinsic);
  }
  return intrinsic;
};
var hasToStringTag$7 = typeof Symbol === "function" && typeof Symbol.toStringTag === "symbol";
var $toString$3 = callBound("Object.prototype.toString");
var isStandardArguments = function isArguments(value) {
  if (hasToStringTag$7 && value && typeof value === "object" && Symbol.toStringTag in value) {
    return false;
  }
  return $toString$3(value) === "[object Arguments]";
};
var isLegacyArguments = function isArguments2(value) {
  if (isStandardArguments(value)) {
    return true;
  }
  return value !== null && typeof value === "object" && typeof value.length === "number" && value.length >= 0 && $toString$3(value) !== "[object Array]" && $toString$3(value.callee) === "[object Function]";
};
var supportsStandardArguments = function() {
  return isStandardArguments(arguments);
}();
isStandardArguments.isLegacyArguments = isLegacyArguments;
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isArguments = supportsStandardArguments ? isStandardArguments : isLegacyArguments;
var toStr$9 = Object.prototype.toString;
var fnToStr$1 = Function.prototype.toString;
var isFnRegex = /^\s*(?:function)?\*/;
var hasToStringTag$6 = typeof Symbol === "function" && typeof Symbol.toStringTag === "symbol";
var getProto = Object.getPrototypeOf;
var getGeneratorFunc = function() {
  if (!hasToStringTag$6) {
    return false;
  }
  try {
    return Function("return function*() {}")();
  } catch (e) {
  }
};
var GeneratorFunction;
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isGeneratorFunction = function isGeneratorFunction(fn) {
  if (typeof fn !== "function") {
    return false;
  }
  if (isFnRegex.test(fnToStr$1.call(fn))) {
    return true;
  }
  if (!hasToStringTag$6) {
    var str = toStr$9.call(fn);
    return str === "[object GeneratorFunction]";
  }
  if (!getProto) {
    return false;
  }
  if (typeof GeneratorFunction === "undefined") {
    var generatorFunc = getGeneratorFunc();
    GeneratorFunction = generatorFunc ? getProto(generatorFunc) : false;
  }
  return getProto(fn) === GeneratorFunction;
};
var hasOwn$1 = Object.prototype.hasOwnProperty;
var toString = Object.prototype.toString;
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_foreach = function forEach(obj, fn, ctx) {
  if (toString.call(fn) !== "[object Function]") {
    throw new TypeError("iterator must be a function");
  }
  var l = obj.length;
  if (l === +l) {
    for (var i = 0; i < l; i++) {
      fn.call(ctx, obj[i], i, obj);
    }
  } else {
    for (var k in obj) {
      if (hasOwn$1.call(obj, k)) {
        fn.call(ctx, obj[k], k, obj);
      }
    }
  }
};
var toStr$8 = Object.prototype.toString;
var isArguments3 = function isArguments4(value) {
  var str = toStr$8.call(value);
  var isArgs = str === "[object Arguments]";
  if (!isArgs) {
    isArgs = str !== "[object Array]" && value !== null && typeof value === "object" && typeof value.length === "number" && value.length >= 0 && toStr$8.call(value.callee) === "[object Function]";
  }
  return isArgs;
};
var keysShim$1;
if (!Object.keys) {
  var has$2 = Object.prototype.hasOwnProperty;
  var toStr$7 = Object.prototype.toString;
  var isArgs = isArguments3;
  var isEnumerable$1 = Object.prototype.propertyIsEnumerable;
  var hasDontEnumBug = !isEnumerable$1.call({toString: null}, "toString");
  var hasProtoEnumBug = isEnumerable$1.call(function() {
  }, "prototype");
  var dontEnums = [
    "toString",
    "toLocaleString",
    "valueOf",
    "hasOwnProperty",
    "isPrototypeOf",
    "propertyIsEnumerable",
    "constructor"
  ];
  var equalsConstructorPrototype = function(o) {
    var ctor = o.constructor;
    return ctor && ctor.prototype === o;
  };
  var excludedKeys = {
    $applicationCache: true,
    $console: true,
    $external: true,
    $frame: true,
    $frameElement: true,
    $frames: true,
    $innerHeight: true,
    $innerWidth: true,
    $onmozfullscreenchange: true,
    $onmozfullscreenerror: true,
    $outerHeight: true,
    $outerWidth: true,
    $pageXOffset: true,
    $pageYOffset: true,
    $parent: true,
    $scrollLeft: true,
    $scrollTop: true,
    $scrollX: true,
    $scrollY: true,
    $self: true,
    $webkitIndexedDB: true,
    $webkitStorageInfo: true,
    $window: true
  };
  var hasAutomationEqualityBug = function() {
    if (typeof window === "undefined") {
      return false;
    }
    for (var k in window) {
      try {
        if (!excludedKeys["$" + k] && has$2.call(window, k) && window[k] !== null && typeof window[k] === "object") {
          try {
            equalsConstructorPrototype(window[k]);
          } catch (e) {
            return true;
          }
        }
      } catch (e) {
        return true;
      }
    }
    return false;
  }();
  var equalsConstructorPrototypeIfNotBuggy = function(o) {
    if (typeof window === "undefined" || !hasAutomationEqualityBug) {
      return equalsConstructorPrototype(o);
    }
    try {
      return equalsConstructorPrototype(o);
    } catch (e) {
      return false;
    }
  };
  keysShim$1 = function keys2(object) {
    var isObject = object !== null && typeof object === "object";
    var isFunction2 = toStr$7.call(object) === "[object Function]";
    var isArguments5 = isArgs(object);
    var isString3 = isObject && toStr$7.call(object) === "[object String]";
    var theKeys = [];
    if (!isObject && !isFunction2 && !isArguments5) {
      throw new TypeError("Object.keys called on a non-object");
    }
    var skipProto = hasProtoEnumBug && isFunction2;
    if (isString3 && object.length > 0 && !has$2.call(object, 0)) {
      for (var i = 0; i < object.length; ++i) {
        theKeys.push(String(i));
      }
    }
    if (isArguments5 && object.length > 0) {
      for (var j = 0; j < object.length; ++j) {
        theKeys.push(String(j));
      }
    } else {
      for (var name2 in object) {
        if (!(skipProto && name2 === "prototype") && has$2.call(object, name2)) {
          theKeys.push(String(name2));
        }
      }
    }
    if (hasDontEnumBug) {
      var skipConstructor = equalsConstructorPrototypeIfNotBuggy(object);
      for (var k = 0; k < dontEnums.length; ++k) {
        if (!(skipConstructor && dontEnums[k] === "constructor") && has$2.call(object, dontEnums[k])) {
          theKeys.push(dontEnums[k]);
        }
      }
    }
    return theKeys;
  };
}
var implementation$1 = keysShim$1;
var slice = Array.prototype.slice;
var origKeys = Object.keys;
var keysShim = origKeys ? function keys(o) {
  return origKeys(o);
} : implementation$1;
var originalKeys = Object.keys;
keysShim.shim = function shimObjectKeys() {
  if (Object.keys) {
    var keysWorksWithArguments = function() {
      var args = Object.keys(arguments);
      return args && args.length === arguments.length;
    }(1, 2);
    if (!keysWorksWithArguments) {
      Object.keys = function keys2(object) {
        if (isArguments3(object)) {
          return originalKeys(slice.call(object));
        }
        return originalKeys(object);
      };
    }
  } else {
    Object.keys = keysShim;
  }
  return Object.keys || keysShim;
};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_objectKeys = keysShim;
var hasSymbols$4 = typeof Symbol === "function" && typeof Symbol("foo") === "symbol";
var toStr$6 = Object.prototype.toString;
var concat = Array.prototype.concat;
var origDefineProperty = Object.defineProperty;
var isFunction = function(fn) {
  return typeof fn === "function" && toStr$6.call(fn) === "[object Function]";
};
var arePropertyDescriptorsSupported = function() {
  var obj = {};
  try {
    origDefineProperty(obj, "x", {enumerable: false, value: obj});
    for (var _ in obj) {
      return false;
    }
    return obj.x === obj;
  } catch (e) {
    return false;
  }
};
var supportsDescriptors = origDefineProperty && arePropertyDescriptorsSupported();
var defineProperty = function(object, name2, value, predicate) {
  if (name2 in object && (!isFunction(predicate) || !predicate())) {
    return;
  }
  if (supportsDescriptors) {
    origDefineProperty(object, name2, {
      configurable: true,
      enumerable: false,
      value,
      writable: true
    });
  } else {
    object[name2] = value;
  }
};
var defineProperties = function(object, map) {
  var predicates2 = arguments.length > 2 ? arguments[2] : {};
  var props = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_objectKeys(map);
  if (hasSymbols$4) {
    props = concat.call(props, Object.getOwnPropertySymbols(map));
  }
  for (var i = 0; i < props.length; i += 1) {
    defineProperty(object, props[i], map[props[i]], predicates2[props[i]]);
  }
};
defineProperties.supportsDescriptors = !!supportsDescriptors;
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_defineProperties = defineProperties;
var $TypeError$e = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var CheckObjectCoercible = function CheckObjectCoercible2(value, optMessage) {
  if (value == null) {
    throw new $TypeError$e(optMessage || "Cannot call method on " + value);
  }
  return value;
};
var RequireObjectCoercible = CheckObjectCoercible;
var __viteBrowserExternal = {};
var __viteBrowserExternal$1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: __viteBrowserExternal
});
var require$$0$1 = /* @__PURE__ */ getAugmentedNamespace(__viteBrowserExternal$1);
var hasMap = typeof Map === "function" && Map.prototype;
var mapSizeDescriptor = Object.getOwnPropertyDescriptor && hasMap ? Object.getOwnPropertyDescriptor(Map.prototype, "size") : null;
var mapSize = hasMap && mapSizeDescriptor && typeof mapSizeDescriptor.get === "function" ? mapSizeDescriptor.get : null;
var mapForEach = hasMap && Map.prototype.forEach;
var hasSet = typeof Set === "function" && Set.prototype;
var setSizeDescriptor = Object.getOwnPropertyDescriptor && hasSet ? Object.getOwnPropertyDescriptor(Set.prototype, "size") : null;
var setSize = hasSet && setSizeDescriptor && typeof setSizeDescriptor.get === "function" ? setSizeDescriptor.get : null;
var setForEach = hasSet && Set.prototype.forEach;
var hasWeakMap = typeof WeakMap === "function" && WeakMap.prototype;
var weakMapHas = hasWeakMap ? WeakMap.prototype.has : null;
var hasWeakSet = typeof WeakSet === "function" && WeakSet.prototype;
var weakSetHas = hasWeakSet ? WeakSet.prototype.has : null;
var hasWeakRef = typeof WeakRef === "function" && WeakRef.prototype;
var weakRefDeref = hasWeakRef ? WeakRef.prototype.deref : null;
var booleanValueOf = Boolean.prototype.valueOf;
var objectToString = Object.prototype.toString;
var functionToString = Function.prototype.toString;
var match = String.prototype.match;
var bigIntValueOf = typeof BigInt === "function" ? BigInt.prototype.valueOf : null;
var gOPS = Object.getOwnPropertySymbols;
var symToString = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? Symbol.prototype.toString : null;
var hasShammedSymbols = typeof Symbol === "function" && typeof Symbol.iterator === "object";
var isEnumerable = Object.prototype.propertyIsEnumerable;
var gPO = (typeof Reflect === "function" ? Reflect.getPrototypeOf : Object.getPrototypeOf) || ([].__proto__ === Array.prototype ? function(O) {
  return O.__proto__;
} : null);
var inspectCustom = require$$0$1.custom;
var inspectSymbol = inspectCustom && isSymbol(inspectCustom) ? inspectCustom : null;
var toStringTag = typeof Symbol === "function" && typeof Symbol.toStringTag !== "undefined" ? Symbol.toStringTag : null;
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_objectInspect = function inspect_(obj, options, depth, seen) {
  var opts = options || {};
  if (has$1(opts, "quoteStyle") && (opts.quoteStyle !== "single" && opts.quoteStyle !== "double")) {
    throw new TypeError('option "quoteStyle" must be "single" or "double"');
  }
  if (has$1(opts, "maxStringLength") && (typeof opts.maxStringLength === "number" ? opts.maxStringLength < 0 && opts.maxStringLength !== Infinity : opts.maxStringLength !== null)) {
    throw new TypeError('option "maxStringLength", if provided, must be a positive integer, Infinity, or `null`');
  }
  var customInspect = has$1(opts, "customInspect") ? opts.customInspect : true;
  if (typeof customInspect !== "boolean") {
    throw new TypeError('option "customInspect", if provided, must be `true` or `false`');
  }
  if (has$1(opts, "indent") && opts.indent !== null && opts.indent !== "	" && !(parseInt(opts.indent, 10) === opts.indent && opts.indent > 0)) {
    throw new TypeError('options "indent" must be "\\t", an integer > 0, or `null`');
  }
  if (typeof obj === "undefined") {
    return "undefined";
  }
  if (obj === null) {
    return "null";
  }
  if (typeof obj === "boolean") {
    return obj ? "true" : "false";
  }
  if (typeof obj === "string") {
    return inspectString(obj, opts);
  }
  if (typeof obj === "number") {
    if (obj === 0) {
      return Infinity / obj > 0 ? "0" : "-0";
    }
    return String(obj);
  }
  if (typeof obj === "bigint") {
    return String(obj) + "n";
  }
  var maxDepth = typeof opts.depth === "undefined" ? 5 : opts.depth;
  if (typeof depth === "undefined") {
    depth = 0;
  }
  if (depth >= maxDepth && maxDepth > 0 && typeof obj === "object") {
    return isArray(obj) ? "[Array]" : "[Object]";
  }
  var indent = getIndent(opts, depth);
  if (typeof seen === "undefined") {
    seen = [];
  } else if (indexOf(seen, obj) >= 0) {
    return "[Circular]";
  }
  function inspect(value, from, noIndent) {
    if (from) {
      seen = seen.slice();
      seen.push(from);
    }
    if (noIndent) {
      var newOpts = {
        depth: opts.depth
      };
      if (has$1(opts, "quoteStyle")) {
        newOpts.quoteStyle = opts.quoteStyle;
      }
      return inspect_(value, newOpts, depth + 1, seen);
    }
    return inspect_(value, opts, depth + 1, seen);
  }
  if (typeof obj === "function") {
    var name2 = nameOf(obj);
    var keys2 = arrObjKeys(obj, inspect);
    return "[Function" + (name2 ? ": " + name2 : " (anonymous)") + "]" + (keys2.length > 0 ? " { " + keys2.join(", ") + " }" : "");
  }
  if (isSymbol(obj)) {
    var symString = hasShammedSymbols ? String(obj).replace(/^(Symbol\(.*\))_[^)]*$/, "$1") : symToString.call(obj);
    return typeof obj === "object" && !hasShammedSymbols ? markBoxed(symString) : symString;
  }
  if (isElement(obj)) {
    var s2 = "<" + String(obj.nodeName).toLowerCase();
    var attrs = obj.attributes || [];
    for (var i = 0; i < attrs.length; i++) {
      s2 += " " + attrs[i].name + "=" + wrapQuotes(quote(attrs[i].value), "double", opts);
    }
    s2 += ">";
    if (obj.childNodes && obj.childNodes.length) {
      s2 += "...";
    }
    s2 += "</" + String(obj.nodeName).toLowerCase() + ">";
    return s2;
  }
  if (isArray(obj)) {
    if (obj.length === 0) {
      return "[]";
    }
    var xs = arrObjKeys(obj, inspect);
    if (indent && !singleLineValues(xs)) {
      return "[" + indentedJoin(xs, indent) + "]";
    }
    return "[ " + xs.join(", ") + " ]";
  }
  if (isError(obj)) {
    var parts = arrObjKeys(obj, inspect);
    if (parts.length === 0) {
      return "[" + String(obj) + "]";
    }
    return "{ [" + String(obj) + "] " + parts.join(", ") + " }";
  }
  if (typeof obj === "object" && customInspect) {
    if (inspectSymbol && typeof obj[inspectSymbol] === "function") {
      return obj[inspectSymbol]();
    } else if (typeof obj.inspect === "function") {
      return obj.inspect();
    }
  }
  if (isMap(obj)) {
    var mapParts = [];
    mapForEach.call(obj, function(value, key) {
      mapParts.push(inspect(key, obj, true) + " => " + inspect(value, obj));
    });
    return collectionOf("Map", mapSize.call(obj), mapParts, indent);
  }
  if (isSet(obj)) {
    var setParts = [];
    setForEach.call(obj, function(value) {
      setParts.push(inspect(value, obj));
    });
    return collectionOf("Set", setSize.call(obj), setParts, indent);
  }
  if (isWeakMap(obj)) {
    return weakCollectionOf("WeakMap");
  }
  if (isWeakSet(obj)) {
    return weakCollectionOf("WeakSet");
  }
  if (isWeakRef(obj)) {
    return weakCollectionOf("WeakRef");
  }
  if (isNumber(obj)) {
    return markBoxed(inspect(Number(obj)));
  }
  if (isBigInt(obj)) {
    return markBoxed(inspect(bigIntValueOf.call(obj)));
  }
  if (isBoolean(obj)) {
    return markBoxed(booleanValueOf.call(obj));
  }
  if (isString(obj)) {
    return markBoxed(inspect(String(obj)));
  }
  if (!isDate(obj) && !isRegExp(obj)) {
    var ys = arrObjKeys(obj, inspect);
    var isPlainObject = gPO ? gPO(obj) === Object.prototype : obj instanceof Object || obj.constructor === Object;
    var protoTag = obj instanceof Object ? "" : "null prototype";
    var stringTag = !isPlainObject && toStringTag && Object(obj) === obj && toStringTag in obj ? toStr$5(obj).slice(8, -1) : protoTag ? "Object" : "";
    var constructorTag = isPlainObject || typeof obj.constructor !== "function" ? "" : obj.constructor.name ? obj.constructor.name + " " : "";
    var tag = constructorTag + (stringTag || protoTag ? "[" + [].concat(stringTag || [], protoTag || []).join(": ") + "] " : "");
    if (ys.length === 0) {
      return tag + "{}";
    }
    if (indent) {
      return tag + "{" + indentedJoin(ys, indent) + "}";
    }
    return tag + "{ " + ys.join(", ") + " }";
  }
  return String(obj);
};
function wrapQuotes(s2, defaultStyle, opts) {
  var quoteChar = (opts.quoteStyle || defaultStyle) === "double" ? '"' : "'";
  return quoteChar + s2 + quoteChar;
}
function quote(s2) {
  return String(s2).replace(/"/g, "&quot;");
}
function isArray(obj) {
  return toStr$5(obj) === "[object Array]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
}
function isDate(obj) {
  return toStr$5(obj) === "[object Date]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
}
function isRegExp(obj) {
  return toStr$5(obj) === "[object RegExp]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
}
function isError(obj) {
  return toStr$5(obj) === "[object Error]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
}
function isString(obj) {
  return toStr$5(obj) === "[object String]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
}
function isNumber(obj) {
  return toStr$5(obj) === "[object Number]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
}
function isBoolean(obj) {
  return toStr$5(obj) === "[object Boolean]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
}
function isSymbol(obj) {
  if (hasShammedSymbols) {
    return obj && typeof obj === "object" && obj instanceof Symbol;
  }
  if (typeof obj === "symbol") {
    return true;
  }
  if (!obj || typeof obj !== "object" || !symToString) {
    return false;
  }
  try {
    symToString.call(obj);
    return true;
  } catch (e) {
  }
  return false;
}
function isBigInt(obj) {
  if (!obj || typeof obj !== "object" || !bigIntValueOf) {
    return false;
  }
  try {
    bigIntValueOf.call(obj);
    return true;
  } catch (e) {
  }
  return false;
}
var hasOwn = Object.prototype.hasOwnProperty || function(key) {
  return key in this;
};
function has$1(obj, key) {
  return hasOwn.call(obj, key);
}
function toStr$5(obj) {
  return objectToString.call(obj);
}
function nameOf(f) {
  if (f.name) {
    return f.name;
  }
  var m = match.call(functionToString.call(f), /^function\s*([\w$]+)/);
  if (m) {
    return m[1];
  }
  return null;
}
function indexOf(xs, x) {
  if (xs.indexOf) {
    return xs.indexOf(x);
  }
  for (var i = 0, l = xs.length; i < l; i++) {
    if (xs[i] === x) {
      return i;
    }
  }
  return -1;
}
function isMap(x) {
  if (!mapSize || !x || typeof x !== "object") {
    return false;
  }
  try {
    mapSize.call(x);
    try {
      setSize.call(x);
    } catch (s2) {
      return true;
    }
    return x instanceof Map;
  } catch (e) {
  }
  return false;
}
function isWeakMap(x) {
  if (!weakMapHas || !x || typeof x !== "object") {
    return false;
  }
  try {
    weakMapHas.call(x, weakMapHas);
    try {
      weakSetHas.call(x, weakSetHas);
    } catch (s2) {
      return true;
    }
    return x instanceof WeakMap;
  } catch (e) {
  }
  return false;
}
function isWeakRef(x) {
  if (!weakRefDeref || !x || typeof x !== "object") {
    return false;
  }
  try {
    weakRefDeref.call(x);
    return true;
  } catch (e) {
  }
  return false;
}
function isSet(x) {
  if (!setSize || !x || typeof x !== "object") {
    return false;
  }
  try {
    setSize.call(x);
    try {
      mapSize.call(x);
    } catch (m) {
      return true;
    }
    return x instanceof Set;
  } catch (e) {
  }
  return false;
}
function isWeakSet(x) {
  if (!weakSetHas || !x || typeof x !== "object") {
    return false;
  }
  try {
    weakSetHas.call(x, weakSetHas);
    try {
      weakMapHas.call(x, weakMapHas);
    } catch (s2) {
      return true;
    }
    return x instanceof WeakSet;
  } catch (e) {
  }
  return false;
}
function isElement(x) {
  if (!x || typeof x !== "object") {
    return false;
  }
  if (typeof HTMLElement !== "undefined" && x instanceof HTMLElement) {
    return true;
  }
  return typeof x.nodeName === "string" && typeof x.getAttribute === "function";
}
function inspectString(str, opts) {
  if (str.length > opts.maxStringLength) {
    var remaining = str.length - opts.maxStringLength;
    var trailer = "... " + remaining + " more character" + (remaining > 1 ? "s" : "");
    return inspectString(str.slice(0, opts.maxStringLength), opts) + trailer;
  }
  var s2 = str.replace(/(['\\])/g, "\\$1").replace(/[\x00-\x1f]/g, lowbyte);
  return wrapQuotes(s2, "single", opts);
}
function lowbyte(c) {
  var n = c.charCodeAt(0);
  var x = {
    8: "b",
    9: "t",
    10: "n",
    12: "f",
    13: "r"
  }[n];
  if (x) {
    return "\\" + x;
  }
  return "\\x" + (n < 16 ? "0" : "") + n.toString(16).toUpperCase();
}
function markBoxed(str) {
  return "Object(" + str + ")";
}
function weakCollectionOf(type) {
  return type + " { ? }";
}
function collectionOf(type, size, entries, indent) {
  var joinedEntries = indent ? indentedJoin(entries, indent) : entries.join(", ");
  return type + " (" + size + ") {" + joinedEntries + "}";
}
function singleLineValues(xs) {
  for (var i = 0; i < xs.length; i++) {
    if (indexOf(xs[i], "\n") >= 0) {
      return false;
    }
  }
  return true;
}
function getIndent(opts, depth) {
  var baseIndent;
  if (opts.indent === "	") {
    baseIndent = "	";
  } else if (typeof opts.indent === "number" && opts.indent > 0) {
    baseIndent = Array(opts.indent + 1).join(" ");
  } else {
    return null;
  }
  return {
    base: baseIndent,
    prev: Array(depth + 1).join(baseIndent)
  };
}
function indentedJoin(xs, indent) {
  if (xs.length === 0) {
    return "";
  }
  var lineJoiner = "\n" + indent.prev + indent.base;
  return lineJoiner + xs.join("," + lineJoiner) + "\n" + indent.prev;
}
function arrObjKeys(obj, inspect) {
  var isArr = isArray(obj);
  var xs = [];
  if (isArr) {
    xs.length = obj.length;
    for (var i = 0; i < obj.length; i++) {
      xs[i] = has$1(obj, i) ? inspect(obj[i], obj) : "";
    }
  }
  var syms = typeof gOPS === "function" ? gOPS(obj) : [];
  var symMap;
  if (hasShammedSymbols) {
    symMap = {};
    for (var k = 0; k < syms.length; k++) {
      symMap["$" + syms[k]] = syms[k];
    }
  }
  for (var key in obj) {
    if (!has$1(obj, key)) {
      continue;
    }
    if (isArr && String(Number(key)) === key && key < obj.length) {
      continue;
    }
    if (hasShammedSymbols && symMap["$" + key] instanceof Symbol) {
      continue;
    } else if (/[^\w$]/.test(key)) {
      xs.push(inspect(key, obj) + ": " + inspect(obj[key], obj));
    } else {
      xs.push(key + ": " + inspect(obj[key], obj));
    }
  }
  if (typeof gOPS === "function") {
    for (var j = 0; j < syms.length; j++) {
      if (isEnumerable.call(obj, syms[j])) {
        xs.push("[" + inspect(syms[j]) + "]: " + inspect(obj[syms[j]], obj));
      }
    }
  }
  return xs;
}
var IsPropertyKey = function IsPropertyKey2(argument) {
  return typeof argument === "string" || typeof argument === "symbol";
};
var Type$1 = function Type(x) {
  if (x === null) {
    return "Null";
  }
  if (typeof x === "undefined") {
    return "Undefined";
  }
  if (typeof x === "function" || typeof x === "object") {
    return "Object";
  }
  if (typeof x === "number") {
    return "Number";
  }
  if (typeof x === "boolean") {
    return "Boolean";
  }
  if (typeof x === "string") {
    return "String";
  }
};
var Type2 = function Type3(x) {
  if (typeof x === "symbol") {
    return "Symbol";
  }
  if (typeof x === "bigint") {
    return "BigInt";
  }
  return Type$1(x);
};
var $TypeError$d = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var Get = function Get2(O, P) {
  if (Type2(O) !== "Object") {
    throw new $TypeError$d("Assertion failed: Type(O) is not Object");
  }
  if (!IsPropertyKey(P)) {
    throw new $TypeError$d("Assertion failed: IsPropertyKey(P) is not true, got " + C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_objectInspect(P));
  }
  return O[P];
};
var $Array$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Array%");
var toStr$4 = !$Array$1.isArray && callBound("Object.prototype.toString");
var IsArray = $Array$1.isArray || function IsArray2(argument) {
  return toStr$4(argument) === "[object Array]";
};
var GetIntrinsic2 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic;
var $TypeError$c = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var isPropertyDescriptor = function IsPropertyDescriptor(ES, Desc) {
  if (ES.Type(Desc) !== "Object") {
    return false;
  }
  var allowed = {
    "[[Configurable]]": true,
    "[[Enumerable]]": true,
    "[[Get]]": true,
    "[[Set]]": true,
    "[[Value]]": true,
    "[[Writable]]": true
  };
  for (var key in Desc) {
    if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Desc, key) && !allowed[key]) {
      return false;
    }
  }
  if (ES.IsDataDescriptor(Desc) && ES.IsAccessorDescriptor(Desc)) {
    throw new $TypeError$c("Property Descriptors may not be both accessor and data descriptors");
  }
  return true;
};
var $defineProperty = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Object.defineProperty%", true);
if ($defineProperty) {
  try {
    $defineProperty({}, "a", {value: 1});
  } catch (e) {
    $defineProperty = null;
  }
}
var $isEnumerable$1 = callBound("Object.prototype.propertyIsEnumerable");
var DefineOwnProperty = function DefineOwnProperty2(IsDataDescriptor3, SameValue3, FromPropertyDescriptor3, O, P, desc) {
  if (!$defineProperty) {
    if (!IsDataDescriptor3(desc)) {
      return false;
    }
    if (!desc["[[Configurable]]"] || !desc["[[Writable]]"]) {
      return false;
    }
    if (P in O && $isEnumerable$1(O, P) !== !!desc["[[Enumerable]]"]) {
      return false;
    }
    var V = desc["[[Value]]"];
    O[P] = V;
    return SameValue3(O[P], V);
  }
  $defineProperty(O, P, FromPropertyDescriptor3(desc));
  return true;
};
var $TypeError$b = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var $SyntaxError = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%SyntaxError%");
var predicates = {
  "Property Descriptor": function isPropertyDescriptor2(Type4, Desc) {
    if (Type4(Desc) !== "Object") {
      return false;
    }
    var allowed = {
      "[[Configurable]]": true,
      "[[Enumerable]]": true,
      "[[Get]]": true,
      "[[Set]]": true,
      "[[Value]]": true,
      "[[Writable]]": true
    };
    for (var key in Desc) {
      if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Desc, key) && !allowed[key]) {
        return false;
      }
    }
    var isData = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Desc, "[[Value]]");
    var IsAccessor = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Desc, "[[Get]]") || C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Desc, "[[Set]]");
    if (isData && IsAccessor) {
      throw new $TypeError$b("Property Descriptors may not be both accessor and data descriptors");
    }
    return true;
  }
};
var assertRecord = function assertRecord2(Type4, recordType, argumentName, value) {
  var predicate = predicates[recordType];
  if (typeof predicate !== "function") {
    throw new $SyntaxError("unknown record type: " + recordType);
  }
  if (!predicate(Type4, value)) {
    throw new $TypeError$b(argumentName + " must be a " + recordType);
  }
};
var FromPropertyDescriptor = function FromPropertyDescriptor2(Desc) {
  if (typeof Desc === "undefined") {
    return Desc;
  }
  assertRecord(Type2, "Property Descriptor", "Desc", Desc);
  var obj = {};
  if ("[[Value]]" in Desc) {
    obj.value = Desc["[[Value]]"];
  }
  if ("[[Writable]]" in Desc) {
    obj.writable = Desc["[[Writable]]"];
  }
  if ("[[Get]]" in Desc) {
    obj.get = Desc["[[Get]]"];
  }
  if ("[[Set]]" in Desc) {
    obj.set = Desc["[[Set]]"];
  }
  if ("[[Enumerable]]" in Desc) {
    obj.enumerable = Desc["[[Enumerable]]"];
  }
  if ("[[Configurable]]" in Desc) {
    obj.configurable = Desc["[[Configurable]]"];
  }
  return obj;
};
var IsAccessorDescriptor = function IsAccessorDescriptor2(Desc) {
  if (typeof Desc === "undefined") {
    return false;
  }
  assertRecord(Type2, "Property Descriptor", "Desc", Desc);
  if (!C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Desc, "[[Get]]") && !C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Desc, "[[Set]]")) {
    return false;
  }
  return true;
};
var IsDataDescriptor = function IsDataDescriptor2(Desc) {
  if (typeof Desc === "undefined") {
    return false;
  }
  assertRecord(Type2, "Property Descriptor", "Desc", Desc);
  if (!C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Desc, "[[Value]]") && !C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Desc, "[[Writable]]")) {
    return false;
  }
  return true;
};
var _isNaN = Number.isNaN || function isNaN2(a) {
  return a !== a;
};
var SameValue = function SameValue2(x, y) {
  if (x === y) {
    if (x === 0) {
      return 1 / x === 1 / y;
    }
    return true;
  }
  return _isNaN(x) && _isNaN(y);
};
var ToBoolean = function ToBoolean2(value) {
  return !!value;
};
var fnToStr = Function.prototype.toString;
var reflectApply = typeof Reflect === "object" && Reflect !== null && Reflect.apply;
var badArrayLike;
var isCallableMarker;
if (typeof reflectApply === "function" && typeof Object.defineProperty === "function") {
  try {
    badArrayLike = Object.defineProperty({}, "length", {
      get: function() {
        throw isCallableMarker;
      }
    });
    isCallableMarker = {};
    reflectApply(function() {
      throw 42;
    }, null, badArrayLike);
  } catch (_) {
    if (_ !== isCallableMarker) {
      reflectApply = null;
    }
  }
} else {
  reflectApply = null;
}
var constructorRegex = /^\s*class\b/;
var isES6ClassFn = function isES6ClassFunction(value) {
  try {
    var fnStr = fnToStr.call(value);
    return constructorRegex.test(fnStr);
  } catch (e) {
    return false;
  }
};
var tryFunctionObject = function tryFunctionToStr(value) {
  try {
    if (isES6ClassFn(value)) {
      return false;
    }
    fnToStr.call(value);
    return true;
  } catch (e) {
    return false;
  }
};
var toStr$3 = Object.prototype.toString;
var fnClass = "[object Function]";
var genClass = "[object GeneratorFunction]";
var hasToStringTag$5 = typeof Symbol === "function" && typeof Symbol.toStringTag === "symbol";
var documentDotAll = typeof document === "object" && typeof document.all === "undefined" && document.all !== void 0 ? document.all : {};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isCallable = reflectApply ? function isCallable(value) {
  if (value === documentDotAll) {
    return true;
  }
  if (!value) {
    return false;
  }
  if (typeof value !== "function" && typeof value !== "object") {
    return false;
  }
  if (typeof value === "function" && !value.prototype) {
    return true;
  }
  try {
    reflectApply(value, null, badArrayLike);
  } catch (e) {
    if (e !== isCallableMarker) {
      return false;
    }
  }
  return !isES6ClassFn(value);
} : function isCallable2(value) {
  if (value === documentDotAll) {
    return true;
  }
  if (!value) {
    return false;
  }
  if (typeof value !== "function" && typeof value !== "object") {
    return false;
  }
  if (typeof value === "function" && !value.prototype) {
    return true;
  }
  if (hasToStringTag$5) {
    return tryFunctionObject(value);
  }
  if (isES6ClassFn(value)) {
    return false;
  }
  var strClass2 = toStr$3.call(value);
  return strClass2 === fnClass || strClass2 === genClass;
};
var IsCallable = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isCallable;
var $TypeError$a = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var ToPropertyDescriptor = function ToPropertyDescriptor2(Obj) {
  if (Type2(Obj) !== "Object") {
    throw new $TypeError$a("ToPropertyDescriptor requires an object");
  }
  var desc = {};
  if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Obj, "enumerable")) {
    desc["[[Enumerable]]"] = ToBoolean(Obj.enumerable);
  }
  if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Obj, "configurable")) {
    desc["[[Configurable]]"] = ToBoolean(Obj.configurable);
  }
  if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Obj, "value")) {
    desc["[[Value]]"] = Obj.value;
  }
  if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Obj, "writable")) {
    desc["[[Writable]]"] = ToBoolean(Obj.writable);
  }
  if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Obj, "get")) {
    var getter = Obj.get;
    if (typeof getter !== "undefined" && !IsCallable(getter)) {
      throw new $TypeError$a("getter must be a function");
    }
    desc["[[Get]]"] = getter;
  }
  if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(Obj, "set")) {
    var setter = Obj.set;
    if (typeof setter !== "undefined" && !IsCallable(setter)) {
      throw new $TypeError$a("setter must be a function");
    }
    desc["[[Set]]"] = setter;
  }
  if ((C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(desc, "[[Get]]") || C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(desc, "[[Set]]")) && (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(desc, "[[Value]]") || C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(desc, "[[Writable]]"))) {
    throw new $TypeError$a("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute");
  }
  return desc;
};
var $TypeError$9 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var DefinePropertyOrThrow = function DefinePropertyOrThrow2(O, P, desc) {
  if (Type2(O) !== "Object") {
    throw new $TypeError$9("Assertion failed: Type(O) is not Object");
  }
  if (!IsPropertyKey(P)) {
    throw new $TypeError$9("Assertion failed: IsPropertyKey(P) is not true");
  }
  var Desc = isPropertyDescriptor({
    Type: Type2,
    IsDataDescriptor,
    IsAccessorDescriptor
  }, desc) ? desc : ToPropertyDescriptor(desc);
  if (!isPropertyDescriptor({
    Type: Type2,
    IsDataDescriptor,
    IsAccessorDescriptor
  }, Desc)) {
    throw new $TypeError$9("Assertion failed: Desc is not a valid Property Descriptor");
  }
  return DefineOwnProperty(IsDataDescriptor, SameValue, FromPropertyDescriptor, O, P, Desc);
};
var IsConstructor = createCommonjsModule(function(module) {
  var $construct = GetIntrinsic2("%Reflect.construct%", true);
  var DefinePropertyOrThrow$1 = DefinePropertyOrThrow;
  try {
    DefinePropertyOrThrow$1({}, "", {"[[Get]]": function() {
    }});
  } catch (e) {
    DefinePropertyOrThrow$1 = null;
  }
  if (DefinePropertyOrThrow$1 && $construct) {
    var isConstructorMarker = {};
    var badArrayLike2 = {};
    DefinePropertyOrThrow$1(badArrayLike2, "length", {
      "[[Get]]": function() {
        throw isConstructorMarker;
      },
      "[[Enumerable]]": true
    });
    module.exports = function IsConstructor2(argument) {
      try {
        $construct(argument, badArrayLike2);
      } catch (err) {
        return err === isConstructorMarker;
      }
    };
  } else {
    module.exports = function IsConstructor2(argument) {
      return typeof argument === "function" && !!argument.prototype;
    };
  }
});
var $abs$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Math.abs%");
var abs$1 = function abs(x) {
  return $abs$1(x);
};
var $floor$1 = Math.floor;
var floor$1 = function floor(x) {
  return $floor$1(x);
};
var $isNaN = Number.isNaN || function(a) {
  return a !== a;
};
var _isFinite = Number.isFinite || function(x) {
  return typeof x === "number" && !$isNaN(x) && x !== Infinity && x !== -Infinity;
};
var IsInteger = function IsInteger2(argument) {
  if (typeof argument !== "number" || _isNaN(argument) || !_isFinite(argument)) {
    return false;
  }
  var absValue = abs$1(argument);
  return floor$1(absValue) === absValue;
};
var $Array = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Array%");
var $species = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Symbol.species%", true);
var $TypeError$8 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var ArraySpeciesCreate = function ArraySpeciesCreate2(originalArray, length) {
  if (!IsInteger(length) || length < 0) {
    throw new $TypeError$8("Assertion failed: length must be an integer >= 0");
  }
  var len = length === 0 ? 0 : length;
  var C;
  var isArray2 = IsArray(originalArray);
  if (isArray2) {
    C = Get(originalArray, "constructor");
    if ($species && Type2(C) === "Object") {
      C = Get(C, $species);
      if (C === null) {
        C = void 0;
      }
    }
  }
  if (typeof C === "undefined") {
    return $Array(len);
  }
  if (!IsConstructor(C)) {
    throw new $TypeError$8("C must be a constructor");
  }
  return new C(len);
};
var $TypeError$7 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var $apply = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Reflect.apply%", true) || callBound("%Function.prototype.apply%");
var Call = function Call2(F, V) {
  var argumentsList = arguments.length > 2 ? arguments[2] : [];
  if (!IsArray(argumentsList)) {
    throw new $TypeError$7("Assertion failed: optional `argumentsList`, if provided, must be a List");
  }
  return $apply(F, V, argumentsList);
};
var $gOPD = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Object.getOwnPropertyDescriptor%");
if ($gOPD) {
  try {
    $gOPD([], "length");
  } catch (e) {
    $gOPD = null;
  }
}
var getOwnPropertyDescriptor = $gOPD;
var hasSymbols$3 = shams();
var hasToStringTag$4 = hasSymbols$3 && !!Symbol.toStringTag;
var has;
var $exec;
var isRegexMarker;
var badStringifier;
if (hasToStringTag$4) {
  has = callBound("Object.prototype.hasOwnProperty");
  $exec = callBound("RegExp.prototype.exec");
  isRegexMarker = {};
  var throwRegexMarker = function() {
    throw isRegexMarker;
  };
  badStringifier = {
    toString: throwRegexMarker,
    valueOf: throwRegexMarker
  };
  if (typeof Symbol.toPrimitive === "symbol") {
    badStringifier[Symbol.toPrimitive] = throwRegexMarker;
  }
}
var $toString$2 = callBound("Object.prototype.toString");
var gOPD = Object.getOwnPropertyDescriptor;
var regexClass = "[object RegExp]";
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isRegex = hasToStringTag$4 ? function isRegex(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  var descriptor = gOPD(value, "lastIndex");
  var hasLastIndexDataProperty = descriptor && has(descriptor, "value");
  if (!hasLastIndexDataProperty) {
    return false;
  }
  try {
    $exec(value, badStringifier);
  } catch (e) {
    return e === isRegexMarker;
  }
} : function isRegex2(value) {
  if (!value || typeof value !== "object" && typeof value !== "function") {
    return false;
  }
  return $toString$2(value) === regexClass;
};
var $match = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Symbol.match%", true);
var IsRegExp = function IsRegExp2(argument) {
  if (!argument || typeof argument !== "object") {
    return false;
  }
  if ($match) {
    var isRegExp2 = argument[$match];
    if (typeof isRegExp2 !== "undefined") {
      return ToBoolean(isRegExp2);
    }
  }
  return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isRegex(argument);
};
var $TypeError$6 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var $isEnumerable = callBound("Object.prototype.propertyIsEnumerable");
var OrdinaryGetOwnProperty = function OrdinaryGetOwnProperty2(O, P) {
  if (Type2(O) !== "Object") {
    throw new $TypeError$6("Assertion failed: O must be an Object");
  }
  if (!IsPropertyKey(P)) {
    throw new $TypeError$6("Assertion failed: P must be a Property Key");
  }
  if (!C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_has_src(O, P)) {
    return void 0;
  }
  if (!getOwnPropertyDescriptor) {
    var arrayLength = IsArray(O) && P === "length";
    var regexLastIndex = IsRegExp(O) && P === "lastIndex";
    return {
      "[[Configurable]]": !(arrayLength || regexLastIndex),
      "[[Enumerable]]": $isEnumerable(O, P),
      "[[Value]]": O[P],
      "[[Writable]]": true
    };
  }
  return ToPropertyDescriptor(getOwnPropertyDescriptor(O, P));
};
var isPrimitive$2 = function isPrimitive(value) {
  return value === null || typeof value !== "function" && typeof value !== "object";
};
var $Object$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Object%");
var $preventExtensions = $Object$1.preventExtensions;
var $isExtensible = $Object$1.isExtensible;
var IsExtensible = $preventExtensions ? function IsExtensible2(obj) {
  return !isPrimitive$2(obj) && $isExtensible(obj);
} : function IsExtensible3(obj) {
  return !isPrimitive$2(obj);
};
var $TypeError$5 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var CreateDataProperty = function CreateDataProperty2(O, P, V) {
  if (Type2(O) !== "Object") {
    throw new $TypeError$5("Assertion failed: Type(O) is not Object");
  }
  if (!IsPropertyKey(P)) {
    throw new $TypeError$5("Assertion failed: IsPropertyKey(P) is not true");
  }
  var oldDesc = OrdinaryGetOwnProperty(O, P);
  var extensible = !oldDesc || IsExtensible(O);
  var immutable = oldDesc && (!oldDesc["[[Writable]]"] || !oldDesc["[[Configurable]]"]);
  if (immutable || !extensible) {
    return false;
  }
  return DefineOwnProperty(IsDataDescriptor, SameValue, FromPropertyDescriptor, O, P, {
    "[[Configurable]]": true,
    "[[Enumerable]]": true,
    "[[Value]]": V,
    "[[Writable]]": true
  });
};
var $TypeError$4 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var CreateDataPropertyOrThrow = function CreateDataPropertyOrThrow2(O, P, V) {
  if (Type2(O) !== "Object") {
    throw new $TypeError$4("Assertion failed: Type(O) is not Object");
  }
  if (!IsPropertyKey(P)) {
    throw new $TypeError$4("Assertion failed: IsPropertyKey(P) is not true");
  }
  var success = CreateDataProperty(O, P, V);
  if (!success) {
    throw new $TypeError$4("unable to create data property");
  }
  return success;
};
var $TypeError$3 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var HasProperty = function HasProperty2(O, P) {
  if (Type2(O) !== "Object") {
    throw new $TypeError$3("Assertion failed: `O` must be an Object");
  }
  if (!IsPropertyKey(P)) {
    throw new $TypeError$3("Assertion failed: `P` must be a Property Key");
  }
  return P in O;
};
var $Math = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Math%");
var $Number$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Number%");
var maxSafeInteger = $Number$1.MAX_SAFE_INTEGER || $Math.pow(2, 53) - 1;
var $abs = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Math.abs%");
var abs2 = function abs3(x) {
  return $abs(x);
};
var $floor = Math.floor;
var floor2 = function floor3(x) {
  return $floor(x);
};
var isPrimitive$1 = function isPrimitive2(value) {
  return value === null || typeof value !== "function" && typeof value !== "object";
};
var toStr$2 = Object.prototype.toString;
var ES5internalSlots = {
  "[[DefaultValue]]": function(O) {
    var actualHint;
    if (arguments.length > 1) {
      actualHint = arguments[1];
    } else {
      actualHint = toStr$2.call(O) === "[object Date]" ? String : Number;
    }
    if (actualHint === String || actualHint === Number) {
      var methods = actualHint === String ? ["toString", "valueOf"] : ["valueOf", "toString"];
      var value, i;
      for (i = 0; i < methods.length; ++i) {
        if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isCallable(O[methods[i]])) {
          value = O[methods[i]]();
          if (isPrimitive$1(value)) {
            return value;
          }
        }
      }
      throw new TypeError("No default value");
    }
    throw new TypeError("invalid [[DefaultValue]] hint supplied");
  }
};
var es5 = function ToPrimitive(input) {
  if (isPrimitive$1(input)) {
    return input;
  }
  if (arguments.length > 1) {
    return ES5internalSlots["[[DefaultValue]]"](input, arguments[1]);
  }
  return ES5internalSlots["[[DefaultValue]]"](input);
};
var ToPrimitive$1 = es5;
var ToNumber$1 = function ToNumber(value) {
  var prim = ToPrimitive$1(value, Number);
  if (typeof prim !== "string") {
    return +prim;
  }
  var trimmed = prim.replace(/^[ \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u0085]+|[ \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u0085]+$/g, "");
  if (/^0[ob]|^[+-]0x/.test(trimmed)) {
    return NaN;
  }
  return +trimmed;
};
var sign = function sign2(number) {
  return number >= 0 ? 1 : -1;
};
var ToInteger$1 = function ToInteger(value) {
  var number = ToNumber$1(value);
  if (_isNaN(number)) {
    return 0;
  }
  if (number === 0 || !_isFinite(number)) {
    return number;
  }
  return sign(number) * floor2(abs2(number));
};
var $test = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("RegExp.prototype.test");
var regexTester = function regexTester2(regex) {
  return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_callBind($test, regex);
};
var getDay = Date.prototype.getDay;
var tryDateObject = function tryDateGetDayCall(value) {
  try {
    getDay.call(value);
    return true;
  } catch (e) {
    return false;
  }
};
var toStr$1 = Object.prototype.toString;
var dateClass = "[object Date]";
var hasToStringTag$3 = typeof Symbol === "function" && !!Symbol.toStringTag;
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isDateObject = function isDateObject(value) {
  if (typeof value !== "object" || value === null) {
    return false;
  }
  return hasToStringTag$3 ? tryDateObject(value) : toStr$1.call(value) === dateClass;
};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isSymbol = createCommonjsModule(function(module) {
  var toStr2 = Object.prototype.toString;
  var hasSymbols3 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_hasSymbols();
  if (hasSymbols3) {
    var symToStr = Symbol.prototype.toString;
    var symStringRegex = /^Symbol\(.*\)$/;
    var isSymbolObject = function isRealSymbolObject(value) {
      if (typeof value.valueOf() !== "symbol") {
        return false;
      }
      return symStringRegex.test(symToStr.call(value));
    };
    module.exports = function isSymbol2(value) {
      if (typeof value === "symbol") {
        return true;
      }
      if (toStr2.call(value) !== "[object Symbol]") {
        return false;
      }
      try {
        return isSymbolObject(value);
      } catch (e) {
        return false;
      }
    };
  } else {
    module.exports = function isSymbol2(value) {
      return false;
    };
  }
});
var hasSymbols$2 = typeof Symbol === "function" && typeof Symbol.iterator === "symbol";
var ordinaryToPrimitive = function OrdinaryToPrimitive(O, hint) {
  if (typeof O === "undefined" || O === null) {
    throw new TypeError("Cannot call method on " + O);
  }
  if (typeof hint !== "string" || hint !== "number" && hint !== "string") {
    throw new TypeError('hint must be "string" or "number"');
  }
  var methodNames = hint === "string" ? ["toString", "valueOf"] : ["valueOf", "toString"];
  var method, result, i;
  for (i = 0; i < methodNames.length; ++i) {
    method = O[methodNames[i]];
    if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isCallable(method)) {
      result = method.call(O);
      if (isPrimitive$1(result)) {
        return result;
      }
    }
  }
  throw new TypeError("No default value");
};
var GetMethod = function GetMethod2(O, P) {
  var func = O[P];
  if (func !== null && typeof func !== "undefined") {
    if (!C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isCallable(func)) {
      throw new TypeError(func + " returned for property " + P + " of object " + O + " is not a function");
    }
    return func;
  }
  return void 0;
};
var es2015 = function ToPrimitive2(input) {
  if (isPrimitive$1(input)) {
    return input;
  }
  var hint = "default";
  if (arguments.length > 1) {
    if (arguments[1] === String) {
      hint = "string";
    } else if (arguments[1] === Number) {
      hint = "number";
    }
  }
  var exoticToPrim;
  if (hasSymbols$2) {
    if (Symbol.toPrimitive) {
      exoticToPrim = GetMethod(input, Symbol.toPrimitive);
    } else if (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isSymbol(input)) {
      exoticToPrim = Symbol.prototype.valueOf;
    }
  }
  if (typeof exoticToPrim !== "undefined") {
    var result = exoticToPrim.call(input, hint);
    if (isPrimitive$1(result)) {
      return result;
    }
    throw new TypeError("unable to convert exotic object to primitive");
  }
  if (hint === "default" && (C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isDateObject(input) || C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isSymbol(input))) {
    hint = "string";
  }
  return ordinaryToPrimitive(input, hint === "default" ? "number" : hint);
};
var ToPrimitive3 = function ToPrimitive4(input) {
  if (arguments.length > 1) {
    return es2015(input, arguments[1]);
  }
  return es2015(input);
};
var $TypeError$2 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var $Number = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Number%");
var $RegExp = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%RegExp%");
var $parseInteger = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%parseInt%");
var $strSlice = callBound("String.prototype.slice");
var isBinary = regexTester(/^0b[01]+$/i);
var isOctal = regexTester(/^0o[0-7]+$/i);
var isInvalidHexLiteral = regexTester(/^[-+]0x[0-9a-f]+$/i);
var nonWS = ["\x85", "\u200B", "\uFFFE"].join("");
var nonWSregex = new $RegExp("[" + nonWS + "]", "g");
var hasNonWS = regexTester(nonWSregex);
var ws = [
  "	\n\v\f\r \xA0\u1680\u180E\u2000\u2001\u2002\u2003",
  "\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028",
  "\u2029\uFEFF"
].join("");
var trimRegex = new RegExp("(^[" + ws + "]+)|([" + ws + "]+$)", "g");
var $replace = callBound("String.prototype.replace");
var $trim = function(value) {
  return $replace(value, trimRegex, "");
};
var ToNumber2 = function ToNumber3(argument) {
  var value = isPrimitive$2(argument) ? argument : ToPrimitive3(argument, $Number);
  if (typeof value === "symbol") {
    throw new $TypeError$2("Cannot convert a Symbol value to a number");
  }
  if (typeof value === "string") {
    if (isBinary(value)) {
      return ToNumber3($parseInteger($strSlice(value, 2), 2));
    } else if (isOctal(value)) {
      return ToNumber3($parseInteger($strSlice(value, 2), 8));
    } else if (hasNonWS(value) || isInvalidHexLiteral(value)) {
      return NaN;
    } else {
      var trimmed = $trim(value);
      if (trimmed !== value) {
        return ToNumber3(trimmed);
      }
    }
  }
  return $Number(value);
};
var ToInteger2 = function ToInteger3(value) {
  var number = ToNumber2(value);
  if (number !== 0) {
    number = ToInteger$1(number);
  }
  return number === 0 ? 0 : number;
};
var ToLength = function ToLength2(argument) {
  var len = ToInteger2(argument);
  if (len <= 0) {
    return 0;
  }
  if (len > maxSafeInteger) {
    return maxSafeInteger;
  }
  return len;
};
var $TypeError$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var LengthOfArrayLike = function LengthOfArrayLike2(obj) {
  if (Type2(obj) !== "Object") {
    throw new $TypeError$1("Assertion failed: `obj` must be an Object");
  }
  return ToLength(Get(obj, "length"));
};
var $Object = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%Object%");
var ToObject = function ToObject2(value) {
  RequireObjectCoercible(value);
  return $Object(value);
};
var $String = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%String%");
var $TypeError = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_getIntrinsic("%TypeError%");
var ToString = function ToString2(argument) {
  if (typeof argument === "symbol") {
    throw new $TypeError("Cannot convert a Symbol value to a string");
  }
  return $String(argument);
};
var strValue = String.prototype.valueOf;
var tryStringObject = function tryStringObject2(value) {
  try {
    strValue.call(value);
    return true;
  } catch (e) {
    return false;
  }
};
var toStr = Object.prototype.toString;
var strClass = "[object String]";
var hasToStringTag$2 = typeof Symbol === "function" && typeof Symbol.toStringTag === "symbol";
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isString = function isString2(value) {
  if (typeof value === "string") {
    return true;
  }
  if (typeof value !== "object") {
    return false;
  }
  return hasToStringTag$2 ? tryStringObject(value) : toStr.call(value) === strClass;
};
var boxedString = Object("a");
var splitString = boxedString[0] !== "a" || !(0 in boxedString);
var strSplit = callBound("String.prototype.split");
var implementation = function filter(callbackfn) {
  var O = ToObject(this);
  var self2 = splitString && C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isString(O) ? strSplit(O, "") : O;
  var len = LengthOfArrayLike(self2);
  if (!IsCallable(callbackfn)) {
    throw new TypeError("Array.prototype.filter callback must be a function");
  }
  var thisArg;
  if (arguments.length > 1) {
    thisArg = arguments[1];
  }
  var A = ArraySpeciesCreate(O, 0);
  var k = 0;
  var to = 0;
  while (k < len) {
    var Pk = ToString(k);
    var kPresent = HasProperty(O, Pk);
    if (kPresent) {
      var kValue = Get(O, Pk);
      var selected = ToBoolean(Call(callbackfn, thisArg, [kValue, k, O]));
      if (selected) {
        CreateDataPropertyOrThrow(A, ToString(to), kValue);
        to += 1;
      }
    }
    k += 1;
  }
  return A;
};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_esArrayMethodBoxesProperly = function properlyBoxed(method) {
  var properlyBoxesNonStrict = true;
  var properlyBoxesStrict = true;
  var threwException = false;
  if (typeof method === "function") {
    try {
      method.call("f", function(_, __, O) {
        if (typeof O !== "object") {
          properlyBoxesNonStrict = false;
        }
      });
      method.call([null], function() {
        "use strict";
        properlyBoxesStrict = typeof this === "string";
      }, "x");
    } catch (e) {
      threwException = true;
    }
    return !threwException && properlyBoxesNonStrict && properlyBoxesStrict;
  }
  return false;
};
var polyfill$1 = function getPolyfill() {
  var method = Array.prototype.filter;
  return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_esArrayMethodBoxesProperly(method) ? method : implementation;
};
var shim = function shimArrayPrototypeMap() {
  var polyfill2 = polyfill$1();
  C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_defineProperties(Array.prototype, {filter: polyfill2}, {filter: function() {
    return Array.prototype.filter !== polyfill2;
  }});
  return polyfill2;
};
var polyfill = polyfill$1();
var $slice$2 = callBound("Array.prototype.slice");
var bound = function filter2(array, callbackfn) {
  RequireObjectCoercible(array);
  return polyfill.apply(array, $slice$2(arguments, 1));
};
C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_defineProperties(bound, {
  getPolyfill: polyfill$1,
  implementation,
  shim
});
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_array_prototype_filter = bound;
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_availableTypedArrays = function availableTypedArrays() {
  return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_array_prototype_filter([
    "BigInt64Array",
    "BigUint64Array",
    "Float32Array",
    "Float64Array",
    "Int16Array",
    "Int32Array",
    "Int8Array",
    "Uint16Array",
    "Uint32Array",
    "Uint8Array",
    "Uint8ClampedArray"
  ], function(typedArray) {
    return typeof commonjsGlobal[typedArray] === "function";
  });
};
var $toString$1 = callBound("Object.prototype.toString");
var hasSymbols$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_hasSymbols();
var hasToStringTag$1 = hasSymbols$1 && typeof Symbol.toStringTag === "symbol";
var typedArrays$1 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_availableTypedArrays();
var $indexOf = callBound("Array.prototype.indexOf", true) || function indexOf2(array, value) {
  for (var i = 0; i < array.length; i += 1) {
    if (array[i] === value) {
      return i;
    }
  }
  return -1;
};
var $slice$1 = callBound("String.prototype.slice");
var toStrTags$1 = {};
var getPrototypeOf$1 = Object.getPrototypeOf;
if (hasToStringTag$1 && getOwnPropertyDescriptor && getPrototypeOf$1) {
  C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_foreach(typedArrays$1, function(typedArray) {
    var arr = new commonjsGlobal[typedArray]();
    if (!(Symbol.toStringTag in arr)) {
      throw new EvalError("this engine has support for Symbol.toStringTag, but " + typedArray + " does not have the property! Please report this.");
    }
    var proto = getPrototypeOf$1(arr);
    var descriptor = getOwnPropertyDescriptor(proto, Symbol.toStringTag);
    if (!descriptor) {
      var superProto = getPrototypeOf$1(proto);
      descriptor = getOwnPropertyDescriptor(superProto, Symbol.toStringTag);
    }
    toStrTags$1[typedArray] = descriptor.get;
  });
}
var tryTypedArrays$1 = function tryAllTypedArrays(value) {
  var anyTrue = false;
  C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_foreach(toStrTags$1, function(getter, typedArray) {
    if (!anyTrue) {
      try {
        anyTrue = getter.call(value) === typedArray;
      } catch (e) {
      }
    }
  });
  return anyTrue;
};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isTypedArray = function isTypedArray(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  if (!hasToStringTag$1) {
    var tag = $slice$1($toString$1(value), 8, -1);
    return $indexOf(typedArrays$1, tag) > -1;
  }
  if (!getOwnPropertyDescriptor) {
    return false;
  }
  return tryTypedArrays$1(value);
};
var $toString = callBound("Object.prototype.toString");
var hasSymbols2 = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_hasSymbols();
var hasToStringTag = hasSymbols2 && typeof Symbol.toStringTag === "symbol";
var typedArrays = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_availableTypedArrays();
var $slice = callBound("String.prototype.slice");
var toStrTags = {};
var getPrototypeOf = Object.getPrototypeOf;
if (hasToStringTag && getOwnPropertyDescriptor && getPrototypeOf) {
  C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_foreach(typedArrays, function(typedArray) {
    if (typeof commonjsGlobal[typedArray] === "function") {
      var arr = new commonjsGlobal[typedArray]();
      if (!(Symbol.toStringTag in arr)) {
        throw new EvalError("this engine has support for Symbol.toStringTag, but " + typedArray + " does not have the property! Please report this.");
      }
      var proto = getPrototypeOf(arr);
      var descriptor = getOwnPropertyDescriptor(proto, Symbol.toStringTag);
      if (!descriptor) {
        var superProto = getPrototypeOf(proto);
        descriptor = getOwnPropertyDescriptor(superProto, Symbol.toStringTag);
      }
      toStrTags[typedArray] = descriptor.get;
    }
  });
}
var tryTypedArrays = function tryAllTypedArrays2(value) {
  var foundName = false;
  C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_foreach(toStrTags, function(getter, typedArray) {
    if (!foundName) {
      try {
        var name2 = getter.call(value);
        if (name2 === typedArray) {
          foundName = name2;
        }
      } catch (e) {
      }
    }
  });
  return foundName;
};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray = function whichTypedArray(value) {
  if (!C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isTypedArray(value)) {
    return false;
  }
  if (!hasToStringTag) {
    return $slice($toString(value), 8, -1);
  }
  return tryTypedArrays(value);
};
var types = createCommonjsModule(function(module, exports) {
  function uncurryThis(f) {
    return f.call.bind(f);
  }
  var BigIntSupported = typeof BigInt !== "undefined";
  var SymbolSupported = typeof Symbol !== "undefined";
  var ObjectToString = uncurryThis(Object.prototype.toString);
  var numberValue = uncurryThis(Number.prototype.valueOf);
  var stringValue = uncurryThis(String.prototype.valueOf);
  var booleanValue = uncurryThis(Boolean.prototype.valueOf);
  if (BigIntSupported) {
    var bigIntValue = uncurryThis(BigInt.prototype.valueOf);
  }
  if (SymbolSupported) {
    var symbolValue = uncurryThis(Symbol.prototype.valueOf);
  }
  function checkBoxedPrimitive(value, prototypeValueOf) {
    if (typeof value !== "object") {
      return false;
    }
    try {
      prototypeValueOf(value);
      return true;
    } catch (e) {
      return false;
    }
  }
  exports.isArgumentsObject = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isArguments;
  exports.isGeneratorFunction = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isGeneratorFunction;
  exports.isTypedArray = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isTypedArray;
  function isPromise(input) {
    return typeof Promise !== "undefined" && input instanceof Promise || input !== null && typeof input === "object" && typeof input.then === "function" && typeof input.catch === "function";
  }
  exports.isPromise = isPromise;
  function isArrayBufferView(value) {
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
      return ArrayBuffer.isView(value);
    }
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_isTypedArray(value) || isDataView(value);
  }
  exports.isArrayBufferView = isArrayBufferView;
  function isUint8Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "Uint8Array";
  }
  exports.isUint8Array = isUint8Array;
  function isUint8ClampedArray(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "Uint8ClampedArray";
  }
  exports.isUint8ClampedArray = isUint8ClampedArray;
  function isUint16Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "Uint16Array";
  }
  exports.isUint16Array = isUint16Array;
  function isUint32Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "Uint32Array";
  }
  exports.isUint32Array = isUint32Array;
  function isInt8Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "Int8Array";
  }
  exports.isInt8Array = isInt8Array;
  function isInt16Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "Int16Array";
  }
  exports.isInt16Array = isInt16Array;
  function isInt32Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "Int32Array";
  }
  exports.isInt32Array = isInt32Array;
  function isFloat32Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "Float32Array";
  }
  exports.isFloat32Array = isFloat32Array;
  function isFloat64Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "Float64Array";
  }
  exports.isFloat64Array = isFloat64Array;
  function isBigInt64Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "BigInt64Array";
  }
  exports.isBigInt64Array = isBigInt64Array;
  function isBigUint64Array(value) {
    return C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_whichTypedArray(value) === "BigUint64Array";
  }
  exports.isBigUint64Array = isBigUint64Array;
  function isMapToString(value) {
    return ObjectToString(value) === "[object Map]";
  }
  isMapToString.working = typeof Map !== "undefined" && isMapToString(new Map());
  function isMap2(value) {
    if (typeof Map === "undefined") {
      return false;
    }
    return isMapToString.working ? isMapToString(value) : value instanceof Map;
  }
  exports.isMap = isMap2;
  function isSetToString(value) {
    return ObjectToString(value) === "[object Set]";
  }
  isSetToString.working = typeof Set !== "undefined" && isSetToString(new Set());
  function isSet2(value) {
    if (typeof Set === "undefined") {
      return false;
    }
    return isSetToString.working ? isSetToString(value) : value instanceof Set;
  }
  exports.isSet = isSet2;
  function isWeakMapToString(value) {
    return ObjectToString(value) === "[object WeakMap]";
  }
  isWeakMapToString.working = typeof WeakMap !== "undefined" && isWeakMapToString(new WeakMap());
  function isWeakMap2(value) {
    if (typeof WeakMap === "undefined") {
      return false;
    }
    return isWeakMapToString.working ? isWeakMapToString(value) : value instanceof WeakMap;
  }
  exports.isWeakMap = isWeakMap2;
  function isWeakSetToString(value) {
    return ObjectToString(value) === "[object WeakSet]";
  }
  isWeakSetToString.working = typeof WeakSet !== "undefined" && isWeakSetToString(new WeakSet());
  function isWeakSet2(value) {
    return isWeakSetToString(value);
  }
  exports.isWeakSet = isWeakSet2;
  function isArrayBufferToString(value) {
    return ObjectToString(value) === "[object ArrayBuffer]";
  }
  isArrayBufferToString.working = typeof ArrayBuffer !== "undefined" && isArrayBufferToString(new ArrayBuffer());
  function isArrayBuffer(value) {
    if (typeof ArrayBuffer === "undefined") {
      return false;
    }
    return isArrayBufferToString.working ? isArrayBufferToString(value) : value instanceof ArrayBuffer;
  }
  exports.isArrayBuffer = isArrayBuffer;
  function isDataViewToString(value) {
    return ObjectToString(value) === "[object DataView]";
  }
  isDataViewToString.working = typeof ArrayBuffer !== "undefined" && typeof DataView !== "undefined" && isDataViewToString(new DataView(new ArrayBuffer(1), 0, 1));
  function isDataView(value) {
    if (typeof DataView === "undefined") {
      return false;
    }
    return isDataViewToString.working ? isDataViewToString(value) : value instanceof DataView;
  }
  exports.isDataView = isDataView;
  function isSharedArrayBufferToString(value) {
    return ObjectToString(value) === "[object SharedArrayBuffer]";
  }
  isSharedArrayBufferToString.working = typeof SharedArrayBuffer !== "undefined" && isSharedArrayBufferToString(new SharedArrayBuffer());
  function isSharedArrayBuffer(value) {
    if (typeof SharedArrayBuffer === "undefined") {
      return false;
    }
    return isSharedArrayBufferToString.working ? isSharedArrayBufferToString(value) : value instanceof SharedArrayBuffer;
  }
  exports.isSharedArrayBuffer = isSharedArrayBuffer;
  function isAsyncFunction(value) {
    return ObjectToString(value) === "[object AsyncFunction]";
  }
  exports.isAsyncFunction = isAsyncFunction;
  function isMapIterator(value) {
    return ObjectToString(value) === "[object Map Iterator]";
  }
  exports.isMapIterator = isMapIterator;
  function isSetIterator(value) {
    return ObjectToString(value) === "[object Set Iterator]";
  }
  exports.isSetIterator = isSetIterator;
  function isGeneratorObject(value) {
    return ObjectToString(value) === "[object Generator]";
  }
  exports.isGeneratorObject = isGeneratorObject;
  function isWebAssemblyCompiledModule(value) {
    return ObjectToString(value) === "[object WebAssembly.Module]";
  }
  exports.isWebAssemblyCompiledModule = isWebAssemblyCompiledModule;
  function isNumberObject(value) {
    return checkBoxedPrimitive(value, numberValue);
  }
  exports.isNumberObject = isNumberObject;
  function isStringObject(value) {
    return checkBoxedPrimitive(value, stringValue);
  }
  exports.isStringObject = isStringObject;
  function isBooleanObject(value) {
    return checkBoxedPrimitive(value, booleanValue);
  }
  exports.isBooleanObject = isBooleanObject;
  function isBigIntObject(value) {
    return BigIntSupported && checkBoxedPrimitive(value, bigIntValue);
  }
  exports.isBigIntObject = isBigIntObject;
  function isSymbolObject(value) {
    return SymbolSupported && checkBoxedPrimitive(value, symbolValue);
  }
  exports.isSymbolObject = isSymbolObject;
  function isBoxedPrimitive(value) {
    return isNumberObject(value) || isStringObject(value) || isBooleanObject(value) || isBigIntObject(value) || isSymbolObject(value);
  }
  exports.isBoxedPrimitive = isBoxedPrimitive;
  function isAnyArrayBuffer(value) {
    return typeof Uint8Array !== "undefined" && (isArrayBuffer(value) || isSharedArrayBuffer(value));
  }
  exports.isAnyArrayBuffer = isAnyArrayBuffer;
  ["isProxy", "isExternal", "isModuleNamespaceObject"].forEach(function(method) {
    Object.defineProperty(exports, method, {
      enumerable: false,
      value: function() {
        throw new Error(method + " is not supported in userland");
      }
    });
  });
});
var isBufferBrowser = function isBuffer(arg) {
  return arg && typeof arg === "object" && typeof arg.copy === "function" && typeof arg.fill === "function" && typeof arg.readUInt8 === "function";
};
var inherits_browser = createCommonjsModule(function(module) {
  if (typeof Object.create === "function") {
    module.exports = function inherits(ctor, superCtor) {
      if (superCtor) {
        ctor.super_ = superCtor;
        ctor.prototype = Object.create(superCtor.prototype, {
          constructor: {
            value: ctor,
            enumerable: false,
            writable: true,
            configurable: true
          }
        });
      }
    };
  } else {
    module.exports = function inherits(ctor, superCtor) {
      if (superCtor) {
        ctor.super_ = superCtor;
        var TempCtor = function() {
        };
        TempCtor.prototype = superCtor.prototype;
        ctor.prototype = new TempCtor();
        ctor.prototype.constructor = ctor;
      }
    };
  }
});
var util$1 = createCommonjsModule(function(module, exports) {
  var getOwnPropertyDescriptors = Object.getOwnPropertyDescriptors || function getOwnPropertyDescriptors2(obj) {
    var keys2 = Object.keys(obj);
    var descriptors = {};
    for (var i = 0; i < keys2.length; i++) {
      descriptors[keys2[i]] = Object.getOwnPropertyDescriptor(obj, keys2[i]);
    }
    return descriptors;
  };
  var formatRegExp = /%[sdj%]/g;
  exports.format = function(f) {
    if (!isString3(f)) {
      var objects = [];
      for (var i = 0; i < arguments.length; i++) {
        objects.push(inspect(arguments[i]));
      }
      return objects.join(" ");
    }
    var i = 1;
    var args = arguments;
    var len = args.length;
    var str = String(f).replace(formatRegExp, function(x2) {
      if (x2 === "%%")
        return "%";
      if (i >= len)
        return x2;
      switch (x2) {
        case "%s":
          return String(args[i++]);
        case "%d":
          return Number(args[i++]);
        case "%j":
          try {
            return JSON.stringify(args[i++]);
          } catch (_) {
            return "[Circular]";
          }
        default:
          return x2;
      }
    });
    for (var x = args[i]; i < len; x = args[++i]) {
      if (isNull(x) || !isObject(x)) {
        str += " " + x;
      } else {
        str += " " + inspect(x);
      }
    }
    return str;
  };
  exports.deprecate = function(fn, msg) {
    if (typeof process !== "undefined" && process.noDeprecation === true) {
      return fn;
    }
    if (typeof process === "undefined") {
      return function() {
        return exports.deprecate(fn, msg).apply(this, arguments);
      };
    }
    var warned = false;
    function deprecated2() {
      if (!warned) {
        if (process.throwDeprecation) {
          throw new Error(msg);
        } else if (process.traceDeprecation) {
          console.trace(msg);
        } else {
          console.error(msg);
        }
        warned = true;
      }
      return fn.apply(this, arguments);
    }
    return deprecated2;
  };
  var debugs = {};
  var debugEnvRegex = /^$/;
  exports.debuglog = function(set) {
    set = set.toUpperCase();
    if (!debugs[set]) {
      if (debugEnvRegex.test(set)) {
        var pid = process.pid;
        debugs[set] = function() {
          var msg = exports.format.apply(exports, arguments);
          console.error("%s %d: %s", set, pid, msg);
        };
      } else {
        debugs[set] = function() {
        };
      }
    }
    return debugs[set];
  };
  function inspect(obj, opts) {
    var ctx = {
      seen: [],
      stylize: stylizeNoColor
    };
    if (arguments.length >= 3)
      ctx.depth = arguments[2];
    if (arguments.length >= 4)
      ctx.colors = arguments[3];
    if (isBoolean2(opts)) {
      ctx.showHidden = opts;
    } else if (opts) {
      exports._extend(ctx, opts);
    }
    if (isUndefined(ctx.showHidden))
      ctx.showHidden = false;
    if (isUndefined(ctx.depth))
      ctx.depth = 2;
    if (isUndefined(ctx.colors))
      ctx.colors = false;
    if (isUndefined(ctx.customInspect))
      ctx.customInspect = true;
    if (ctx.colors)
      ctx.stylize = stylizeWithColor;
    return formatValue(ctx, obj, ctx.depth);
  }
  exports.inspect = inspect;
  inspect.colors = {
    bold: [1, 22],
    italic: [3, 23],
    underline: [4, 24],
    inverse: [7, 27],
    white: [37, 39],
    grey: [90, 39],
    black: [30, 39],
    blue: [34, 39],
    cyan: [36, 39],
    green: [32, 39],
    magenta: [35, 39],
    red: [31, 39],
    yellow: [33, 39]
  };
  inspect.styles = {
    special: "cyan",
    number: "yellow",
    boolean: "yellow",
    undefined: "grey",
    null: "bold",
    string: "green",
    date: "magenta",
    regexp: "red"
  };
  function stylizeWithColor(str, styleType) {
    var style = inspect.styles[styleType];
    if (style) {
      return "[" + inspect.colors[style][0] + "m" + str + "[" + inspect.colors[style][1] + "m";
    } else {
      return str;
    }
  }
  function stylizeNoColor(str, styleType) {
    return str;
  }
  function arrayToHash(array) {
    var hash = {};
    array.forEach(function(val, idx) {
      hash[val] = true;
    });
    return hash;
  }
  function formatValue(ctx, value, recurseTimes) {
    if (ctx.customInspect && value && isFunction2(value.inspect) && value.inspect !== exports.inspect && !(value.constructor && value.constructor.prototype === value)) {
      var ret = value.inspect(recurseTimes, ctx);
      if (!isString3(ret)) {
        ret = formatValue(ctx, ret, recurseTimes);
      }
      return ret;
    }
    var primitive = formatPrimitive(ctx, value);
    if (primitive) {
      return primitive;
    }
    var keys2 = Object.keys(value);
    var visibleKeys = arrayToHash(keys2);
    if (ctx.showHidden) {
      keys2 = Object.getOwnPropertyNames(value);
    }
    if (isError2(value) && (keys2.indexOf("message") >= 0 || keys2.indexOf("description") >= 0)) {
      return formatError(value);
    }
    if (keys2.length === 0) {
      if (isFunction2(value)) {
        var name2 = value.name ? ": " + value.name : "";
        return ctx.stylize("[Function" + name2 + "]", "special");
      }
      if (isRegExp2(value)) {
        return ctx.stylize(RegExp.prototype.toString.call(value), "regexp");
      }
      if (isDate2(value)) {
        return ctx.stylize(Date.prototype.toString.call(value), "date");
      }
      if (isError2(value)) {
        return formatError(value);
      }
    }
    var base = "", array = false, braces = ["{", "}"];
    if (isArray2(value)) {
      array = true;
      braces = ["[", "]"];
    }
    if (isFunction2(value)) {
      var n = value.name ? ": " + value.name : "";
      base = " [Function" + n + "]";
    }
    if (isRegExp2(value)) {
      base = " " + RegExp.prototype.toString.call(value);
    }
    if (isDate2(value)) {
      base = " " + Date.prototype.toUTCString.call(value);
    }
    if (isError2(value)) {
      base = " " + formatError(value);
    }
    if (keys2.length === 0 && (!array || value.length == 0)) {
      return braces[0] + base + braces[1];
    }
    if (recurseTimes < 0) {
      if (isRegExp2(value)) {
        return ctx.stylize(RegExp.prototype.toString.call(value), "regexp");
      } else {
        return ctx.stylize("[Object]", "special");
      }
    }
    ctx.seen.push(value);
    var output;
    if (array) {
      output = formatArray(ctx, value, recurseTimes, visibleKeys, keys2);
    } else {
      output = keys2.map(function(key) {
        return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
      });
    }
    ctx.seen.pop();
    return reduceToSingleString(output, base, braces);
  }
  function formatPrimitive(ctx, value) {
    if (isUndefined(value))
      return ctx.stylize("undefined", "undefined");
    if (isString3(value)) {
      var simple = "'" + JSON.stringify(value).replace(/^"|"$/g, "").replace(/'/g, "\\'").replace(/\\"/g, '"') + "'";
      return ctx.stylize(simple, "string");
    }
    if (isNumber2(value))
      return ctx.stylize("" + value, "number");
    if (isBoolean2(value))
      return ctx.stylize("" + value, "boolean");
    if (isNull(value))
      return ctx.stylize("null", "null");
  }
  function formatError(value) {
    return "[" + Error.prototype.toString.call(value) + "]";
  }
  function formatArray(ctx, value, recurseTimes, visibleKeys, keys2) {
    var output = [];
    for (var i = 0, l = value.length; i < l; ++i) {
      if (hasOwnProperty2(value, String(i))) {
        output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, String(i), true));
      } else {
        output.push("");
      }
    }
    keys2.forEach(function(key) {
      if (!key.match(/^\d+$/)) {
        output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, key, true));
      }
    });
    return output;
  }
  function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
    var name2, str, desc;
    desc = Object.getOwnPropertyDescriptor(value, key) || {value: value[key]};
    if (desc.get) {
      if (desc.set) {
        str = ctx.stylize("[Getter/Setter]", "special");
      } else {
        str = ctx.stylize("[Getter]", "special");
      }
    } else {
      if (desc.set) {
        str = ctx.stylize("[Setter]", "special");
      }
    }
    if (!hasOwnProperty2(visibleKeys, key)) {
      name2 = "[" + key + "]";
    }
    if (!str) {
      if (ctx.seen.indexOf(desc.value) < 0) {
        if (isNull(recurseTimes)) {
          str = formatValue(ctx, desc.value, null);
        } else {
          str = formatValue(ctx, desc.value, recurseTimes - 1);
        }
        if (str.indexOf("\n") > -1) {
          if (array) {
            str = str.split("\n").map(function(line) {
              return "  " + line;
            }).join("\n").substr(2);
          } else {
            str = "\n" + str.split("\n").map(function(line) {
              return "   " + line;
            }).join("\n");
          }
        }
      } else {
        str = ctx.stylize("[Circular]", "special");
      }
    }
    if (isUndefined(name2)) {
      if (array && key.match(/^\d+$/)) {
        return str;
      }
      name2 = JSON.stringify("" + key);
      if (name2.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
        name2 = name2.substr(1, name2.length - 2);
        name2 = ctx.stylize(name2, "name");
      } else {
        name2 = name2.replace(/'/g, "\\'").replace(/\\"/g, '"').replace(/(^"|"$)/g, "'");
        name2 = ctx.stylize(name2, "string");
      }
    }
    return name2 + ": " + str;
  }
  function reduceToSingleString(output, base, braces) {
    var length = output.reduce(function(prev, cur) {
      if (cur.indexOf("\n") >= 0)
        ;
      return prev + cur.replace(/\u001b\[\d\d?m/g, "").length + 1;
    }, 0);
    if (length > 60) {
      return braces[0] + (base === "" ? "" : base + "\n ") + " " + output.join(",\n  ") + " " + braces[1];
    }
    return braces[0] + base + " " + output.join(", ") + " " + braces[1];
  }
  exports.types = types;
  function isArray2(ar) {
    return Array.isArray(ar);
  }
  exports.isArray = isArray2;
  function isBoolean2(arg) {
    return typeof arg === "boolean";
  }
  exports.isBoolean = isBoolean2;
  function isNull(arg) {
    return arg === null;
  }
  exports.isNull = isNull;
  function isNullOrUndefined(arg) {
    return arg == null;
  }
  exports.isNullOrUndefined = isNullOrUndefined;
  function isNumber2(arg) {
    return typeof arg === "number";
  }
  exports.isNumber = isNumber2;
  function isString3(arg) {
    return typeof arg === "string";
  }
  exports.isString = isString3;
  function isSymbol2(arg) {
    return typeof arg === "symbol";
  }
  exports.isSymbol = isSymbol2;
  function isUndefined(arg) {
    return arg === void 0;
  }
  exports.isUndefined = isUndefined;
  function isRegExp2(re) {
    return isObject(re) && objectToString2(re) === "[object RegExp]";
  }
  exports.isRegExp = isRegExp2;
  exports.types.isRegExp = isRegExp2;
  function isObject(arg) {
    return typeof arg === "object" && arg !== null;
  }
  exports.isObject = isObject;
  function isDate2(d) {
    return isObject(d) && objectToString2(d) === "[object Date]";
  }
  exports.isDate = isDate2;
  exports.types.isDate = isDate2;
  function isError2(e) {
    return isObject(e) && (objectToString2(e) === "[object Error]" || e instanceof Error);
  }
  exports.isError = isError2;
  exports.types.isNativeError = isError2;
  function isFunction2(arg) {
    return typeof arg === "function";
  }
  exports.isFunction = isFunction2;
  function isPrimitive4(arg) {
    return arg === null || typeof arg === "boolean" || typeof arg === "number" || typeof arg === "string" || typeof arg === "symbol" || typeof arg === "undefined";
  }
  exports.isPrimitive = isPrimitive4;
  exports.isBuffer = isBufferBrowser;
  function objectToString2(o) {
    return Object.prototype.toString.call(o);
  }
  function pad(n) {
    return n < 10 ? "0" + n.toString(10) : n.toString(10);
  }
  var months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];
  function timestamp() {
    var d = new Date();
    var time = [
      pad(d.getHours()),
      pad(d.getMinutes()),
      pad(d.getSeconds())
    ].join(":");
    return [d.getDate(), months[d.getMonth()], time].join(" ");
  }
  exports.log = function() {
    console.log("%s - %s", timestamp(), exports.format.apply(exports, arguments));
  };
  exports.inherits = inherits_browser;
  exports._extend = function(origin, add) {
    if (!add || !isObject(add))
      return origin;
    var keys2 = Object.keys(add);
    var i = keys2.length;
    while (i--) {
      origin[keys2[i]] = add[keys2[i]];
    }
    return origin;
  };
  function hasOwnProperty2(obj, prop) {
    return Object.prototype.hasOwnProperty.call(obj, prop);
  }
  var kCustomPromisifiedSymbol = typeof Symbol !== "undefined" ? Symbol("util.promisify.custom") : void 0;
  exports.promisify = function promisify(original) {
    if (typeof original !== "function")
      throw new TypeError('The "original" argument must be of type Function');
    if (kCustomPromisifiedSymbol && original[kCustomPromisifiedSymbol]) {
      var fn = original[kCustomPromisifiedSymbol];
      if (typeof fn !== "function") {
        throw new TypeError('The "util.promisify.custom" argument must be of type Function');
      }
      Object.defineProperty(fn, kCustomPromisifiedSymbol, {
        value: fn,
        enumerable: false,
        writable: false,
        configurable: true
      });
      return fn;
    }
    function fn() {
      var promiseResolve, promiseReject;
      var promise = new Promise(function(resolve2, reject) {
        promiseResolve = resolve2;
        promiseReject = reject;
      });
      var args = [];
      for (var i = 0; i < arguments.length; i++) {
        args.push(arguments[i]);
      }
      args.push(function(err, value) {
        if (err) {
          promiseReject(err);
        } else {
          promiseResolve(value);
        }
      });
      try {
        original.apply(this, args);
      } catch (err) {
        promiseReject(err);
      }
      return promise;
    }
    Object.setPrototypeOf(fn, Object.getPrototypeOf(original));
    if (kCustomPromisifiedSymbol)
      Object.defineProperty(fn, kCustomPromisifiedSymbol, {
        value: fn,
        enumerable: false,
        writable: false,
        configurable: true
      });
    return Object.defineProperties(fn, getOwnPropertyDescriptors(original));
  };
  exports.promisify.custom = kCustomPromisifiedSymbol;
  function callbackifyOnRejected(reason, cb) {
    if (!reason) {
      var newReason = new Error("Promise was rejected with a falsy value");
      newReason.reason = reason;
      reason = newReason;
    }
    return cb(reason);
  }
  function callbackify(original) {
    if (typeof original !== "function") {
      throw new TypeError('The "original" argument must be of type Function');
    }
    function callbackified() {
      var args = [];
      for (var i = 0; i < arguments.length; i++) {
        args.push(arguments[i]);
      }
      var maybeCb = args.pop();
      if (typeof maybeCb !== "function") {
        throw new TypeError("The last argument must be of type Function");
      }
      var self2 = this;
      var cb = function() {
        return maybeCb.apply(self2, arguments);
      };
      original.apply(this, args).then(function(ret) {
        process.nextTick(cb.bind(null, null, ret));
      }, function(rej) {
        process.nextTick(callbackifyOnRejected.bind(null, rej, cb));
      });
    }
    Object.setPrototypeOf(callbackified, Object.getPrototypeOf(original));
    Object.defineProperties(callbackified, getOwnPropertyDescriptors(original));
    return callbackified;
  }
  exports.callbackify = callbackify;
});
/*! https://mths.be/punycode v1.3.2 by @mathias */
var punycode = createCommonjsModule(function(module, exports) {
  (function(root) {
    var freeExports = exports && !exports.nodeType && exports;
    var freeModule = module && !module.nodeType && module;
    var freeGlobal = typeof commonjsGlobal == "object" && commonjsGlobal;
    if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal || freeGlobal.self === freeGlobal) {
      root = freeGlobal;
    }
    var punycode2, maxInt = 2147483647, base = 36, tMin = 1, tMax = 26, skew = 38, damp = 700, initialBias = 72, initialN = 128, delimiter = "-", regexPunycode = /^xn--/, regexNonASCII = /[^\x20-\x7E]/, regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g, errors = {
      overflow: "Overflow: input needs wider integers to process",
      "not-basic": "Illegal input >= 0x80 (not a basic code point)",
      "invalid-input": "Invalid input"
    }, baseMinusTMin = base - tMin, floor4 = Math.floor, stringFromCharCode = String.fromCharCode, key;
    function error2(type) {
      throw RangeError(errors[type]);
    }
    function map(array, fn) {
      var length = array.length;
      var result = [];
      while (length--) {
        result[length] = fn(array[length]);
      }
      return result;
    }
    function mapDomain(string, fn) {
      var parts = string.split("@");
      var result = "";
      if (parts.length > 1) {
        result = parts[0] + "@";
        string = parts[1];
      }
      string = string.replace(regexSeparators, ".");
      var labels = string.split(".");
      var encoded = map(labels, fn).join(".");
      return result + encoded;
    }
    function ucs2decode(string) {
      var output = [], counter = 0, length = string.length, value, extra;
      while (counter < length) {
        value = string.charCodeAt(counter++);
        if (value >= 55296 && value <= 56319 && counter < length) {
          extra = string.charCodeAt(counter++);
          if ((extra & 64512) == 56320) {
            output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
          } else {
            output.push(value);
            counter--;
          }
        } else {
          output.push(value);
        }
      }
      return output;
    }
    function ucs2encode(array) {
      return map(array, function(value) {
        var output = "";
        if (value > 65535) {
          value -= 65536;
          output += stringFromCharCode(value >>> 10 & 1023 | 55296);
          value = 56320 | value & 1023;
        }
        output += stringFromCharCode(value);
        return output;
      }).join("");
    }
    function basicToDigit(codePoint) {
      if (codePoint - 48 < 10) {
        return codePoint - 22;
      }
      if (codePoint - 65 < 26) {
        return codePoint - 65;
      }
      if (codePoint - 97 < 26) {
        return codePoint - 97;
      }
      return base;
    }
    function digitToBasic(digit, flag) {
      return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
    }
    function adapt(delta, numPoints, firstTime) {
      var k = 0;
      delta = firstTime ? floor4(delta / damp) : delta >> 1;
      delta += floor4(delta / numPoints);
      for (; delta > baseMinusTMin * tMax >> 1; k += base) {
        delta = floor4(delta / baseMinusTMin);
      }
      return floor4(k + (baseMinusTMin + 1) * delta / (delta + skew));
    }
    function decode2(input) {
      var output = [], inputLength = input.length, out, i = 0, n = initialN, bias = initialBias, basic, j, index2, oldi, w, k, digit, t, baseMinusT;
      basic = input.lastIndexOf(delimiter);
      if (basic < 0) {
        basic = 0;
      }
      for (j = 0; j < basic; ++j) {
        if (input.charCodeAt(j) >= 128) {
          error2("not-basic");
        }
        output.push(input.charCodeAt(j));
      }
      for (index2 = basic > 0 ? basic + 1 : 0; index2 < inputLength; ) {
        for (oldi = i, w = 1, k = base; ; k += base) {
          if (index2 >= inputLength) {
            error2("invalid-input");
          }
          digit = basicToDigit(input.charCodeAt(index2++));
          if (digit >= base || digit > floor4((maxInt - i) / w)) {
            error2("overflow");
          }
          i += digit * w;
          t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
          if (digit < t) {
            break;
          }
          baseMinusT = base - t;
          if (w > floor4(maxInt / baseMinusT)) {
            error2("overflow");
          }
          w *= baseMinusT;
        }
        out = output.length + 1;
        bias = adapt(i - oldi, out, oldi == 0);
        if (floor4(i / out) > maxInt - n) {
          error2("overflow");
        }
        n += floor4(i / out);
        i %= out;
        output.splice(i++, 0, n);
      }
      return ucs2encode(output);
    }
    function encode2(input) {
      var n, delta, handledCPCount, basicLength, bias, j, m, q, k, t, currentValue, output = [], inputLength, handledCPCountPlusOne, baseMinusT, qMinusT;
      input = ucs2decode(input);
      inputLength = input.length;
      n = initialN;
      delta = 0;
      bias = initialBias;
      for (j = 0; j < inputLength; ++j) {
        currentValue = input[j];
        if (currentValue < 128) {
          output.push(stringFromCharCode(currentValue));
        }
      }
      handledCPCount = basicLength = output.length;
      if (basicLength) {
        output.push(delimiter);
      }
      while (handledCPCount < inputLength) {
        for (m = maxInt, j = 0; j < inputLength; ++j) {
          currentValue = input[j];
          if (currentValue >= n && currentValue < m) {
            m = currentValue;
          }
        }
        handledCPCountPlusOne = handledCPCount + 1;
        if (m - n > floor4((maxInt - delta) / handledCPCountPlusOne)) {
          error2("overflow");
        }
        delta += (m - n) * handledCPCountPlusOne;
        n = m;
        for (j = 0; j < inputLength; ++j) {
          currentValue = input[j];
          if (currentValue < n && ++delta > maxInt) {
            error2("overflow");
          }
          if (currentValue == n) {
            for (q = delta, k = base; ; k += base) {
              t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
              if (q < t) {
                break;
              }
              qMinusT = q - t;
              baseMinusT = base - t;
              output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0)));
              q = floor4(qMinusT / baseMinusT);
            }
            output.push(stringFromCharCode(digitToBasic(q, 0)));
            bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
            delta = 0;
            ++handledCPCount;
          }
        }
        ++delta;
        ++n;
      }
      return output.join("");
    }
    function toUnicode(input) {
      return mapDomain(input, function(string) {
        return regexPunycode.test(string) ? decode2(string.slice(4).toLowerCase()) : string;
      });
    }
    function toASCII(input) {
      return mapDomain(input, function(string) {
        return regexNonASCII.test(string) ? "xn--" + encode2(string) : string;
      });
    }
    punycode2 = {
      version: "1.3.2",
      ucs2: {
        decode: ucs2decode,
        encode: ucs2encode
      },
      decode: decode2,
      encode: encode2,
      toASCII,
      toUnicode
    };
    if (freeExports && freeModule) {
      if (module.exports == freeExports) {
        freeModule.exports = punycode2;
      } else {
        for (key in punycode2) {
          punycode2.hasOwnProperty(key) && (freeExports[key] = punycode2[key]);
        }
      }
    } else {
      root.punycode = punycode2;
    }
  })(commonjsGlobal);
});
var util = {
  isString: function(arg) {
    return typeof arg === "string";
  },
  isObject: function(arg) {
    return typeof arg === "object" && arg !== null;
  },
  isNull: function(arg) {
    return arg === null;
  },
  isNullOrUndefined: function(arg) {
    return arg == null;
  }
};
function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}
var decode = function(qs, sep, eq, options) {
  sep = sep || "&";
  eq = eq || "=";
  var obj = {};
  if (typeof qs !== "string" || qs.length === 0) {
    return obj;
  }
  var regexp = /\+/g;
  qs = qs.split(sep);
  var maxKeys = 1e3;
  if (options && typeof options.maxKeys === "number") {
    maxKeys = options.maxKeys;
  }
  var len = qs.length;
  if (maxKeys > 0 && len > maxKeys) {
    len = maxKeys;
  }
  for (var i = 0; i < len; ++i) {
    var x = qs[i].replace(regexp, "%20"), idx = x.indexOf(eq), kstr, vstr, k, v;
    if (idx >= 0) {
      kstr = x.substr(0, idx);
      vstr = x.substr(idx + 1);
    } else {
      kstr = x;
      vstr = "";
    }
    k = decodeURIComponent(kstr);
    v = decodeURIComponent(vstr);
    if (!hasOwnProperty(obj, k)) {
      obj[k] = v;
    } else if (Array.isArray(obj[k])) {
      obj[k].push(v);
    } else {
      obj[k] = [obj[k], v];
    }
  }
  return obj;
};
var stringifyPrimitive$1 = function(v) {
  switch (typeof v) {
    case "string":
      return v;
    case "boolean":
      return v ? "true" : "false";
    case "number":
      return isFinite(v) ? v : "";
    default:
      return "";
  }
};
var encode = function(obj, sep, eq, name2) {
  sep = sep || "&";
  eq = eq || "=";
  if (obj === null) {
    obj = void 0;
  }
  if (typeof obj === "object") {
    return Object.keys(obj).map(function(k) {
      var ks = encodeURIComponent(stringifyPrimitive$1(k)) + eq;
      if (Array.isArray(obj[k])) {
        return obj[k].map(function(v) {
          return ks + encodeURIComponent(stringifyPrimitive$1(v));
        }).join(sep);
      } else {
        return ks + encodeURIComponent(stringifyPrimitive$1(obj[k]));
      }
    }).join(sep);
  }
  if (!name2)
    return "";
  return encodeURIComponent(stringifyPrimitive$1(name2)) + eq + encodeURIComponent(stringifyPrimitive$1(obj));
};
var C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_querystring = createCommonjsModule(function(module, exports) {
  exports.decode = exports.parse = decode;
  exports.encode = exports.stringify = encode;
});
var parse = urlParse;
var resolve = urlResolve;
var resolveObject = urlResolveObject;
var format = urlFormat;
var Url_1 = Url;
function Url() {
  this.protocol = null;
  this.slashes = null;
  this.auth = null;
  this.host = null;
  this.port = null;
  this.hostname = null;
  this.hash = null;
  this.search = null;
  this.query = null;
  this.pathname = null;
  this.path = null;
  this.href = null;
}
var protocolPattern = /^([a-z0-9.+-]+:)/i, portPattern = /:[0-9]*$/, simplePathPattern = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/, delims = ["<", ">", '"', "`", " ", "\r", "\n", "	"], unwise = ["{", "}", "|", "\\", "^", "`"].concat(delims), autoEscape = ["'"].concat(unwise), nonHostChars = ["%", "/", "?", ";", "#"].concat(autoEscape), hostEndingChars = ["/", "?", "#"], hostnameMaxLen = 255, hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/, hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/, unsafeProtocol = {
  javascript: true,
  "javascript:": true
}, hostlessProtocol = {
  javascript: true,
  "javascript:": true
}, slashedProtocol = {
  http: true,
  https: true,
  ftp: true,
  gopher: true,
  file: true,
  "http:": true,
  "https:": true,
  "ftp:": true,
  "gopher:": true,
  "file:": true
};
function urlParse(url2, parseQueryString, slashesDenoteHost) {
  if (url2 && util.isObject(url2) && url2 instanceof Url)
    return url2;
  var u = new Url();
  u.parse(url2, parseQueryString, slashesDenoteHost);
  return u;
}
Url.prototype.parse = function(url2, parseQueryString, slashesDenoteHost) {
  if (!util.isString(url2)) {
    throw new TypeError("Parameter 'url' must be a string, not " + typeof url2);
  }
  var queryIndex = url2.indexOf("?"), splitter = queryIndex !== -1 && queryIndex < url2.indexOf("#") ? "?" : "#", uSplit = url2.split(splitter), slashRegex = /\\/g;
  uSplit[0] = uSplit[0].replace(slashRegex, "/");
  url2 = uSplit.join(splitter);
  var rest = url2;
  rest = rest.trim();
  if (!slashesDenoteHost && url2.split("#").length === 1) {
    var simplePath = simplePathPattern.exec(rest);
    if (simplePath) {
      this.path = rest;
      this.href = rest;
      this.pathname = simplePath[1];
      if (simplePath[2]) {
        this.search = simplePath[2];
        if (parseQueryString) {
          this.query = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_querystring.parse(this.search.substr(1));
        } else {
          this.query = this.search.substr(1);
        }
      } else if (parseQueryString) {
        this.search = "";
        this.query = {};
      }
      return this;
    }
  }
  var proto = protocolPattern.exec(rest);
  if (proto) {
    proto = proto[0];
    var lowerProto = proto.toLowerCase();
    this.protocol = lowerProto;
    rest = rest.substr(proto.length);
  }
  if (slashesDenoteHost || proto || rest.match(/^\/\/[^@\/]+@[^@\/]+/)) {
    var slashes = rest.substr(0, 2) === "//";
    if (slashes && !(proto && hostlessProtocol[proto])) {
      rest = rest.substr(2);
      this.slashes = true;
    }
  }
  if (!hostlessProtocol[proto] && (slashes || proto && !slashedProtocol[proto])) {
    var hostEnd = -1;
    for (var i = 0; i < hostEndingChars.length; i++) {
      var hec = rest.indexOf(hostEndingChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
        hostEnd = hec;
    }
    var auth, atSign;
    if (hostEnd === -1) {
      atSign = rest.lastIndexOf("@");
    } else {
      atSign = rest.lastIndexOf("@", hostEnd);
    }
    if (atSign !== -1) {
      auth = rest.slice(0, atSign);
      rest = rest.slice(atSign + 1);
      this.auth = decodeURIComponent(auth);
    }
    hostEnd = -1;
    for (var i = 0; i < nonHostChars.length; i++) {
      var hec = rest.indexOf(nonHostChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
        hostEnd = hec;
    }
    if (hostEnd === -1)
      hostEnd = rest.length;
    this.host = rest.slice(0, hostEnd);
    rest = rest.slice(hostEnd);
    this.parseHost();
    this.hostname = this.hostname || "";
    var ipv6Hostname = this.hostname[0] === "[" && this.hostname[this.hostname.length - 1] === "]";
    if (!ipv6Hostname) {
      var hostparts = this.hostname.split(/\./);
      for (var i = 0, l = hostparts.length; i < l; i++) {
        var part = hostparts[i];
        if (!part)
          continue;
        if (!part.match(hostnamePartPattern)) {
          var newpart = "";
          for (var j = 0, k = part.length; j < k; j++) {
            if (part.charCodeAt(j) > 127) {
              newpart += "x";
            } else {
              newpart += part[j];
            }
          }
          if (!newpart.match(hostnamePartPattern)) {
            var validParts = hostparts.slice(0, i);
            var notHost = hostparts.slice(i + 1);
            var bit = part.match(hostnamePartStart);
            if (bit) {
              validParts.push(bit[1]);
              notHost.unshift(bit[2]);
            }
            if (notHost.length) {
              rest = "/" + notHost.join(".") + rest;
            }
            this.hostname = validParts.join(".");
            break;
          }
        }
      }
    }
    if (this.hostname.length > hostnameMaxLen) {
      this.hostname = "";
    } else {
      this.hostname = this.hostname.toLowerCase();
    }
    if (!ipv6Hostname) {
      this.hostname = punycode.toASCII(this.hostname);
    }
    var p = this.port ? ":" + this.port : "";
    var h = this.hostname || "";
    this.host = h + p;
    this.href += this.host;
    if (ipv6Hostname) {
      this.hostname = this.hostname.substr(1, this.hostname.length - 2);
      if (rest[0] !== "/") {
        rest = "/" + rest;
      }
    }
  }
  if (!unsafeProtocol[lowerProto]) {
    for (var i = 0, l = autoEscape.length; i < l; i++) {
      var ae = autoEscape[i];
      if (rest.indexOf(ae) === -1)
        continue;
      var esc = encodeURIComponent(ae);
      if (esc === ae) {
        esc = escape(ae);
      }
      rest = rest.split(ae).join(esc);
    }
  }
  var hash = rest.indexOf("#");
  if (hash !== -1) {
    this.hash = rest.substr(hash);
    rest = rest.slice(0, hash);
  }
  var qm = rest.indexOf("?");
  if (qm !== -1) {
    this.search = rest.substr(qm);
    this.query = rest.substr(qm + 1);
    if (parseQueryString) {
      this.query = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_querystring.parse(this.query);
    }
    rest = rest.slice(0, qm);
  } else if (parseQueryString) {
    this.search = "";
    this.query = {};
  }
  if (rest)
    this.pathname = rest;
  if (slashedProtocol[lowerProto] && this.hostname && !this.pathname) {
    this.pathname = "/";
  }
  if (this.pathname || this.search) {
    var p = this.pathname || "";
    var s2 = this.search || "";
    this.path = p + s2;
  }
  this.href = this.format();
  return this;
};
function urlFormat(obj) {
  if (util.isString(obj))
    obj = urlParse(obj);
  if (!(obj instanceof Url))
    return Url.prototype.format.call(obj);
  return obj.format();
}
Url.prototype.format = function() {
  var auth = this.auth || "";
  if (auth) {
    auth = encodeURIComponent(auth);
    auth = auth.replace(/%3A/i, ":");
    auth += "@";
  }
  var protocol = this.protocol || "", pathname = this.pathname || "", hash = this.hash || "", host = false, query = "";
  if (this.host) {
    host = auth + this.host;
  } else if (this.hostname) {
    host = auth + (this.hostname.indexOf(":") === -1 ? this.hostname : "[" + this.hostname + "]");
    if (this.port) {
      host += ":" + this.port;
    }
  }
  if (this.query && util.isObject(this.query) && Object.keys(this.query).length) {
    query = C__Users_eloua_Documents_Projet_Transverse_Test_LesPeresCastors__node_modules_querystring.stringify(this.query);
  }
  var search = this.search || query && "?" + query || "";
  if (protocol && protocol.substr(-1) !== ":")
    protocol += ":";
  if (this.slashes || (!protocol || slashedProtocol[protocol]) && host !== false) {
    host = "//" + (host || "");
    if (pathname && pathname.charAt(0) !== "/")
      pathname = "/" + pathname;
  } else if (!host) {
    host = "";
  }
  if (hash && hash.charAt(0) !== "#")
    hash = "#" + hash;
  if (search && search.charAt(0) !== "?")
    search = "?" + search;
  pathname = pathname.replace(/[?#]/g, function(match2) {
    return encodeURIComponent(match2);
  });
  search = search.replace("#", "%23");
  return protocol + host + pathname + search + hash;
};
function urlResolve(source, relative) {
  return urlParse(source, false, true).resolve(relative);
}
Url.prototype.resolve = function(relative) {
  return this.resolveObject(urlParse(relative, false, true)).format();
};
function urlResolveObject(source, relative) {
  if (!source)
    return relative;
  return urlParse(source, false, true).resolveObject(relative);
}
Url.prototype.resolveObject = function(relative) {
  if (util.isString(relative)) {
    var rel = new Url();
    rel.parse(relative, false, true);
    relative = rel;
  }
  var result = new Url();
  var tkeys = Object.keys(this);
  for (var tk = 0; tk < tkeys.length; tk++) {
    var tkey = tkeys[tk];
    result[tkey] = this[tkey];
  }
  result.hash = relative.hash;
  if (relative.href === "") {
    result.href = result.format();
    return result;
  }
  if (relative.slashes && !relative.protocol) {
    var rkeys = Object.keys(relative);
    for (var rk = 0; rk < rkeys.length; rk++) {
      var rkey = rkeys[rk];
      if (rkey !== "protocol")
        result[rkey] = relative[rkey];
    }
    if (slashedProtocol[result.protocol] && result.hostname && !result.pathname) {
      result.path = result.pathname = "/";
    }
    result.href = result.format();
    return result;
  }
  if (relative.protocol && relative.protocol !== result.protocol) {
    if (!slashedProtocol[relative.protocol]) {
      var keys2 = Object.keys(relative);
      for (var v = 0; v < keys2.length; v++) {
        var k = keys2[v];
        result[k] = relative[k];
      }
      result.href = result.format();
      return result;
    }
    result.protocol = relative.protocol;
    if (!relative.host && !hostlessProtocol[relative.protocol]) {
      var relPath = (relative.pathname || "").split("/");
      while (relPath.length && !(relative.host = relPath.shift()))
        ;
      if (!relative.host)
        relative.host = "";
      if (!relative.hostname)
        relative.hostname = "";
      if (relPath[0] !== "")
        relPath.unshift("");
      if (relPath.length < 2)
        relPath.unshift("");
      result.pathname = relPath.join("/");
    } else {
      result.pathname = relative.pathname;
    }
    result.search = relative.search;
    result.query = relative.query;
    result.host = relative.host || "";
    result.auth = relative.auth;
    result.hostname = relative.hostname || relative.host;
    result.port = relative.port;
    if (result.pathname || result.search) {
      var p = result.pathname || "";
      var s2 = result.search || "";
      result.path = p + s2;
    }
    result.slashes = result.slashes || relative.slashes;
    result.href = result.format();
    return result;
  }
  var isSourceAbs = result.pathname && result.pathname.charAt(0) === "/", isRelAbs = relative.host || relative.pathname && relative.pathname.charAt(0) === "/", mustEndAbs = isRelAbs || isSourceAbs || result.host && relative.pathname, removeAllDots = mustEndAbs, srcPath = result.pathname && result.pathname.split("/") || [], relPath = relative.pathname && relative.pathname.split("/") || [], psychotic = result.protocol && !slashedProtocol[result.protocol];
  if (psychotic) {
    result.hostname = "";
    result.port = null;
    if (result.host) {
      if (srcPath[0] === "")
        srcPath[0] = result.host;
      else
        srcPath.unshift(result.host);
    }
    result.host = "";
    if (relative.protocol) {
      relative.hostname = null;
      relative.port = null;
      if (relative.host) {
        if (relPath[0] === "")
          relPath[0] = relative.host;
        else
          relPath.unshift(relative.host);
      }
      relative.host = null;
    }
    mustEndAbs = mustEndAbs && (relPath[0] === "" || srcPath[0] === "");
  }
  if (isRelAbs) {
    result.host = relative.host || relative.host === "" ? relative.host : result.host;
    result.hostname = relative.hostname || relative.hostname === "" ? relative.hostname : result.hostname;
    result.search = relative.search;
    result.query = relative.query;
    srcPath = relPath;
  } else if (relPath.length) {
    if (!srcPath)
      srcPath = [];
    srcPath.pop();
    srcPath = srcPath.concat(relPath);
    result.search = relative.search;
    result.query = relative.query;
  } else if (!util.isNullOrUndefined(relative.search)) {
    if (psychotic) {
      result.hostname = result.host = srcPath.shift();
      var authInHost = result.host && result.host.indexOf("@") > 0 ? result.host.split("@") : false;
      if (authInHost) {
        result.auth = authInHost.shift();
        result.host = result.hostname = authInHost.shift();
      }
    }
    result.search = relative.search;
    result.query = relative.query;
    if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
      result.path = (result.pathname ? result.pathname : "") + (result.search ? result.search : "");
    }
    result.href = result.format();
    return result;
  }
  if (!srcPath.length) {
    result.pathname = null;
    if (result.search) {
      result.path = "/" + result.search;
    } else {
      result.path = null;
    }
    result.href = result.format();
    return result;
  }
  var last = srcPath.slice(-1)[0];
  var hasTrailingSlash = (result.host || relative.host || srcPath.length > 1) && (last === "." || last === "..") || last === "";
  var up = 0;
  for (var i = srcPath.length; i >= 0; i--) {
    last = srcPath[i];
    if (last === ".") {
      srcPath.splice(i, 1);
    } else if (last === "..") {
      srcPath.splice(i, 1);
      up++;
    } else if (up) {
      srcPath.splice(i, 1);
      up--;
    }
  }
  if (!mustEndAbs && !removeAllDots) {
    for (; up--; up) {
      srcPath.unshift("..");
    }
  }
  if (mustEndAbs && srcPath[0] !== "" && (!srcPath[0] || srcPath[0].charAt(0) !== "/")) {
    srcPath.unshift("");
  }
  if (hasTrailingSlash && srcPath.join("/").substr(-1) !== "/") {
    srcPath.push("");
  }
  var isAbsolute = srcPath[0] === "" || srcPath[0] && srcPath[0].charAt(0) === "/";
  if (psychotic) {
    result.hostname = result.host = isAbsolute ? "" : srcPath.length ? srcPath.shift() : "";
    var authInHost = result.host && result.host.indexOf("@") > 0 ? result.host.split("@") : false;
    if (authInHost) {
      result.auth = authInHost.shift();
      result.host = result.hostname = authInHost.shift();
    }
  }
  mustEndAbs = mustEndAbs || result.host && srcPath.length;
  if (mustEndAbs && !isAbsolute) {
    srcPath.unshift("");
  }
  if (!srcPath.length) {
    result.pathname = null;
    result.path = null;
  } else {
    result.pathname = srcPath.join("/");
  }
  if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
    result.path = (result.pathname ? result.pathname : "") + (result.search ? result.search : "");
  }
  result.auth = relative.auth || result.auth;
  result.slashes = result.slashes || relative.slashes;
  result.href = result.format();
  return result;
};
Url.prototype.parseHost = function() {
  var host = this.host;
  var port = portPattern.exec(host);
  if (port) {
    port = port[0];
    if (port !== ":") {
      this.port = port.substr(1);
    }
    host = host.substr(0, host.length - port.length);
  }
  if (host)
    this.hostname = host;
};
var url = {
  parse,
  resolve,
  resolveObject,
  format,
  Url: Url_1
};
var chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$";
var unsafeChars = /[<>\b\f\n\r\t\0\u2028\u2029]/g;
var reserved = /^(?:do|if|in|for|int|let|new|try|var|byte|case|char|else|enum|goto|long|this|void|with|await|break|catch|class|const|final|float|short|super|throw|while|yield|delete|double|export|import|native|return|switch|throws|typeof|boolean|default|extends|finally|package|private|abstract|continue|debugger|function|volatile|interface|protected|transient|implements|instanceof|synchronized)$/;
var escaped$1 = {
  "<": "\\u003C",
  ">": "\\u003E",
  "/": "\\u002F",
  "\\": "\\\\",
  "\b": "\\b",
  "\f": "\\f",
  "\n": "\\n",
  "\r": "\\r",
  "	": "\\t",
  "\0": "\\0",
  "\u2028": "\\u2028",
  "\u2029": "\\u2029"
};
var objectProtoOwnPropertyNames = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
function devalue(value) {
  var counts = new Map();
  function walk(thing) {
    if (typeof thing === "function") {
      throw new Error("Cannot stringify a function");
    }
    if (counts.has(thing)) {
      counts.set(thing, counts.get(thing) + 1);
      return;
    }
    counts.set(thing, 1);
    if (!isPrimitive3(thing)) {
      var type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
        case "Date":
        case "RegExp":
          return;
        case "Array":
          thing.forEach(walk);
          break;
        case "Set":
        case "Map":
          Array.from(thing).forEach(walk);
          break;
        default:
          var proto = Object.getPrototypeOf(thing);
          if (proto !== Object.prototype && proto !== null && Object.getOwnPropertyNames(proto).sort().join("\0") !== objectProtoOwnPropertyNames) {
            throw new Error("Cannot stringify arbitrary non-POJOs");
          }
          if (Object.getOwnPropertySymbols(thing).length > 0) {
            throw new Error("Cannot stringify POJOs with symbolic keys");
          }
          Object.keys(thing).forEach(function(key) {
            return walk(thing[key]);
          });
      }
    }
  }
  walk(value);
  var names = new Map();
  Array.from(counts).filter(function(entry) {
    return entry[1] > 1;
  }).sort(function(a, b) {
    return b[1] - a[1];
  }).forEach(function(entry, i) {
    names.set(entry[0], getName(i));
  });
  function stringify(thing) {
    if (names.has(thing)) {
      return names.get(thing);
    }
    if (isPrimitive3(thing)) {
      return stringifyPrimitive(thing);
    }
    var type = getType(thing);
    switch (type) {
      case "Number":
      case "String":
      case "Boolean":
        return "Object(" + stringify(thing.valueOf()) + ")";
      case "RegExp":
        return "new RegExp(" + stringifyString(thing.source) + ', "' + thing.flags + '")';
      case "Date":
        return "new Date(" + thing.getTime() + ")";
      case "Array":
        var members = thing.map(function(v, i) {
          return i in thing ? stringify(v) : "";
        });
        var tail = thing.length === 0 || thing.length - 1 in thing ? "" : ",";
        return "[" + members.join(",") + tail + "]";
      case "Set":
      case "Map":
        return "new " + type + "([" + Array.from(thing).map(stringify).join(",") + "])";
      default:
        var obj = "{" + Object.keys(thing).map(function(key) {
          return safeKey(key) + ":" + stringify(thing[key]);
        }).join(",") + "}";
        var proto = Object.getPrototypeOf(thing);
        if (proto === null) {
          return Object.keys(thing).length > 0 ? "Object.assign(Object.create(null)," + obj + ")" : "Object.create(null)";
        }
        return obj;
    }
  }
  var str = stringify(value);
  if (names.size) {
    var params_1 = [];
    var statements_1 = [];
    var values_1 = [];
    names.forEach(function(name2, thing) {
      params_1.push(name2);
      if (isPrimitive3(thing)) {
        values_1.push(stringifyPrimitive(thing));
        return;
      }
      var type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
          values_1.push("Object(" + stringify(thing.valueOf()) + ")");
          break;
        case "RegExp":
          values_1.push(thing.toString());
          break;
        case "Date":
          values_1.push("new Date(" + thing.getTime() + ")");
          break;
        case "Array":
          values_1.push("Array(" + thing.length + ")");
          thing.forEach(function(v, i) {
            statements_1.push(name2 + "[" + i + "]=" + stringify(v));
          });
          break;
        case "Set":
          values_1.push("new Set");
          statements_1.push(name2 + "." + Array.from(thing).map(function(v) {
            return "add(" + stringify(v) + ")";
          }).join("."));
          break;
        case "Map":
          values_1.push("new Map");
          statements_1.push(name2 + "." + Array.from(thing).map(function(_a) {
            var k = _a[0], v = _a[1];
            return "set(" + stringify(k) + ", " + stringify(v) + ")";
          }).join("."));
          break;
        default:
          values_1.push(Object.getPrototypeOf(thing) === null ? "Object.create(null)" : "{}");
          Object.keys(thing).forEach(function(key) {
            statements_1.push("" + name2 + safeProp(key) + "=" + stringify(thing[key]));
          });
      }
    });
    statements_1.push("return " + str);
    return "(function(" + params_1.join(",") + "){" + statements_1.join(";") + "}(" + values_1.join(",") + "))";
  } else {
    return str;
  }
}
function getName(num) {
  var name2 = "";
  do {
    name2 = chars[num % chars.length] + name2;
    num = ~~(num / chars.length) - 1;
  } while (num >= 0);
  return reserved.test(name2) ? name2 + "_" : name2;
}
function isPrimitive3(thing) {
  return Object(thing) !== thing;
}
function stringifyPrimitive(thing) {
  if (typeof thing === "string")
    return stringifyString(thing);
  if (thing === void 0)
    return "void 0";
  if (thing === 0 && 1 / thing < 0)
    return "-0";
  var str = String(thing);
  if (typeof thing === "number")
    return str.replace(/^(-)?0\./, "$1.");
  return str;
}
function getType(thing) {
  return Object.prototype.toString.call(thing).slice(8, -1);
}
function escapeUnsafeChar(c) {
  return escaped$1[c] || c;
}
function escapeUnsafeChars(str) {
  return str.replace(unsafeChars, escapeUnsafeChar);
}
function safeKey(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? key : escapeUnsafeChars(JSON.stringify(key));
}
function safeProp(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? "." + key : "[" + escapeUnsafeChars(JSON.stringify(key)) + "]";
}
function stringifyString(str) {
  var result = '"';
  for (var i = 0; i < str.length; i += 1) {
    var char = str.charAt(i);
    var code = char.charCodeAt(0);
    if (char === '"') {
      result += '\\"';
    } else if (char in escaped$1) {
      result += escaped$1[char];
    } else if (code >= 55296 && code <= 57343) {
      var next = str.charCodeAt(i + 1);
      if (code <= 56319 && (next >= 56320 && next <= 57343)) {
        result += char + str[++i];
      } else {
        result += "\\u" + code.toString(16).toUpperCase();
      }
    } else {
      result += char;
    }
  }
  result += '"';
  return result;
}
function dataUriToBuffer(uri) {
  if (!/^data:/i.test(uri)) {
    throw new TypeError('`uri` does not appear to be a Data URI (must begin with "data:")');
  }
  uri = uri.replace(/\r?\n/g, "");
  const firstComma = uri.indexOf(",");
  if (firstComma === -1 || firstComma <= 4) {
    throw new TypeError("malformed data: URI");
  }
  const meta = uri.substring(5, firstComma).split(";");
  let charset = "";
  let base64 = false;
  const type = meta[0] || "text/plain";
  let typeFull = type;
  for (let i = 1; i < meta.length; i++) {
    if (meta[i] === "base64") {
      base64 = true;
    } else {
      typeFull += `;${meta[i]}`;
      if (meta[i].indexOf("charset=") === 0) {
        charset = meta[i].substring(8);
      }
    }
  }
  if (!meta[0] && !charset.length) {
    typeFull += ";charset=US-ASCII";
    charset = "US-ASCII";
  }
  const encoding = base64 ? "base64" : "ascii";
  const data = unescape(uri.substring(firstComma + 1));
  const buffer = Buffer.from(data, encoding);
  buffer.type = type;
  buffer.typeFull = typeFull;
  buffer.charset = charset;
  return buffer;
}
var src = dataUriToBuffer;
const {Readable} = Stream;
const wm = new WeakMap();
async function* read(parts) {
  for (const part of parts) {
    if ("stream" in part) {
      yield* part.stream();
    } else {
      yield part;
    }
  }
}
class Blob$1 {
  constructor(blobParts = [], options = {type: ""}) {
    let size = 0;
    const parts = blobParts.map((element) => {
      let buffer;
      if (element instanceof Buffer) {
        buffer = element;
      } else if (ArrayBuffer.isView(element)) {
        buffer = Buffer.from(element.buffer, element.byteOffset, element.byteLength);
      } else if (element instanceof ArrayBuffer) {
        buffer = Buffer.from(element);
      } else if (element instanceof Blob$1) {
        buffer = element;
      } else {
        buffer = Buffer.from(typeof element === "string" ? element : String(element));
      }
      size += buffer.length || buffer.size || 0;
      return buffer;
    });
    const type = options.type === void 0 ? "" : String(options.type).toLowerCase();
    wm.set(this, {
      type: /[^\u0020-\u007E]/.test(type) ? "" : type,
      size,
      parts
    });
  }
  get size() {
    return wm.get(this).size;
  }
  get type() {
    return wm.get(this).type;
  }
  async text() {
    return Buffer.from(await this.arrayBuffer()).toString();
  }
  async arrayBuffer() {
    const data = new Uint8Array(this.size);
    let offset = 0;
    for await (const chunk of this.stream()) {
      data.set(chunk, offset);
      offset += chunk.length;
    }
    return data.buffer;
  }
  stream() {
    return Readable.from(read(wm.get(this).parts));
  }
  slice(start = 0, end = this.size, type = "") {
    const {size} = this;
    let relativeStart = start < 0 ? Math.max(size + start, 0) : Math.min(start, size);
    let relativeEnd = end < 0 ? Math.max(size + end, 0) : Math.min(end, size);
    const span = Math.max(relativeEnd - relativeStart, 0);
    const parts = wm.get(this).parts.values();
    const blobParts = [];
    let added = 0;
    for (const part of parts) {
      const size2 = ArrayBuffer.isView(part) ? part.byteLength : part.size;
      if (relativeStart && size2 <= relativeStart) {
        relativeStart -= size2;
        relativeEnd -= size2;
      } else {
        const chunk = part.slice(relativeStart, Math.min(size2, relativeEnd));
        blobParts.push(chunk);
        added += ArrayBuffer.isView(chunk) ? chunk.byteLength : chunk.size;
        relativeStart = 0;
        if (added >= span) {
          break;
        }
      }
    }
    const blob = new Blob$1([], {type});
    Object.assign(wm.get(blob), {size: span, parts: blobParts});
    return blob;
  }
  get [Symbol.toStringTag]() {
    return "Blob";
  }
  static [Symbol.hasInstance](object) {
    return typeof object === "object" && typeof object.stream === "function" && object.stream.length === 0 && typeof object.constructor === "function" && /^(Blob|File)$/.test(object[Symbol.toStringTag]);
  }
}
Object.defineProperties(Blob$1.prototype, {
  size: {enumerable: true},
  type: {enumerable: true},
  slice: {enumerable: true}
});
var fetchBlob = Blob$1;
class FetchBaseError extends Error {
  constructor(message, type) {
    super(message);
    Error.captureStackTrace(this, this.constructor);
    this.type = type;
  }
  get name() {
    return this.constructor.name;
  }
  get [Symbol.toStringTag]() {
    return this.constructor.name;
  }
}
class FetchError extends FetchBaseError {
  constructor(message, type, systemError) {
    super(message, type);
    if (systemError) {
      this.code = this.errno = systemError.code;
      this.erroredSysCall = systemError.syscall;
    }
  }
}
const NAME = Symbol.toStringTag;
const isURLSearchParameters = (object) => {
  return typeof object === "object" && typeof object.append === "function" && typeof object.delete === "function" && typeof object.get === "function" && typeof object.getAll === "function" && typeof object.has === "function" && typeof object.set === "function" && typeof object.sort === "function" && object[NAME] === "URLSearchParams";
};
const isBlob = (object) => {
  return typeof object === "object" && typeof object.arrayBuffer === "function" && typeof object.type === "string" && typeof object.stream === "function" && typeof object.constructor === "function" && /^(Blob|File)$/.test(object[NAME]);
};
function isFormData(object) {
  return typeof object === "object" && typeof object.append === "function" && typeof object.set === "function" && typeof object.get === "function" && typeof object.getAll === "function" && typeof object.delete === "function" && typeof object.keys === "function" && typeof object.values === "function" && typeof object.entries === "function" && typeof object.constructor === "function" && object[NAME] === "FormData";
}
const isAbortSignal = (object) => {
  return typeof object === "object" && object[NAME] === "AbortSignal";
};
const carriage = "\r\n";
const dashes = "-".repeat(2);
const carriageLength = Buffer.byteLength(carriage);
const getFooter = (boundary) => `${dashes}${boundary}${dashes}${carriage.repeat(2)}`;
function getHeader(boundary, name2, field) {
  let header = "";
  header += `${dashes}${boundary}${carriage}`;
  header += `Content-Disposition: form-data; name="${name2}"`;
  if (isBlob(field)) {
    header += `; filename="${field.name}"${carriage}`;
    header += `Content-Type: ${field.type || "application/octet-stream"}`;
  }
  return `${header}${carriage.repeat(2)}`;
}
const getBoundary = () => randomBytes(8).toString("hex");
async function* formDataIterator(form, boundary) {
  for (const [name2, value] of form) {
    yield getHeader(boundary, name2, value);
    if (isBlob(value)) {
      yield* value.stream();
    } else {
      yield value;
    }
    yield carriage;
  }
  yield getFooter(boundary);
}
function getFormDataLength(form, boundary) {
  let length = 0;
  for (const [name2, value] of form) {
    length += Buffer.byteLength(getHeader(boundary, name2, value));
    if (isBlob(value)) {
      length += value.size;
    } else {
      length += Buffer.byteLength(String(value));
    }
    length += carriageLength;
  }
  length += Buffer.byteLength(getFooter(boundary));
  return length;
}
const INTERNALS$2 = Symbol("Body internals");
class Body {
  constructor(body, {
    size = 0
  } = {}) {
    let boundary = null;
    if (body === null) {
      body = null;
    } else if (isURLSearchParameters(body)) {
      body = Buffer.from(body.toString());
    } else if (isBlob(body))
      ;
    else if (Buffer.isBuffer(body))
      ;
    else if (util$1.types.isAnyArrayBuffer(body)) {
      body = Buffer.from(body);
    } else if (ArrayBuffer.isView(body)) {
      body = Buffer.from(body.buffer, body.byteOffset, body.byteLength);
    } else if (body instanceof Stream)
      ;
    else if (isFormData(body)) {
      boundary = `NodeFetchFormDataBoundary${getBoundary()}`;
      body = Stream.Readable.from(formDataIterator(body, boundary));
    } else {
      body = Buffer.from(String(body));
    }
    this[INTERNALS$2] = {
      body,
      boundary,
      disturbed: false,
      error: null
    };
    this.size = size;
    if (body instanceof Stream) {
      body.on("error", (err) => {
        const error2 = err instanceof FetchBaseError ? err : new FetchError(`Invalid response body while trying to fetch ${this.url}: ${err.message}`, "system", err);
        this[INTERNALS$2].error = error2;
      });
    }
  }
  get body() {
    return this[INTERNALS$2].body;
  }
  get bodyUsed() {
    return this[INTERNALS$2].disturbed;
  }
  async arrayBuffer() {
    const {buffer, byteOffset, byteLength} = await consumeBody(this);
    return buffer.slice(byteOffset, byteOffset + byteLength);
  }
  async blob() {
    const ct = this.headers && this.headers.get("content-type") || this[INTERNALS$2].body && this[INTERNALS$2].body.type || "";
    const buf = await this.buffer();
    return new fetchBlob([buf], {
      type: ct
    });
  }
  async json() {
    const buffer = await consumeBody(this);
    return JSON.parse(buffer.toString());
  }
  async text() {
    const buffer = await consumeBody(this);
    return buffer.toString();
  }
  buffer() {
    return consumeBody(this);
  }
}
Object.defineProperties(Body.prototype, {
  body: {enumerable: true},
  bodyUsed: {enumerable: true},
  arrayBuffer: {enumerable: true},
  blob: {enumerable: true},
  json: {enumerable: true},
  text: {enumerable: true}
});
async function consumeBody(data) {
  if (data[INTERNALS$2].disturbed) {
    throw new TypeError(`body used already for: ${data.url}`);
  }
  data[INTERNALS$2].disturbed = true;
  if (data[INTERNALS$2].error) {
    throw data[INTERNALS$2].error;
  }
  let {body} = data;
  if (body === null) {
    return Buffer.alloc(0);
  }
  if (isBlob(body)) {
    body = body.stream();
  }
  if (Buffer.isBuffer(body)) {
    return body;
  }
  if (!(body instanceof Stream)) {
    return Buffer.alloc(0);
  }
  const accum = [];
  let accumBytes = 0;
  try {
    for await (const chunk of body) {
      if (data.size > 0 && accumBytes + chunk.length > data.size) {
        const err = new FetchError(`content size at ${data.url} over limit: ${data.size}`, "max-size");
        body.destroy(err);
        throw err;
      }
      accumBytes += chunk.length;
      accum.push(chunk);
    }
  } catch (error2) {
    if (error2 instanceof FetchBaseError) {
      throw error2;
    } else {
      throw new FetchError(`Invalid response body while trying to fetch ${data.url}: ${error2.message}`, "system", error2);
    }
  }
  if (body.readableEnded === true || body._readableState.ended === true) {
    try {
      if (accum.every((c) => typeof c === "string")) {
        return Buffer.from(accum.join(""));
      }
      return Buffer.concat(accum, accumBytes);
    } catch (error2) {
      throw new FetchError(`Could not create Buffer from response body for ${data.url}: ${error2.message}`, "system", error2);
    }
  } else {
    throw new FetchError(`Premature close of server response while trying to fetch ${data.url}`);
  }
}
const clone = (instance, highWaterMark) => {
  let p1;
  let p2;
  let {body} = instance;
  if (instance.bodyUsed) {
    throw new Error("cannot clone body after it is used");
  }
  if (body instanceof Stream && typeof body.getBoundary !== "function") {
    p1 = new PassThrough({highWaterMark});
    p2 = new PassThrough({highWaterMark});
    body.pipe(p1);
    body.pipe(p2);
    instance[INTERNALS$2].body = p1;
    body = p2;
  }
  return body;
};
const extractContentType = (body, request) => {
  if (body === null) {
    return null;
  }
  if (typeof body === "string") {
    return "text/plain;charset=UTF-8";
  }
  if (isURLSearchParameters(body)) {
    return "application/x-www-form-urlencoded;charset=UTF-8";
  }
  if (isBlob(body)) {
    return body.type || null;
  }
  if (Buffer.isBuffer(body) || util$1.types.isAnyArrayBuffer(body) || ArrayBuffer.isView(body)) {
    return null;
  }
  if (body && typeof body.getBoundary === "function") {
    return `multipart/form-data;boundary=${body.getBoundary()}`;
  }
  if (isFormData(body)) {
    return `multipart/form-data; boundary=${request[INTERNALS$2].boundary}`;
  }
  if (body instanceof Stream) {
    return null;
  }
  return "text/plain;charset=UTF-8";
};
const getTotalBytes = (request) => {
  const {body} = request;
  if (body === null) {
    return 0;
  }
  if (isBlob(body)) {
    return body.size;
  }
  if (Buffer.isBuffer(body)) {
    return body.length;
  }
  if (body && typeof body.getLengthSync === "function") {
    return body.hasKnownLength && body.hasKnownLength() ? body.getLengthSync() : null;
  }
  if (isFormData(body)) {
    return getFormDataLength(request[INTERNALS$2].boundary);
  }
  return null;
};
const writeToStream = (dest, {body}) => {
  if (body === null) {
    dest.end();
  } else if (isBlob(body)) {
    body.stream().pipe(dest);
  } else if (Buffer.isBuffer(body)) {
    dest.write(body);
    dest.end();
  } else {
    body.pipe(dest);
  }
};
const validateHeaderName = typeof http.validateHeaderName === "function" ? http.validateHeaderName : (name2) => {
  if (!/^[\^`\-\w!#$%&'*+.|~]+$/.test(name2)) {
    const err = new TypeError(`Header name must be a valid HTTP token [${name2}]`);
    Object.defineProperty(err, "code", {value: "ERR_INVALID_HTTP_TOKEN"});
    throw err;
  }
};
const validateHeaderValue = typeof http.validateHeaderValue === "function" ? http.validateHeaderValue : (name2, value) => {
  if (/[^\t\u0020-\u007E\u0080-\u00FF]/.test(value)) {
    const err = new TypeError(`Invalid character in header content ["${name2}"]`);
    Object.defineProperty(err, "code", {value: "ERR_INVALID_CHAR"});
    throw err;
  }
};
class Headers extends URLSearchParams {
  constructor(init2) {
    let result = [];
    if (init2 instanceof Headers) {
      const raw = init2.raw();
      for (const [name2, values] of Object.entries(raw)) {
        result.push(...values.map((value) => [name2, value]));
      }
    } else if (init2 == null)
      ;
    else if (typeof init2 === "object" && !util$1.types.isBoxedPrimitive(init2)) {
      const method = init2[Symbol.iterator];
      if (method == null) {
        result.push(...Object.entries(init2));
      } else {
        if (typeof method !== "function") {
          throw new TypeError("Header pairs must be iterable");
        }
        result = [...init2].map((pair) => {
          if (typeof pair !== "object" || util$1.types.isBoxedPrimitive(pair)) {
            throw new TypeError("Each header pair must be an iterable object");
          }
          return [...pair];
        }).map((pair) => {
          if (pair.length !== 2) {
            throw new TypeError("Each header pair must be a name/value tuple");
          }
          return [...pair];
        });
      }
    } else {
      throw new TypeError("Failed to construct 'Headers': The provided value is not of type '(sequence<sequence<ByteString>> or record<ByteString, ByteString>)");
    }
    result = result.length > 0 ? result.map(([name2, value]) => {
      validateHeaderName(name2);
      validateHeaderValue(name2, String(value));
      return [String(name2).toLowerCase(), String(value)];
    }) : void 0;
    super(result);
    return new Proxy(this, {
      get(target, p, receiver) {
        switch (p) {
          case "append":
          case "set":
            return (name2, value) => {
              validateHeaderName(name2);
              validateHeaderValue(name2, String(value));
              return URLSearchParams.prototype[p].call(receiver, String(name2).toLowerCase(), String(value));
            };
          case "delete":
          case "has":
          case "getAll":
            return (name2) => {
              validateHeaderName(name2);
              return URLSearchParams.prototype[p].call(receiver, String(name2).toLowerCase());
            };
          case "keys":
            return () => {
              target.sort();
              return new Set(URLSearchParams.prototype.keys.call(target)).keys();
            };
          default:
            return Reflect.get(target, p, receiver);
        }
      }
    });
  }
  get [Symbol.toStringTag]() {
    return this.constructor.name;
  }
  toString() {
    return Object.prototype.toString.call(this);
  }
  get(name2) {
    const values = this.getAll(name2);
    if (values.length === 0) {
      return null;
    }
    let value = values.join(", ");
    if (/^content-encoding$/i.test(name2)) {
      value = value.toLowerCase();
    }
    return value;
  }
  forEach(callback) {
    for (const name2 of this.keys()) {
      callback(this.get(name2), name2);
    }
  }
  *values() {
    for (const name2 of this.keys()) {
      yield this.get(name2);
    }
  }
  *entries() {
    for (const name2 of this.keys()) {
      yield [name2, this.get(name2)];
    }
  }
  [Symbol.iterator]() {
    return this.entries();
  }
  raw() {
    return [...this.keys()].reduce((result, key) => {
      result[key] = this.getAll(key);
      return result;
    }, {});
  }
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return [...this.keys()].reduce((result, key) => {
      const values = this.getAll(key);
      if (key === "host") {
        result[key] = values[0];
      } else {
        result[key] = values.length > 1 ? values : values[0];
      }
      return result;
    }, {});
  }
}
Object.defineProperties(Headers.prototype, ["get", "entries", "forEach", "values"].reduce((result, property) => {
  result[property] = {enumerable: true};
  return result;
}, {}));
function fromRawHeaders(headers = []) {
  return new Headers(headers.reduce((result, value, index2, array) => {
    if (index2 % 2 === 0) {
      result.push(array.slice(index2, index2 + 2));
    }
    return result;
  }, []).filter(([name2, value]) => {
    try {
      validateHeaderName(name2);
      validateHeaderValue(name2, String(value));
      return true;
    } catch (e) {
      return false;
    }
  }));
}
const redirectStatus = new Set([301, 302, 303, 307, 308]);
const isRedirect = (code) => {
  return redirectStatus.has(code);
};
const INTERNALS$1 = Symbol("Response internals");
class Response extends Body {
  constructor(body = null, options = {}) {
    super(body, options);
    const status = options.status || 200;
    const headers = new Headers(options.headers);
    if (body !== null && !headers.has("Content-Type")) {
      const contentType = extractContentType(body);
      if (contentType) {
        headers.append("Content-Type", contentType);
      }
    }
    this[INTERNALS$1] = {
      url: options.url,
      status,
      statusText: options.statusText || "",
      headers,
      counter: options.counter,
      highWaterMark: options.highWaterMark
    };
  }
  get url() {
    return this[INTERNALS$1].url || "";
  }
  get status() {
    return this[INTERNALS$1].status;
  }
  get ok() {
    return this[INTERNALS$1].status >= 200 && this[INTERNALS$1].status < 300;
  }
  get redirected() {
    return this[INTERNALS$1].counter > 0;
  }
  get statusText() {
    return this[INTERNALS$1].statusText;
  }
  get headers() {
    return this[INTERNALS$1].headers;
  }
  get highWaterMark() {
    return this[INTERNALS$1].highWaterMark;
  }
  clone() {
    return new Response(clone(this, this.highWaterMark), {
      url: this.url,
      status: this.status,
      statusText: this.statusText,
      headers: this.headers,
      ok: this.ok,
      redirected: this.redirected,
      size: this.size
    });
  }
  static redirect(url2, status = 302) {
    if (!isRedirect(status)) {
      throw new RangeError('Failed to execute "redirect" on "response": Invalid status code');
    }
    return new Response(null, {
      headers: {
        location: new URL(url2).toString()
      },
      status
    });
  }
  get [Symbol.toStringTag]() {
    return "Response";
  }
}
Object.defineProperties(Response.prototype, {
  url: {enumerable: true},
  status: {enumerable: true},
  ok: {enumerable: true},
  redirected: {enumerable: true},
  statusText: {enumerable: true},
  headers: {enumerable: true},
  clone: {enumerable: true}
});
const getSearch = (parsedURL) => {
  if (parsedURL.search) {
    return parsedURL.search;
  }
  const lastOffset = parsedURL.href.length - 1;
  const hash = parsedURL.hash || (parsedURL.href[lastOffset] === "#" ? "#" : "");
  return parsedURL.href[lastOffset - hash.length] === "?" ? "?" : "";
};
const INTERNALS = Symbol("Request internals");
const isRequest = (object) => {
  return typeof object === "object" && typeof object[INTERNALS] === "object";
};
class Request extends Body {
  constructor(input, init2 = {}) {
    let parsedURL;
    if (isRequest(input)) {
      parsedURL = new URL(input.url);
    } else {
      parsedURL = new URL(input);
      input = {};
    }
    let method = init2.method || input.method || "GET";
    method = method.toUpperCase();
    if ((init2.body != null || isRequest(input)) && input.body !== null && (method === "GET" || method === "HEAD")) {
      throw new TypeError("Request with GET/HEAD method cannot have body");
    }
    const inputBody = init2.body ? init2.body : isRequest(input) && input.body !== null ? clone(input) : null;
    super(inputBody, {
      size: init2.size || input.size || 0
    });
    const headers = new Headers(init2.headers || input.headers || {});
    if (inputBody !== null && !headers.has("Content-Type")) {
      const contentType = extractContentType(inputBody, this);
      if (contentType) {
        headers.append("Content-Type", contentType);
      }
    }
    let signal = isRequest(input) ? input.signal : null;
    if ("signal" in init2) {
      signal = init2.signal;
    }
    if (signal !== null && !isAbortSignal(signal)) {
      throw new TypeError("Expected signal to be an instanceof AbortSignal");
    }
    this[INTERNALS] = {
      method,
      redirect: init2.redirect || input.redirect || "follow",
      headers,
      parsedURL,
      signal
    };
    this.follow = init2.follow === void 0 ? input.follow === void 0 ? 20 : input.follow : init2.follow;
    this.compress = init2.compress === void 0 ? input.compress === void 0 ? true : input.compress : init2.compress;
    this.counter = init2.counter || input.counter || 0;
    this.agent = init2.agent || input.agent;
    this.highWaterMark = init2.highWaterMark || input.highWaterMark || 16384;
    this.insecureHTTPParser = init2.insecureHTTPParser || input.insecureHTTPParser || false;
  }
  get method() {
    return this[INTERNALS].method;
  }
  get url() {
    return format(this[INTERNALS].parsedURL);
  }
  get headers() {
    return this[INTERNALS].headers;
  }
  get redirect() {
    return this[INTERNALS].redirect;
  }
  get signal() {
    return this[INTERNALS].signal;
  }
  clone() {
    return new Request(this);
  }
  get [Symbol.toStringTag]() {
    return "Request";
  }
}
Object.defineProperties(Request.prototype, {
  method: {enumerable: true},
  url: {enumerable: true},
  headers: {enumerable: true},
  redirect: {enumerable: true},
  clone: {enumerable: true},
  signal: {enumerable: true}
});
const getNodeRequestOptions = (request) => {
  const {parsedURL} = request[INTERNALS];
  const headers = new Headers(request[INTERNALS].headers);
  if (!headers.has("Accept")) {
    headers.set("Accept", "*/*");
  }
  let contentLengthValue = null;
  if (request.body === null && /^(post|put)$/i.test(request.method)) {
    contentLengthValue = "0";
  }
  if (request.body !== null) {
    const totalBytes = getTotalBytes(request);
    if (typeof totalBytes === "number" && !Number.isNaN(totalBytes)) {
      contentLengthValue = String(totalBytes);
    }
  }
  if (contentLengthValue) {
    headers.set("Content-Length", contentLengthValue);
  }
  if (!headers.has("User-Agent")) {
    headers.set("User-Agent", "node-fetch");
  }
  if (request.compress && !headers.has("Accept-Encoding")) {
    headers.set("Accept-Encoding", "gzip,deflate,br");
  }
  let {agent} = request;
  if (typeof agent === "function") {
    agent = agent(parsedURL);
  }
  if (!headers.has("Connection") && !agent) {
    headers.set("Connection", "close");
  }
  const search = getSearch(parsedURL);
  const requestOptions = {
    path: parsedURL.pathname + search,
    pathname: parsedURL.pathname,
    hostname: parsedURL.hostname,
    protocol: parsedURL.protocol,
    port: parsedURL.port,
    hash: parsedURL.hash,
    search: parsedURL.search,
    query: parsedURL.query,
    href: parsedURL.href,
    method: request.method,
    headers: headers[Symbol.for("nodejs.util.inspect.custom")](),
    insecureHTTPParser: request.insecureHTTPParser,
    agent
  };
  return requestOptions;
};
class AbortError extends FetchBaseError {
  constructor(message, type = "aborted") {
    super(message, type);
  }
}
const supportedSchemas = new Set(["data:", "http:", "https:"]);
async function fetch$2(url2, options_) {
  return new Promise((resolve2, reject) => {
    const request = new Request(url2, options_);
    const options = getNodeRequestOptions(request);
    if (!supportedSchemas.has(options.protocol)) {
      throw new TypeError(`node-fetch cannot load ${url2}. URL scheme "${options.protocol.replace(/:$/, "")}" is not supported.`);
    }
    if (options.protocol === "data:") {
      const data = src(request.url);
      const response2 = new Response(data, {headers: {"Content-Type": data.typeFull}});
      resolve2(response2);
      return;
    }
    const send = (options.protocol === "https:" ? https : http).request;
    const {signal} = request;
    let response = null;
    const abort = () => {
      const error2 = new AbortError("The operation was aborted.");
      reject(error2);
      if (request.body && request.body instanceof Stream.Readable) {
        request.body.destroy(error2);
      }
      if (!response || !response.body) {
        return;
      }
      response.body.emit("error", error2);
    };
    if (signal && signal.aborted) {
      abort();
      return;
    }
    const abortAndFinalize = () => {
      abort();
      finalize();
    };
    const request_ = send(options);
    if (signal) {
      signal.addEventListener("abort", abortAndFinalize);
    }
    const finalize = () => {
      request_.abort();
      if (signal) {
        signal.removeEventListener("abort", abortAndFinalize);
      }
    };
    request_.on("error", (err) => {
      reject(new FetchError(`request to ${request.url} failed, reason: ${err.message}`, "system", err));
      finalize();
    });
    request_.on("response", (response_) => {
      request_.setTimeout(0);
      const headers = fromRawHeaders(response_.rawHeaders);
      if (isRedirect(response_.statusCode)) {
        const location = headers.get("Location");
        const locationURL = location === null ? null : new URL(location, request.url);
        switch (request.redirect) {
          case "error":
            reject(new FetchError(`uri requested responds with a redirect, redirect mode is set to error: ${request.url}`, "no-redirect"));
            finalize();
            return;
          case "manual":
            if (locationURL !== null) {
              try {
                headers.set("Location", locationURL);
              } catch (error2) {
                reject(error2);
              }
            }
            break;
          case "follow": {
            if (locationURL === null) {
              break;
            }
            if (request.counter >= request.follow) {
              reject(new FetchError(`maximum redirect reached at: ${request.url}`, "max-redirect"));
              finalize();
              return;
            }
            const requestOptions = {
              headers: new Headers(request.headers),
              follow: request.follow,
              counter: request.counter + 1,
              agent: request.agent,
              compress: request.compress,
              method: request.method,
              body: request.body,
              signal: request.signal,
              size: request.size
            };
            if (response_.statusCode !== 303 && request.body && options_.body instanceof Stream.Readable) {
              reject(new FetchError("Cannot follow redirect with body being a readable stream", "unsupported-redirect"));
              finalize();
              return;
            }
            if (response_.statusCode === 303 || (response_.statusCode === 301 || response_.statusCode === 302) && request.method === "POST") {
              requestOptions.method = "GET";
              requestOptions.body = void 0;
              requestOptions.headers.delete("content-length");
            }
            resolve2(fetch$2(new Request(locationURL, requestOptions)));
            finalize();
            return;
          }
        }
      }
      response_.once("end", () => {
        if (signal) {
          signal.removeEventListener("abort", abortAndFinalize);
        }
      });
      let body = pipeline(response_, new PassThrough(), (error2) => {
        reject(error2);
      });
      if (process.version < "v12.10") {
        response_.on("aborted", abortAndFinalize);
      }
      const responseOptions = {
        url: request.url,
        status: response_.statusCode,
        statusText: response_.statusMessage,
        headers,
        size: request.size,
        counter: request.counter,
        highWaterMark: request.highWaterMark
      };
      const codings = headers.get("Content-Encoding");
      if (!request.compress || request.method === "HEAD" || codings === null || response_.statusCode === 204 || response_.statusCode === 304) {
        response = new Response(body, responseOptions);
        resolve2(response);
        return;
      }
      const zlibOptions = {
        flush: zlib.Z_SYNC_FLUSH,
        finishFlush: zlib.Z_SYNC_FLUSH
      };
      if (codings === "gzip" || codings === "x-gzip") {
        body = pipeline(body, zlib.createGunzip(zlibOptions), (error2) => {
          reject(error2);
        });
        response = new Response(body, responseOptions);
        resolve2(response);
        return;
      }
      if (codings === "deflate" || codings === "x-deflate") {
        const raw = pipeline(response_, new PassThrough(), (error2) => {
          reject(error2);
        });
        raw.once("data", (chunk) => {
          if ((chunk[0] & 15) === 8) {
            body = pipeline(body, zlib.createInflate(), (error2) => {
              reject(error2);
            });
          } else {
            body = pipeline(body, zlib.createInflateRaw(), (error2) => {
              reject(error2);
            });
          }
          response = new Response(body, responseOptions);
          resolve2(response);
        });
        return;
      }
      if (codings === "br") {
        body = pipeline(body, zlib.createBrotliDecompress(), (error2) => {
          reject(error2);
        });
        response = new Response(body, responseOptions);
        resolve2(response);
        return;
      }
      response = new Response(body, responseOptions);
      resolve2(response);
    });
    writeToStream(request_, request);
  });
}
function noop$2() {
}
function safe_not_equal(a, b) {
  return a != a ? b == b : a !== b || (a && typeof a === "object" || typeof a === "function");
}
const subscriber_queue = [];
function writable(value, start = noop$2) {
  let stop;
  const subscribers = [];
  function set(new_value) {
    if (safe_not_equal(value, new_value)) {
      value = new_value;
      if (stop) {
        const run_queue = !subscriber_queue.length;
        for (let i = 0; i < subscribers.length; i += 1) {
          const s2 = subscribers[i];
          s2[1]();
          subscriber_queue.push(s2, value);
        }
        if (run_queue) {
          for (let i = 0; i < subscriber_queue.length; i += 2) {
            subscriber_queue[i][0](subscriber_queue[i + 1]);
          }
          subscriber_queue.length = 0;
        }
      }
    }
  }
  function update(fn) {
    set(fn(value));
  }
  function subscribe(run2, invalidate = noop$2) {
    const subscriber = [run2, invalidate];
    subscribers.push(subscriber);
    if (subscribers.length === 1) {
      stop = start(set) || noop$2;
    }
    run2(value);
    return () => {
      const index2 = subscribers.indexOf(subscriber);
      if (index2 !== -1) {
        subscribers.splice(index2, 1);
      }
      if (subscribers.length === 0) {
        stop();
        stop = null;
      }
    };
  }
  return {set, update, subscribe};
}
function normalize(loaded) {
  if (loaded.error) {
    const error2 = typeof loaded.error === "string" ? new Error(loaded.error) : loaded.error;
    const status = loaded.status;
    if (!(error2 instanceof Error)) {
      return {
        status: 500,
        error: new Error(`"error" property returned from load() must be a string or instance of Error, received type "${typeof error2}"`)
      };
    }
    if (!status || status < 400 || status > 599) {
      console.warn('"error" returned from load() without a valid status code \u2014 defaulting to 500');
      return {status: 500, error: error2};
    }
    return {status, error: error2};
  }
  if (loaded.redirect) {
    if (!loaded.status || Math.floor(loaded.status / 100) !== 3) {
      return {
        status: 500,
        error: new Error('"redirect" property returned from load() must be accompanied by a 3xx status code')
      };
    }
    if (typeof loaded.redirect !== "string") {
      return {
        status: 500,
        error: new Error('"redirect" property returned from load() must be a string')
      };
    }
  }
  return loaded;
}
const s = JSON.stringify;
async function respond({request, options, $session, route, status = 200, error: error2}) {
  const serialized_session = try_serialize($session, (error3) => {
    throw new Error(`Failed to serialize session data: ${error3.message}`);
  });
  const serialized_data = [];
  const match2 = error2 ? null : route.pattern.exec(request.path);
  const params = error2 ? {} : route.params(match2);
  const page = {
    host: request.host,
    path: request.path,
    query: request.query,
    params
  };
  let uses_credentials = false;
  const fetcher = async (resource, opts = {}) => {
    let url$1;
    if (typeof resource === "string") {
      url$1 = resource;
    } else {
      url$1 = resource.url;
      opts = {
        method: resource.method,
        headers: resource.headers,
        body: resource.body,
        mode: resource.mode,
        credentials: resource.credentials,
        cache: resource.cache,
        redirect: resource.redirect,
        referrer: resource.referrer,
        integrity: resource.integrity,
        ...opts
      };
    }
    if (options.local && url$1.startsWith(options.paths.assets)) {
      url$1 = url$1.replace(options.paths.assets, "");
    }
    const parsed = parse(url$1);
    let response;
    if (parsed.protocol) {
      response = await fetch$2(parsed.href, opts);
    } else {
      const resolved = resolve(request.path, parsed.pathname);
      const filename = resolved.slice(1);
      const filename_html = `${filename}/index.html`;
      const asset = options.manifest.assets.find((d) => d.file === filename || d.file === filename_html);
      if (asset) {
        if (options.get_static_file) {
          response = new Response(options.get_static_file(asset.file), {
            headers: {
              "content-type": asset.type
            }
          });
        } else {
          response = await fetch$2(`http://${page.host}/${asset.file}`, opts);
        }
      }
      if (!response) {
        const headers2 = {...opts.headers};
        if (opts.credentials !== "omit") {
          uses_credentials = true;
          headers2.cookie = request.headers.cookie;
          if (!headers2.authorization) {
            headers2.authorization = request.headers.authorization;
          }
        }
        const rendered2 = await ssr({
          host: request.host,
          method: opts.method || "GET",
          headers: headers2,
          path: resolved,
          body: opts.body,
          query: new url.URLSearchParams(parsed.query || "")
        }, {
          ...options,
          fetched: url$1,
          initiator: route
        });
        if (rendered2) {
          if (options.dependencies) {
            options.dependencies.set(resolved, rendered2);
          }
          response = new Response(rendered2.body, {
            status: rendered2.status,
            headers: rendered2.headers
          });
        }
      }
    }
    if (response && page_config.hydrate) {
      const proxy = new Proxy(response, {
        get(response2, key, receiver) {
          async function text() {
            const body2 = await response2.text();
            const headers2 = {};
            response2.headers.forEach((value, key2) => {
              if (key2 !== "etag" && key2 !== "set-cookie")
                headers2[key2] = value;
            });
            serialized_data.push({
              url: url$1,
              json: `{"status":${response2.status},"statusText":${s(response2.statusText)},"headers":${s(headers2)},"body":${escape$2(body2)}}`
            });
            return body2;
          }
          if (key === "text") {
            return text;
          }
          if (key === "json") {
            return async () => {
              return JSON.parse(await text());
            };
          }
          return Reflect.get(response2, key, receiver);
        }
      });
      return proxy;
    }
    return response || new Response("Not found", {
      status: 404
    });
  };
  const component_promises = error2 ? [options.manifest.layout()] : [options.manifest.layout(), ...route.parts.map((part) => part.load())];
  const components2 = [];
  const props_promises = [];
  let context = {};
  let maxage;
  let page_component;
  try {
    page_component = error2 ? {ssr: options.ssr, router: options.router, hydrate: options.hydrate} : await component_promises[component_promises.length - 1];
  } catch (e) {
    return await respond({
      request,
      options,
      $session,
      route: null,
      status: 500,
      error: e instanceof Error ? e : {name: "Error", message: e.toString()}
    });
  }
  const page_config = {
    ssr: "ssr" in page_component ? page_component.ssr : options.ssr,
    router: "router" in page_component ? page_component.router : options.router,
    hydrate: "hydrate" in page_component ? page_component.hydrate : options.hydrate
  };
  if (options.only_render_prerenderable_pages) {
    if (error2) {
      return {
        status,
        headers: {},
        body: error2.message
      };
    }
    if (!page_component.prerender) {
      return {
        status: 204,
        headers: {},
        body: null
      };
    }
  }
  let rendered;
  if (page_config.ssr) {
    for (let i = 0; i < component_promises.length; i += 1) {
      let loaded;
      try {
        const mod = await component_promises[i];
        components2[i] = mod.default;
        if (mod.load) {
          loaded = await mod.load.call(null, {
            page,
            get session() {
              uses_credentials = true;
              return $session;
            },
            fetch: fetcher,
            context: {...context}
          });
          if (!loaded && mod === page_component)
            return;
        }
      } catch (e) {
        if (error2)
          throw e instanceof Error ? e : new Error(e);
        loaded = {
          error: e instanceof Error ? e : {name: "Error", message: e.toString()},
          status: 500
        };
      }
      if (loaded) {
        loaded = normalize(loaded);
        if (loaded.error) {
          return await respond({
            request,
            options,
            $session,
            route: null,
            status: loaded.status,
            error: loaded.error
          });
        }
        if (loaded.redirect) {
          return {
            status: loaded.status,
            headers: {
              location: loaded.redirect
            }
          };
        }
        if (loaded.context) {
          context = {
            ...context,
            ...loaded.context
          };
        }
        maxage = loaded.maxage || 0;
        props_promises[i] = loaded.props;
      }
    }
    const session = writable($session);
    let session_tracking_active = false;
    const unsubscribe = session.subscribe(() => {
      if (session_tracking_active)
        uses_credentials = true;
    });
    session_tracking_active = true;
    if (error2) {
      if (options.dev) {
        error2.stack = await options.get_stack(error2);
      } else {
        error2.stack = String(error2);
      }
    }
    const props = {
      status,
      error: error2,
      stores: {
        page: writable(null),
        navigating: writable(null),
        session
      },
      page,
      components: components2
    };
    for (let i = 0; i < props_promises.length; i += 1) {
      props[`props_${i}`] = await props_promises[i];
    }
    try {
      rendered = options.root.render(props);
    } catch (e) {
      if (error2)
        throw e instanceof Error ? e : new Error(e);
      return await respond({
        request,
        options,
        $session,
        route: null,
        status: 500,
        error: e instanceof Error ? e : {name: "Error", message: e.toString()}
      });
    } finally {
      unsubscribe();
    }
  } else {
    rendered = {
      head: "",
      html: "",
      css: ""
    };
  }
  const js_deps = route && page_config.ssr ? route.js : [];
  const css_deps = route && page_config.ssr ? route.css : [];
  const style = route && page_config.ssr ? route.style : "";
  const prefix = `${options.paths.assets}/${options.app_dir}`;
  const links = options.amp ? `<style amp-custom>${style || (await Promise.all(css_deps.map((dep) => options.get_amp_css(dep)))).join("\n")}</style>` : [
    ...js_deps.map((dep) => `<link rel="modulepreload" href="${prefix}/${dep}">`),
    ...css_deps.map((dep) => `<link rel="stylesheet" href="${prefix}/${dep}">`)
  ].join("\n			");
  let init2 = "";
  if (options.amp) {
    init2 = `
		<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style>
		<noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
		<script async src="https://cdn.ampproject.org/v0.js"></script>`;
  } else if (page_config.router || page_config.hydrate) {
    init2 = `
		<script type="module">
			import { start } from ${s(options.entry)};
			start({
				target: ${options.target ? `document.querySelector(${s(options.target)})` : "document.body"},
				paths: ${s(options.paths)},
				session: ${serialized_session},
				host: ${request.host ? s(request.host) : "location.host"},
				route: ${!!page_config.router},
				hydrate: ${page_config.hydrate ? `{
					status: ${status},
					error: ${serialize_error(error2)},
					nodes: ${route ? `[
						${(route ? route.parts : []).map((part) => `import(${s(options.get_component_path(part.id))})`).join(",\n						")}
					]` : "[]"},
					page: {
						host: ${request.host ? s(request.host) : "location.host"}, // TODO this is redundant
						path: ${s(request.path)},
						query: new URLSearchParams(${s(request.query.toString())}),
						params: ${s(params)}
					}
				}` : "null"}
			});
		</script>`;
  }
  const head = [
    rendered.head,
    style && !options.amp ? `<style data-svelte>${style}</style>` : "",
    links,
    init2
  ].join("\n\n");
  const body = options.amp ? rendered.html : `${rendered.html}

			${serialized_data.map(({url: url2, json}) => `<script type="svelte-data" url="${url2}">${json}</script>`).join("\n\n			")}
		`.replace(/^\t{2}/gm, "");
  const headers = {
    "content-type": "text/html"
  };
  if (maxage) {
    headers["cache-control"] = `${uses_credentials ? "private" : "public"}, max-age=${maxage}`;
  }
  return {
    status,
    headers,
    body: options.template({head, body})
  };
}
async function render_page(request, route, options) {
  if (options.initiator === route) {
    return {
      status: 404,
      headers: {},
      body: `Not found: ${request.path}`
    };
  }
  const $session = await options.hooks.getSession({context: request.context});
  const response = await respond({
    request,
    options,
    $session,
    route,
    status: route ? 200 : 404,
    error: route ? null : new Error(`Not found: ${request.path}`)
  });
  if (response) {
    return response;
  }
  if (options.fetched) {
    return {
      status: 500,
      headers: {},
      body: `Bad request in load function: failed to fetch ${options.fetched}`
    };
  }
}
function try_serialize(data, fail) {
  try {
    return devalue(data);
  } catch (err) {
    if (fail)
      fail(err);
    return null;
  }
}
function serialize_error(error2) {
  if (!error2)
    return null;
  let serialized = try_serialize(error2);
  if (!serialized) {
    const {name: name2, message, stack} = error2;
    serialized = try_serialize({name: name2, message, stack});
  }
  if (!serialized) {
    serialized = "{}";
  }
  return serialized;
}
const escaped$2 = {
  "<": "\\u003C",
  ">": "\\u003E",
  "/": "\\u002F",
  "\\": "\\\\",
  "\b": "\\b",
  "\f": "\\f",
  "\n": "\\n",
  "\r": "\\r",
  "	": "\\t",
  "\0": "\\0",
  "\u2028": "\\u2028",
  "\u2029": "\\u2029"
};
function escape$2(str) {
  let result = '"';
  for (let i = 0; i < str.length; i += 1) {
    const char = str.charAt(i);
    const code = char.charCodeAt(0);
    if (char === '"') {
      result += '\\"';
    } else if (char in escaped$2) {
      result += escaped$2[char];
    } else if (code >= 55296 && code <= 57343) {
      const next = str.charCodeAt(i + 1);
      if (code <= 56319 && next >= 56320 && next <= 57343) {
        result += char + str[++i];
      } else {
        result += `\\u${code.toString(16).toUpperCase()}`;
      }
    } else {
      result += char;
    }
  }
  result += '"';
  return result;
}
async function render_route(request, route) {
  const mod = await route.load();
  const handler = mod[request.method.toLowerCase().replace("delete", "del")];
  if (handler) {
    const match2 = route.pattern.exec(request.path);
    const params = route.params(match2);
    const response = await handler({...request, params});
    if (response) {
      if (typeof response !== "object" || response.body == null) {
        return {
          status: 500,
          body: `Invalid response from route ${request.path}; ${response.body == null ? "body is missing" : `expected an object, got ${typeof response}`}`,
          headers: {}
        };
      }
      let {status = 200, body, headers = {}} = response;
      headers = lowercase_keys(headers);
      if (typeof body === "object" && !("content-type" in headers) || headers["content-type"] === "application/json") {
        headers = {...headers, "content-type": "application/json"};
        body = JSON.stringify(body);
      }
      return {status, body, headers};
    }
  }
}
function lowercase_keys(obj) {
  const clone2 = {};
  for (const key in obj) {
    clone2[key.toLowerCase()] = obj[key];
  }
  return clone2;
}
function md5(body) {
  return createHash("md5").update(body).digest("hex");
}
async function ssr(incoming, options) {
  if (incoming.path.endsWith("/") && incoming.path !== "/") {
    const q = incoming.query.toString();
    return {
      status: 301,
      headers: {
        location: incoming.path.slice(0, -1) + (q ? `?${q}` : "")
      }
    };
  }
  const context = await options.hooks.getContext(incoming) || {};
  try {
    return await options.hooks.handle({
      ...incoming,
      params: null,
      context
    }, async (request) => {
      for (const route of options.manifest.routes) {
        if (!route.pattern.test(request.path))
          continue;
        const response = route.type === "endpoint" ? await render_route(request, route) : await render_page(request, route, options);
        if (response) {
          if (response.status === 200) {
            if (!/(no-store|immutable)/.test(response.headers["cache-control"])) {
              const etag = `"${md5(response.body)}"`;
              if (request.headers["if-none-match"] === etag) {
                return {
                  status: 304,
                  headers: {},
                  body: null
                };
              }
              response.headers["etag"] = etag;
            }
          }
          return response;
        }
      }
      return await render_page(request, null, options);
    });
  } catch (e) {
    if (e && e.stack) {
      e.stack = await options.get_stack(e);
    }
    console.error(e && e.stack || e);
    return {
      status: 500,
      headers: {},
      body: options.dev ? e.stack : e.message
    };
  }
}
function run(fn) {
  return fn();
}
function blank_object() {
  return Object.create(null);
}
function run_all(fns) {
  fns.forEach(run);
}
function custom_event(type, detail) {
  const e = document.createEvent("CustomEvent");
  e.initCustomEvent(type, false, false, detail);
  return e;
}
let current_component;
function set_current_component(component) {
  current_component = component;
}
function get_current_component() {
  if (!current_component)
    throw new Error("Function called outside component initialization");
  return current_component;
}
function onMount(fn) {
  get_current_component().$$.on_mount.push(fn);
}
function afterUpdate(fn) {
  get_current_component().$$.after_update.push(fn);
}
function onDestroy(fn) {
  get_current_component().$$.on_destroy.push(fn);
}
function createEventDispatcher() {
  const component = get_current_component();
  return (type, detail) => {
    const callbacks = component.$$.callbacks[type];
    if (callbacks) {
      const event = custom_event(type, detail);
      callbacks.slice().forEach((fn) => {
        fn.call(component, event);
      });
    }
  };
}
function setContext(key, context) {
  get_current_component().$$.context.set(key, context);
}
const escaped = {
  '"': "&quot;",
  "'": "&#39;",
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;"
};
function escape$1(html) {
  return String(html).replace(/["'&<>]/g, (match2) => escaped[match2]);
}
function each(items, fn) {
  let str = "";
  for (let i = 0; i < items.length; i += 1) {
    str += fn(items[i], i);
  }
  return str;
}
const missing_component = {
  $$render: () => ""
};
function validate_component(component, name2) {
  if (!component || !component.$$render) {
    if (name2 === "svelte:component")
      name2 += " this={...}";
    throw new Error(`<${name2}> is not a valid SSR component. You may need to review your build config to ensure that dependencies are compiled, rather than imported as pre-compiled modules`);
  }
  return component;
}
let on_destroy;
function create_ssr_component(fn) {
  function $$render(result, props, bindings, slots, context) {
    const parent_component = current_component;
    const $$ = {
      on_destroy,
      context: new Map(parent_component ? parent_component.$$.context : context || []),
      on_mount: [],
      before_update: [],
      after_update: [],
      callbacks: blank_object()
    };
    set_current_component({$$});
    const html = fn(result, props, bindings, slots);
    set_current_component(parent_component);
    return html;
  }
  return {
    render: (props = {}, {$$slots = {}, context = new Map()} = {}) => {
      on_destroy = [];
      const result = {title: "", head: "", css: new Set()};
      const html = $$render(result, props, {}, $$slots, context);
      run_all(on_destroy);
      return {
        html,
        css: {
          code: Array.from(result.css).map((css2) => css2.code).join("\n"),
          map: null
        },
        head: result.title + result.head
      };
    },
    $$render
  };
}
function add_attribute(name2, value, boolean) {
  if (value == null || boolean && !value)
    return "";
  return ` ${name2}${value === true ? "" : `=${typeof value === "string" ? JSON.stringify(escape$1(value)) : `"${value}"`}`}`;
}
const Error$1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let {status} = $$props;
  let {error: error2} = $$props;
  if ($$props.status === void 0 && $$bindings.status && status !== void 0)
    $$bindings.status(status);
  if ($$props.error === void 0 && $$bindings.error && error2 !== void 0)
    $$bindings.error(error2);
  return `<h1>${escape$1(status)}</h1>

<p>${escape$1(error2.message)}</p>


${error2.stack ? `<pre>${escape$1(error2.stack)}</pre>` : ``}`;
});
var error = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Error$1
});
var root_svelte = "#svelte-announcer.svelte-1j55zn5{\n  position:absolute;\n  left:0;\n  top:0;\n  clip:rect(0 0 0 0);\n  -webkit-clip-path:inset(50%);\n          clip-path:inset(50%);\n  overflow:hidden;\n  white-space:nowrap;\n  width:1px;\n  height:1px\n}";
const css$3 = {
  code: "#svelte-announcer.svelte-1j55zn5{position:absolute;left:0;top:0;clip:rect(0 0 0 0);clip-path:inset(50%);overflow:hidden;white-space:nowrap;width:1px;height:1px}",
  map: `{"version":3,"file":"root.svelte","sources":["root.svelte"],"sourcesContent":["<!-- This file is generated by @sveltejs/kit \u2014 do not edit it! -->\\n<script>\\n\\timport { setContext, afterUpdate, onMount } from 'svelte';\\n\\timport ErrorComponent from \\"..\\\\\\\\components\\\\\\\\error.svelte\\";\\n\\n\\t// error handling\\n\\texport let status = undefined;\\n\\texport let error = undefined;\\n\\n\\t// stores\\n\\texport let stores;\\n\\texport let page;\\n\\n\\texport let components;\\n\\texport let props_0 = null;\\n\\texport let props_1 = null;\\n\\n\\tconst Layout = components[0];\\n\\n\\tsetContext('__svelte__', stores);\\n\\n\\t$: stores.page.set(page);\\n\\tafterUpdate(stores.page.notify);\\n\\n\\tlet mounted = false;\\n\\tlet navigated = false;\\n\\tlet title = null;\\n\\n\\tonMount(() => {\\n\\t\\tconst unsubscribe = stores.page.subscribe(() => {\\n\\t\\t\\tif (mounted) {\\n\\t\\t\\t\\tnavigated = true;\\n\\t\\t\\t\\ttitle = document.title;\\n\\t\\t\\t}\\n\\t\\t});\\n\\n\\t\\tmounted = true;\\n\\t\\treturn unsubscribe;\\n\\t});\\n</script>\\n\\n<Layout {...(props_0 || {})}>\\n\\t{#if error}\\n\\t\\t<ErrorComponent {status} {error}/>\\n\\t{:else}\\n\\t\\t<svelte:component this={components[1]} {...(props_1 || {})}/>\\n\\t{/if}\\n</Layout>\\n\\n{#if mounted}\\n\\t<div id=\\"svelte-announcer\\" aria-live=\\"assertive\\" aria-atomic=\\"true\\">\\n\\t\\t{#if navigated}\\n\\t\\t\\tNavigated to {title}\\n\\t\\t{/if}\\n\\t</div>\\n{/if}\\n\\n<style>\\n\\t#svelte-announcer {\\n\\t\\tposition: absolute;\\n\\t\\tleft: 0;\\n\\t\\ttop: 0;\\n\\t\\tclip: rect(0 0 0 0);\\n\\t\\tclip-path: inset(50%);\\n\\t\\toverflow: hidden;\\n\\t\\twhite-space: nowrap;\\n\\t\\twidth: 1px;\\n\\t\\theight: 1px;\\n\\t}\\n</style>"],"names":[],"mappings":"AA0DC,iBAAiB,eAAC,CAAC,AAClB,QAAQ,CAAE,QAAQ,CAClB,IAAI,CAAE,CAAC,CACP,GAAG,CAAE,CAAC,CACN,IAAI,CAAE,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CACnB,SAAS,CAAE,MAAM,GAAG,CAAC,CACrB,QAAQ,CAAE,MAAM,CAChB,WAAW,CAAE,MAAM,CACnB,KAAK,CAAE,GAAG,CACV,MAAM,CAAE,GAAG,AACZ,CAAC"}`
};
const Root = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let {status = void 0} = $$props;
  let {error: error2 = void 0} = $$props;
  let {stores} = $$props;
  let {page} = $$props;
  let {components: components2} = $$props;
  let {props_0 = null} = $$props;
  let {props_1 = null} = $$props;
  const Layout = components2[0];
  setContext("__svelte__", stores);
  afterUpdate(stores.page.notify);
  let mounted = false;
  let navigated = false;
  let title = null;
  onMount(() => {
    const unsubscribe = stores.page.subscribe(() => {
      if (mounted) {
        navigated = true;
        title = document.title;
      }
    });
    mounted = true;
    return unsubscribe;
  });
  if ($$props.status === void 0 && $$bindings.status && status !== void 0)
    $$bindings.status(status);
  if ($$props.error === void 0 && $$bindings.error && error2 !== void 0)
    $$bindings.error(error2);
  if ($$props.stores === void 0 && $$bindings.stores && stores !== void 0)
    $$bindings.stores(stores);
  if ($$props.page === void 0 && $$bindings.page && page !== void 0)
    $$bindings.page(page);
  if ($$props.components === void 0 && $$bindings.components && components2 !== void 0)
    $$bindings.components(components2);
  if ($$props.props_0 === void 0 && $$bindings.props_0 && props_0 !== void 0)
    $$bindings.props_0(props_0);
  if ($$props.props_1 === void 0 && $$bindings.props_1 && props_1 !== void 0)
    $$bindings.props_1(props_1);
  $$result.css.add(css$3);
  {
    stores.page.set(page);
  }
  return `


${validate_component(Layout, "Layout").$$render($$result, Object.assign(props_0 || {}), {}, {
    default: () => `${error2 ? `${validate_component(Error$1, "ErrorComponent").$$render($$result, {status, error: error2}, {}, {})}` : `${validate_component(components2[1] || missing_component, "svelte:component").$$render($$result, Object.assign(props_1 || {}), {}, {})}`}`
  })}

${mounted ? `<div id="${"svelte-announcer"}" aria-live="${"assertive"}" aria-atomic="${"true"}" class="${"svelte-1j55zn5"}">${navigated ? `Navigated to ${escape$1(title)}` : ``}</div>` : ``}`;
});
var user_hooks = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module"
});
const template = ({head, body}) => '<!DOCTYPE html>\n<html lang="en">\n	<head>\n		<meta charset="utf-8" />\n		<link rel="icon" href="/favicon.ico" />\n		<meta name="viewport" content="width=device-width, initial-scale=1" />\n		' + head + '\n	</head>\n	<body>\n		<div id="svelte">' + body + "</div>\n	</body>\n</html>\n";
function init({paths, prerendering}) {
}
const empty = () => ({});
const components = [
  () => Promise.resolve().then(function() {
    return index;
  }),
  () => Promise.resolve().then(function() {
    return questionsquizzs;
  }),
  () => Promise.resolve().then(function() {
    return formationgen;
  }),
  () => Promise.resolve().then(function() {
    return informatique;
  }),
  () => Promise.resolve().then(function() {
    return biologie;
  }),
  () => Promise.resolve().then(function() {
    return physique;
  }),
  () => Promise.resolve().then(function() {
    return annales;
  }),
  () => Promise.resolve().then(function() {
    return contact;
  }),
  () => Promise.resolve().then(function() {
    return fiches;
  }),
  () => Promise.resolve().then(function() {
    return forum;
  }),
  () => Promise.resolve().then(function() {
    return maths;
  }),
  () => Promise.resolve().then(function() {
    return quizz;
  })
];
const client_component_lookup = {".svelte/build/runtime/internal/start.js": "start-fa7f415b.js", "src/routes/index.svelte": "pages\\index.svelte-b836cf95.js", "src/routes/questionsquizzs.svelte": "pages\\questionsquizzs.svelte-18f20b5e.js", "src/routes/formationgen.svelte": "pages\\formationgen.svelte-d333cc24.js", "src/routes/informatique.svelte": "pages\\informatique.svelte-cf1d0988.js", "src/routes/biologie.svelte": "pages\\biologie.svelte-4b95bcf7.js", "src/routes/physique.svelte": "pages\\physique.svelte-90c8bf5a.js", "src/routes/annales.svelte": "pages\\annales.svelte-dacd3e4f.js", "src/routes/contact.svelte": "pages\\contact.svelte-7b5ca7dc.js", "src/routes/fiches.svelte": "pages\\fiches.svelte-59a8e4b8.js", "src/routes/forum.svelte": "pages\\forum.svelte-4545db23.js", "src/routes/maths.svelte": "pages\\maths.svelte-cd795eb9.js", "src/routes/quizz.svelte": "pages\\quizz.svelte-79ad7e9f.js"};
const manifest = {
  assets: [{file: "favicon.ico", size: 1150, type: "image/vnd.microsoft.icon"}, {file: "robots.txt", size: 67, type: "text/plain"}],
  layout: () => Promise.resolve().then(function() {
    return $layout$1;
  }),
  error: () => Promise.resolve().then(function() {
    return error;
  }),
  routes: [
    {
      type: "page",
      pattern: /^\/$/,
      params: empty,
      parts: [{id: "src/routes/index.svelte", load: components[0]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\index.svelte-b836cf95.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/questionsquizzs\/?$/,
      params: empty,
      parts: [{id: "src/routes/questionsquizzs.svelte", load: components[1]}],
      css: ["assets/start-eb72dec1.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\questionsquizzs.svelte-18f20b5e.js"]
    },
    {
      type: "page",
      pattern: /^\/formationgen\/?$/,
      params: empty,
      parts: [{id: "src/routes/formationgen.svelte", load: components[2]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\formationgen.svelte-d333cc24.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/informatique\/?$/,
      params: empty,
      parts: [{id: "src/routes/informatique.svelte", load: components[3]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\informatique.svelte-cf1d0988.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/biologie\/?$/,
      params: empty,
      parts: [{id: "src/routes/biologie.svelte", load: components[4]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\biologie.svelte-4b95bcf7.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/physique\/?$/,
      params: empty,
      parts: [{id: "src/routes/physique.svelte", load: components[5]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\physique.svelte-90c8bf5a.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/annales\/?$/,
      params: empty,
      parts: [{id: "src/routes/annales.svelte", load: components[6]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\annales.svelte-dacd3e4f.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/contact\/?$/,
      params: empty,
      parts: [{id: "src/routes/contact.svelte", load: components[7]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\contact.svelte-7b5ca7dc.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/fiches\/?$/,
      params: empty,
      parts: [{id: "src/routes/fiches.svelte", load: components[8]}],
      css: ["assets/start-eb72dec1.css", "assets/pages\\fiches.svelte-cfbb714a.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\fiches.svelte-59a8e4b8.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/forum\/?$/,
      params: empty,
      parts: [{id: "src/routes/forum.svelte", load: components[9]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\forum.svelte-4545db23.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/maths\/?$/,
      params: empty,
      parts: [{id: "src/routes/maths.svelte", load: components[10]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\maths.svelte-cd795eb9.js", "chunks/Header-fddb73fa.js"]
    },
    {
      type: "page",
      pattern: /^\/quizz\/?$/,
      params: empty,
      parts: [{id: "src/routes/quizz.svelte", load: components[11]}],
      css: ["assets/start-eb72dec1.css", "assets/Header-a7b1926f.css"],
      js: ["start-fa7f415b.js", "chunks/vendor-abf54270.js", "pages\\quizz.svelte-79ad7e9f.js", "chunks/Header-fddb73fa.js"]
    }
  ]
};
const get_hooks = (hooks2) => ({
  getContext: hooks2.getContext || (() => ({})),
  getSession: hooks2.getSession || (() => ({})),
  handle: hooks2.handle || ((request, render2) => render2(request))
});
const hooks = get_hooks(user_hooks);
function render(request, {
  paths = {base: "", assets: "/."},
  local = false,
  dependencies: dependencies2,
  only_render_prerenderable_pages = false,
  get_static_file
} = {}) {
  return ssr({
    ...request,
    host: request.headers["host"]
  }, {
    paths,
    local,
    template,
    manifest,
    target: "#svelte",
    entry: "/./_app/start-fa7f415b.js",
    root: Root,
    hooks,
    dev: false,
    amp: false,
    dependencies: dependencies2,
    only_render_prerenderable_pages,
    app_dir: "_app",
    get_component_path: (id) => "/./_app/" + client_component_lookup[id],
    get_stack: (error2) => error2.stack,
    get_static_file,
    get_amp_css: (dep) => amp_css_lookup[dep],
    ssr: true,
    router: true,
    hydrate: true
  });
}
var Inscription_svelte = ".svelte-izy1yp.svelte-izy1yp{\n  z-index:100\n}\n\n.backdrop.svelte-izy1yp.svelte-izy1yp{\n  width:100%;\n  height:100%;\n  position:fixed;\n  background:rgba(0, 0, 0, 0.8)\n}\n\n.modal.svelte-izy1yp.svelte-izy1yp{\n  padding:10px;\n  border-radius:10px;\n  max-width:600px;\n  margin:5% auto;\n  text-align:left;\n  background:white\n}\n\n.title.svelte-izy1yp.svelte-izy1yp{\n  text-align:center\n}\n\n.promo.svelte-izy1yp .modal.svelte-izy1yp{\n  background:crimson;\n  color:white\n}";
const css$2 = {
  code: ".svelte-izy1yp.svelte-izy1yp{z-index:100}.backdrop.svelte-izy1yp.svelte-izy1yp{width:100%;height:100%;position:fixed;background:rgba(0, 0, 0, 0.8)}.modal.svelte-izy1yp.svelte-izy1yp{padding:10px;border-radius:10px;max-width:600px;margin:5% auto;text-align:left;background:white}.title.svelte-izy1yp.svelte-izy1yp{text-align:center}.promo.svelte-izy1yp .modal.svelte-izy1yp{background:crimson;color:white}",
  map: `{"version":3,"file":"Inscription.svelte","sources":["Inscription.svelte"],"sourcesContent":["<script>\\r\\n\\texport let showModal = false;\\r\\n\\texport let isPromo = false;\\r\\n\\t/* import supabase from '../lib/db.js';\\r\\n\\timport { session } from '$app/stores'; */\\r\\n\\r\\n\\tlet email, password, nom, prenom, niveau;\\r\\n\\r\\n\\t/* async function signUp() {\\r\\n\\t\\tconst { user, session: sesh, error } = await supabase.auth.signUp({\\r\\n\\t\\t\\temail,\\r\\n\\t\\t\\tpassword\\r\\n\\t\\t});\\r\\n\\t\\tif (error) alert(error, message);\\r\\n\\t\\tconsole.log(user, session, error);\\r\\n\\t\\t$session = sesh;\\r\\n\\t} */\\r\\n</script>\\r\\n\\r\\n<!-- {#if showModal}\\r\\n\\t<div class=\\"backdrop\\" class:promo={isPromo} on:click|self>\\r\\n\\t\\t<div class=\\"modal\\">\\r\\n\\t\\t\\t<div class=\\"title\\">\\r\\n\\t\\t\\t\\t<slot name=\\"title\\">\\r\\n\\t\\t\\t\\t\\t<h3>Default Title</h3>\\r\\n\\t\\t\\t\\t</slot>\\r\\n\\t\\t\\t</div>\\r\\n\\t\\t\\t<slot />\\r\\n\\t\\t</div>\\r\\n\\t</div>\\r\\n{/if} -->\\r\\n\\r\\n{#if showModal}\\r\\n\\t<div class=\\"backdrop\\" class:promo={isPromo} on:click|self>\\r\\n\\t\\t<div class=\\"modal\\">\\r\\n\\t\\t\\t<head>\\r\\n\\t\\t\\t\\t<title>Inscription</title>\\r\\n\\t\\t\\t</head>\\r\\n\\t\\t\\t<form class=\\"overflow-auto\\">\\r\\n\\t\\t\\t\\t<div class=\\"title\\">\\r\\n\\t\\t\\t\\t\\t<h2 class=\\"text-gray-900 text-lg font-medium title-font mb-5\\">Inscription</h2>\\r\\n\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t<div class=\\"flex flex-wrap\\">\\r\\n\\t\\t\\t\\t\\t<div class=\\"relative mb-4 p-4 md:w-1/2\\">\\r\\n\\t\\t\\t\\t\\t\\t<label for=\\"nom\\" class=\\"ml-3 leading-7 text-sm text-gray-400\\" tablindex=\\"0\\">Nom</label>\\r\\n\\t\\t\\t\\t\\t\\t<input\\r\\n\\t\\t\\t\\t\\t\\t\\ttype=\\"text\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tid=\\"nom\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tname=\\"Nom\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tclass=\\"ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tbind:value={nom}\\r\\n\\t\\t\\t\\t\\t\\t/>\\r\\n\\t\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t\\t<div class=\\"relative mb-4 p-4 md:w-1/2\\">\\r\\n\\t\\t\\t\\t\\t\\t<label for=\\"pr\xE9nom\\" class=\\"ml-3 leading-7 text-sm text-gray-400\\">Pr\xE9nom</label>\\r\\n\\t\\t\\t\\t\\t\\t<input\\r\\n\\t\\t\\t\\t\\t\\t\\ttype=\\"text\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tid=\\"pr\xE9nom\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tname=\\"Pr\xE9nom\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tclass=\\"ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tbind:value={prenom}\\r\\n\\t\\t\\t\\t\\t\\t/>\\r\\n\\t\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t<div class=\\"flex flex-wrap\\">\\r\\n\\t\\t\\t\\t\\t<div class=\\"relative mb-4 justify-center\\">\\r\\n\\t\\t\\t\\t\\t\\t<label for=\\"niveau\\" class=\\"ml-7 leading-7 text-sm text-gray-400\\">Niveau d'\xE9tude</label>\\r\\n\\t\\t\\t\\t\\t\\t<select\\r\\n\\t\\t\\t\\t\\t\\t\\tid=\\"niveau\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tclass=\\"rounded border appearance-none border-gray-300 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 text-base pl-3 pr-10\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tbind:value={niveau}\\r\\n\\t\\t\\t\\t\\t\\t>\\r\\n\\t\\t\\t\\t\\t\\t\\t<option>L1</option>\\r\\n\\t\\t\\t\\t\\t\\t\\t<option>L2</option>\\r\\n\\t\\t\\t\\t\\t\\t\\t<option>L3</option>\\r\\n\\t\\t\\t\\t\\t\\t\\t<option>M1</option>\\r\\n\\t\\t\\t\\t\\t\\t\\t<option>M2</option>\\r\\n\\t\\t\\t\\t\\t\\t</select>\\r\\n\\t\\t\\t\\t\\t\\t<span\\r\\n\\t\\t\\t\\t\\t\\t\\tclass=\\"absolute right-0 top-0 h-full w-10 text-center text-gray-600 pointer-events-none flex items-center justify-center\\"\\r\\n\\t\\t\\t\\t\\t\\t>\\r\\n\\t\\t\\t\\t\\t\\t\\t<svg\\r\\n\\t\\t\\t\\t\\t\\t\\t\\tfill=\\"none\\"\\r\\n\\t\\t\\t\\t\\t\\t\\t\\tstroke=\\"currentColor\\"\\r\\n\\t\\t\\t\\t\\t\\t\\t\\tstroke-linecap=\\"round\\"\\r\\n\\t\\t\\t\\t\\t\\t\\t\\tstroke-linejoin=\\"round\\"\\r\\n\\t\\t\\t\\t\\t\\t\\t\\tstroke-width=\\"2\\"\\r\\n\\t\\t\\t\\t\\t\\t\\t\\tclass=\\"w-4 h-4\\"\\r\\n\\t\\t\\t\\t\\t\\t\\t\\tviewBox=\\"0 0 24 24\\"\\r\\n\\t\\t\\t\\t\\t\\t\\t>\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t<path d=\\"M6 9l6 6 6-6\\" />\\r\\n\\t\\t\\t\\t\\t\\t\\t</svg>\\r\\n\\t\\t\\t\\t\\t\\t</span>\\r\\n\\t\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t<div class=\\"flex flex-wrap px-4\\">\\r\\n\\t\\t\\t\\t\\t<div class=\\"relative w-full mb-4 mt-3\\">\\r\\n\\t\\t\\t\\t\\t\\t<label for=\\"email\\" class=\\"ml-3 leading-7 text-sm text-gray-400\\">Email</label>\\r\\n\\t\\t\\t\\t\\t\\t<input\\r\\n\\t\\t\\t\\t\\t\\t\\ttype=\\"email\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tid=\\"email\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tname=\\"email\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tautocomplete=\\"email\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tclass=\\"ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tplaceholder=\\"exemple@domaine.com\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tbind:value={email}\\r\\n\\t\\t\\t\\t\\t\\t/>\\r\\n\\t\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t<div class=\\"flex flex-wrap\\">\\r\\n\\t\\t\\t\\t\\t<div class=\\"relative mb-4 p-4 md:w-1/2\\">\\r\\n\\t\\t\\t\\t\\t\\t<label for=\\"password\\" class=\\"ml-3 leading-7 text-sm text-gray-400\\">Mot de passe</label>\\r\\n\\t\\t\\t\\t\\t\\t<input\\r\\n\\t\\t\\t\\t\\t\\t\\tid=\\"password\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tname=\\"password\\"\\r\\n\\t\\t\\t\\t\\t\\t\\ttype=\\"password\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tautocomplete=\\"current-password\\"\\r\\n\\t\\t\\t\\t\\t\\t\\trequired\\r\\n\\t\\t\\t\\t\\t\\t\\tclass=\\"appearance-none rounded-none relative block ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tplaceholder=\\"Password\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tbind:value={password}\\r\\n\\t\\t\\t\\t\\t\\t/>\\r\\n\\t\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t\\t<div class=\\"relative mb-4 p-4 md:w-1/2\\">\\r\\n\\t\\t\\t\\t\\t\\t<label for=\\"password\\" class=\\"ml-3 leading-7 text-sm text-gray-400\\">Confirmation</label>\\r\\n\\t\\t\\t\\t\\t\\t<input\\r\\n\\t\\t\\t\\t\\t\\t\\tid=\\"password\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tname=\\"password\\"\\r\\n\\t\\t\\t\\t\\t\\t\\ttype=\\"password\\"\\r\\n\\t\\t\\t\\t\\t\\t\\trequired\\r\\n\\t\\t\\t\\t\\t\\t\\tclass=\\"appearance-none rounded-none relative block ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out\\"\\r\\n\\t\\t\\t\\t\\t\\t\\tbind:value={password}\\r\\n\\t\\t\\t\\t\\t\\t\\tplaceholder=\\"Password\\"\\r\\n\\t\\t\\t\\t\\t\\t/>\\r\\n\\t\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t\\t<div class=\\"flex justify-center mb-3\\">\\r\\n\\t\\t\\t\\t\\t<button\\r\\n\\t\\t\\t\\t\\t\\tclass=\\"text-white bg-indigo-500 border-0 py-2 px-8 focus:outline-none hover:bg-indigo-600 rounded text-lg\\"\\r\\n\\t\\t\\t\\t\\t\\t>Valider</button\\r\\n\\t\\t\\t\\t\\t>\\r\\n\\t\\t\\t\\t</div>\\r\\n\\t\\t\\t</form>\\r\\n\\t\\t\\t<div class=\\"flex justify-center\\">\\r\\n\\t\\t\\t\\t<p class=\\"text-gray-900 text-base font-light mb-2\\">\\r\\n\\t\\t\\t\\t\\t----------- ou bien se connecter avec -----------\\r\\n\\t\\t\\t\\t</p>\\r\\n\\t\\t\\t</div>\\r\\n\\t\\t\\t<div class=\\"flex justify-center items-center space-x-2 mb-2\\">\\r\\n\\t\\t\\t\\t<a href=\\"https://github.com\\" class=\\"github w-8\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\"\\r\\n\\t\\t\\t\\t\\t><svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"0 0 24 24\\"\\r\\n\\t\\t\\t\\t\\t\\t><path\\r\\n\\t\\t\\t\\t\\t\\t\\tfill=\\"currentColor\\"\\r\\n\\t\\t\\t\\t\\t\\t\\td=\\"M12 .5C5.37.5 0 5.78 0 12.292c0 5.211 3.438 9.63 8.205 11.188.6.111.82-.254.82-.567 0-.28-.01-1.022-.015-2.005-3.338.711-4.042-1.582-4.042-1.582-.546-1.361-1.335-1.725-1.335-1.725-1.087-.731.084-.716.084-.716 1.205.082 1.838 1.215 1.838 1.215 1.07 1.803 2.809 1.282 3.495.981.108-.763.417-1.282.76-1.577-2.665-.295-5.466-1.309-5.466-5.827 0-1.287.465-2.339 1.235-3.164-.135-.298-.54-1.497.105-3.121 0 0 1.005-.316 3.3 1.209.96-.262 1.98-.392 3-.398 1.02.006 2.04.136 3 .398 2.28-1.525 3.285-1.209 3.285-1.209.645 1.624.24 2.823.12 3.121.765.825 1.23 1.877 1.23 3.164 0 4.53-2.805 5.527-5.475 5.817.42.354.81 1.077.81 2.182 0 1.578-.015 2.846-.015 3.229 0 .309.21.678.825.56C20.565 21.917 24 17.495 24 12.292 24 5.78 18.627.5 12 .5z\\"\\r\\n\\t\\t\\t\\t\\t\\t/></svg\\r\\n\\t\\t\\t\\t\\t></a\\r\\n\\t\\t\\t\\t>\\r\\n\\t\\t\\t\\t<a\\r\\n\\t\\t\\t\\t\\thref=\\"https://facebook.com\\"\\r\\n\\t\\t\\t\\t\\tclass=\\"facebook w-10\\"\\r\\n\\t\\t\\t\\t\\ttarget=\\"_blank\\"\\r\\n\\t\\t\\t\\t\\trel=\\"noopener noreferrer\\"\\r\\n\\t\\t\\t\\t\\t><svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"0 0 30 30\\">\\r\\n\\t\\t\\t\\t\\t\\t<path\\r\\n\\t\\t\\t\\t\\t\\t\\td=\\"M15,3C8.373,3,3,8.373,3,15c0,6.016,4.432,10.984,10.206,11.852V18.18h-2.969v-3.154h2.969v-2.099c0-3.475,1.693-5,4.581-5 c1.383,0,2.115,0.103,2.461,0.149v2.753h-1.97c-1.226,0-1.654,1.163-1.654,2.473v1.724h3.593L19.73,18.18h-3.106v8.697 C22.481,26.083,27,21.075,27,15C27,8.373,21.627,3,15,3z\\"\\r\\n\\t\\t\\t\\t\\t\\t/></svg\\r\\n\\t\\t\\t\\t\\t>\\r\\n\\t\\t\\t\\t</a>\\r\\n\\t\\t\\t\\t<a\\r\\n\\t\\t\\t\\t\\thref=\\"https://www.google.com\\"\\r\\n\\t\\t\\t\\t\\tclass=\\"google w-9\\"\\r\\n\\t\\t\\t\\t\\ttarget=\\"_blank\\"\\r\\n\\t\\t\\t\\t\\trel=\\"noopener noreferrer\\"\\r\\n\\t\\t\\t\\t\\t><svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"0 0 50 50\\"\\r\\n\\t\\t\\t\\t\\t\\t><path\\r\\n\\t\\t\\t\\t\\t\\t\\td=\\"M 25.996094 48 C 13.3125 48 2.992188 37.683594 2.992188 25 C 2.992188 12.316406 13.3125 2 25.996094 2 C 31.742188 2 37.242188 4.128906 41.488281 7.996094 L 42.261719 8.703125 L 34.675781 16.289063 L 33.972656 15.6875 C 31.746094 13.78125 28.914063 12.730469 25.996094 12.730469 C 19.230469 12.730469 13.722656 18.234375 13.722656 25 C 13.722656 31.765625 19.230469 37.269531 25.996094 37.269531 C 30.875 37.269531 34.730469 34.777344 36.546875 30.53125 L 24.996094 30.53125 L 24.996094 20.175781 L 47.546875 20.207031 L 47.714844 21 C 48.890625 26.582031 47.949219 34.792969 43.183594 40.667969 C 39.238281 45.53125 33.457031 48 25.996094 48 Z\\"\\r\\n\\t\\t\\t\\t\\t\\t/></svg\\r\\n\\t\\t\\t\\t\\t>\\r\\n\\t\\t\\t\\t</a>\\r\\n\\t\\t\\t</div>\\r\\n\\t\\t\\t<div class=\\"flex justify-center\\">\\r\\n\\t\\t\\t\\t<p class=\\"text-gray-900 text-base font-light mb-5\\">\\r\\n\\t\\t\\t\\t\\tD\xE9j\xE0 membre ? <a href=\\"Connexion\\">Connecte-toi !</a>\\r\\n\\t\\t\\t\\t</p>\\r\\n\\t\\t\\t</div>\\r\\n\\t\\t</div>\\r\\n\\t</div>\\r\\n{/if}\\r\\n\\r\\n<style>\\r\\n\\t* {\\r\\n\\t\\tz-index: 100;\\r\\n\\t}\\r\\n\\t.backdrop {\\r\\n\\t\\twidth: 100%;\\r\\n\\t\\theight: 100%;\\r\\n\\t\\tposition: fixed;\\r\\n\\t\\tbackground: rgba(0, 0, 0, 0.8);\\r\\n\\t}\\r\\n\\t.modal {\\r\\n\\t\\tpadding: 10px;\\r\\n\\t\\tborder-radius: 10px;\\r\\n\\t\\tmax-width: 600px;\\r\\n\\t\\tmargin: 5% auto;\\r\\n\\t\\ttext-align: left;\\r\\n\\t\\tbackground: white;\\r\\n\\t}\\r\\n\\t.title {\\r\\n\\t\\ttext-align: center;\\r\\n\\t}\\r\\n\\t.promo .modal {\\r\\n\\t\\tbackground: crimson;\\r\\n\\t\\tcolor: white;\\r\\n\\t}\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA8LC,4BAAE,CAAC,AACF,OAAO,CAAE,GAAG,AACb,CAAC,AACD,SAAS,4BAAC,CAAC,AACV,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,QAAQ,CAAE,KAAK,CACf,UAAU,CAAE,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,AAC/B,CAAC,AACD,MAAM,4BAAC,CAAC,AACP,OAAO,CAAE,IAAI,CACb,aAAa,CAAE,IAAI,CACnB,SAAS,CAAE,KAAK,CAChB,MAAM,CAAE,EAAE,CAAC,IAAI,CACf,UAAU,CAAE,IAAI,CAChB,UAAU,CAAE,KAAK,AAClB,CAAC,AACD,MAAM,4BAAC,CAAC,AACP,UAAU,CAAE,MAAM,AACnB,CAAC,AACD,oBAAM,CAAC,MAAM,cAAC,CAAC,AACd,UAAU,CAAE,OAAO,CACnB,KAAK,CAAE,KAAK,AACb,CAAC"}`
};
const Inscription = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let {showModal = false} = $$props;
  let {isPromo = false} = $$props;
  let email, password, nom, prenom, niveau;
  if ($$props.showModal === void 0 && $$bindings.showModal && showModal !== void 0)
    $$bindings.showModal(showModal);
  if ($$props.isPromo === void 0 && $$bindings.isPromo && isPromo !== void 0)
    $$bindings.isPromo(isPromo);
  $$result.css.add(css$2);
  return `

${showModal ? `<div class="${["backdrop svelte-izy1yp", isPromo ? "promo" : ""].join(" ").trim()}"><div class="${"modal svelte-izy1yp"}"><head class="${"svelte-izy1yp"}"><title class="${"svelte-izy1yp"}">Inscription</title></head>
			<form class="${"overflow-auto svelte-izy1yp"}"><div class="${"title svelte-izy1yp"}"><h2 class="${"text-gray-900 text-lg font-medium title-font mb-5 svelte-izy1yp"}">Inscription</h2></div>
				<div class="${"flex flex-wrap svelte-izy1yp"}"><div class="${"relative mb-4 p-4 md:w-1/2 svelte-izy1yp"}"><label for="${"nom"}" class="${"ml-3 leading-7 text-sm text-gray-400 svelte-izy1yp"}" tablindex="${"0"}">Nom</label>
						<input type="${"text"}" id="${"nom"}" name="${"Nom"}" class="${"ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out svelte-izy1yp"}"${add_attribute("value", nom, 1)}></div>
					<div class="${"relative mb-4 p-4 md:w-1/2 svelte-izy1yp"}"><label for="${"pr\xE9nom"}" class="${"ml-3 leading-7 text-sm text-gray-400 svelte-izy1yp"}">Pr\xE9nom</label>
						<input type="${"text"}" id="${"pr\xE9nom"}" name="${"Pr\xE9nom"}" class="${"ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out svelte-izy1yp"}"${add_attribute("value", prenom, 1)}></div></div>
				<div class="${"flex flex-wrap svelte-izy1yp"}"><div class="${"relative mb-4 justify-center svelte-izy1yp"}"><label for="${"niveau"}" class="${"ml-7 leading-7 text-sm text-gray-400 svelte-izy1yp"}">Niveau d&#39;\xE9tude</label>
						<select id="${"niveau"}" class="${"rounded border appearance-none border-gray-300 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 text-base pl-3 pr-10 svelte-izy1yp"}"${add_attribute("value", niveau, 1)}><option value="${"L1"}" class="${"svelte-izy1yp"}">L1</option><option value="${"L2"}" class="${"svelte-izy1yp"}">L2</option><option value="${"L3"}" class="${"svelte-izy1yp"}">L3</option><option value="${"M1"}" class="${"svelte-izy1yp"}">M1</option><option value="${"M2"}" class="${"svelte-izy1yp"}">M2</option></select>
						<span class="${"absolute right-0 top-0 h-full w-10 text-center text-gray-600 pointer-events-none flex items-center justify-center svelte-izy1yp"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-4 h-4 svelte-izy1yp"}" viewBox="${"0 0 24 24"}"><path d="${"M6 9l6 6 6-6"}" class="${"svelte-izy1yp"}"></path></svg></span></div></div>
				<div class="${"flex flex-wrap px-4 svelte-izy1yp"}"><div class="${"relative w-full mb-4 mt-3 svelte-izy1yp"}"><label for="${"email"}" class="${"ml-3 leading-7 text-sm text-gray-400 svelte-izy1yp"}">Email</label>
						<input type="${"email"}" id="${"email"}" name="${"email"}" autocomplete="${"email"}" class="${"ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out svelte-izy1yp"}" placeholder="${"exemple@domaine.com"}"${add_attribute("value", email, 1)}></div></div>
				<div class="${"flex flex-wrap svelte-izy1yp"}"><div class="${"relative mb-4 p-4 md:w-1/2 svelte-izy1yp"}"><label for="${"password"}" class="${"ml-3 leading-7 text-sm text-gray-400 svelte-izy1yp"}">Mot de passe</label>
						<input id="${"password"}" name="${"password"}" type="${"password"}" autocomplete="${"current-password"}" required class="${"appearance-none rounded-none relative block ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out svelte-izy1yp"}" placeholder="${"Password"}"${add_attribute("value", password, 1)}></div>
					<div class="${"relative mb-4 p-4 md:w-1/2 svelte-izy1yp"}"><label for="${"password"}" class="${"ml-3 leading-7 text-sm text-gray-400 svelte-izy1yp"}">Confirmation</label>
						<input id="${"password"}" name="${"password"}" type="${"password"}" required class="${"appearance-none rounded-none relative block ml-1 mt-1 w-full bg-gray-600 bg-opacity-20 focus:bg-transparent focus:ring-2 focus:ring-indigo-900 rounded border border-gray-600 focus:border-indigo-500 text-base outline-none text-gray-500 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out svelte-izy1yp"}" placeholder="${"Password"}"${add_attribute("value", password, 1)}></div></div>
				<div class="${"flex justify-center mb-3 svelte-izy1yp"}"><button class="${"text-white bg-indigo-500 border-0 py-2 px-8 focus:outline-none hover:bg-indigo-600 rounded text-lg svelte-izy1yp"}">Valider</button></div></form>
			<div class="${"flex justify-center svelte-izy1yp"}"><p class="${"text-gray-900 text-base font-light mb-2 svelte-izy1yp"}">----------- ou bien se connecter avec -----------
				</p></div>
			<div class="${"flex justify-center items-center space-x-2 mb-2 svelte-izy1yp"}"><a href="${"https://github.com"}" class="${"github w-8 svelte-izy1yp"}" target="${"_blank"}" rel="${"noopener noreferrer"}"><svg xmlns="${"http://www.w3.org/2000/svg"}" viewBox="${"0 0 24 24"}" class="${"svelte-izy1yp"}"><path fill="${"currentColor"}" d="${"M12 .5C5.37.5 0 5.78 0 12.292c0 5.211 3.438 9.63 8.205 11.188.6.111.82-.254.82-.567 0-.28-.01-1.022-.015-2.005-3.338.711-4.042-1.582-4.042-1.582-.546-1.361-1.335-1.725-1.335-1.725-1.087-.731.084-.716.084-.716 1.205.082 1.838 1.215 1.838 1.215 1.07 1.803 2.809 1.282 3.495.981.108-.763.417-1.282.76-1.577-2.665-.295-5.466-1.309-5.466-5.827 0-1.287.465-2.339 1.235-3.164-.135-.298-.54-1.497.105-3.121 0 0 1.005-.316 3.3 1.209.96-.262 1.98-.392 3-.398 1.02.006 2.04.136 3 .398 2.28-1.525 3.285-1.209 3.285-1.209.645 1.624.24 2.823.12 3.121.765.825 1.23 1.877 1.23 3.164 0 4.53-2.805 5.527-5.475 5.817.42.354.81 1.077.81 2.182 0 1.578-.015 2.846-.015 3.229 0 .309.21.678.825.56C20.565 21.917 24 17.495 24 12.292 24 5.78 18.627.5 12 .5z"}" class="${"svelte-izy1yp"}"></path></svg></a>
				<a href="${"https://facebook.com"}" class="${"facebook w-10 svelte-izy1yp"}" target="${"_blank"}" rel="${"noopener noreferrer"}"><svg xmlns="${"http://www.w3.org/2000/svg"}" viewBox="${"0 0 30 30"}" class="${"svelte-izy1yp"}"><path d="${"M15,3C8.373,3,3,8.373,3,15c0,6.016,4.432,10.984,10.206,11.852V18.18h-2.969v-3.154h2.969v-2.099c0-3.475,1.693-5,4.581-5 c1.383,0,2.115,0.103,2.461,0.149v2.753h-1.97c-1.226,0-1.654,1.163-1.654,2.473v1.724h3.593L19.73,18.18h-3.106v8.697 C22.481,26.083,27,21.075,27,15C27,8.373,21.627,3,15,3z"}" class="${"svelte-izy1yp"}"></path></svg></a>
				<a href="${"https://www.google.com"}" class="${"google w-9 svelte-izy1yp"}" target="${"_blank"}" rel="${"noopener noreferrer"}"><svg xmlns="${"http://www.w3.org/2000/svg"}" viewBox="${"0 0 50 50"}" class="${"svelte-izy1yp"}"><path d="${"M 25.996094 48 C 13.3125 48 2.992188 37.683594 2.992188 25 C 2.992188 12.316406 13.3125 2 25.996094 2 C 31.742188 2 37.242188 4.128906 41.488281 7.996094 L 42.261719 8.703125 L 34.675781 16.289063 L 33.972656 15.6875 C 31.746094 13.78125 28.914063 12.730469 25.996094 12.730469 C 19.230469 12.730469 13.722656 18.234375 13.722656 25 C 13.722656 31.765625 19.230469 37.269531 25.996094 37.269531 C 30.875 37.269531 34.730469 34.777344 36.546875 30.53125 L 24.996094 30.53125 L 24.996094 20.175781 L 47.546875 20.207031 L 47.714844 21 C 48.890625 26.582031 47.949219 34.792969 43.183594 40.667969 C 39.238281 45.53125 33.457031 48 25.996094 48 Z"}" class="${"svelte-izy1yp"}"></path></svg></a></div>
			<div class="${"flex justify-center svelte-izy1yp"}"><p class="${"text-gray-900 text-base font-light mb-5 svelte-izy1yp"}">D\xE9j\xE0 membre ? <a href="${"Connexion"}" class="${"svelte-izy1yp"}">Connecte-toi !</a></p></div></div></div>` : ``}`;
});
const Header = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let showModal = false;
  let $$settled;
  let $$rendered;
  do {
    $$settled = true;
    $$rendered = `${validate_component(Inscription, "Inscription").$$render($$result, {showModal}, {}, {})}
	

<div class="${"z-10 relative bg-white"}"><div class="${"max-w-full border-b-2 mx-auto p-5 sm:p-5"}"><div class="${"flex justify-between items-center md:justify-start md:space-x-10"}"><div class="${"flex-1 flex justify-center md:flex-initial"}"><a class="${"flex w-20 title-font font-medium items-center text-gray-900 md:mb-0"}" href="${"."}"><img class="${"w-5/6 object-cover object-center rounded"}" alt="${"mascotte"}" src="${"https://team-rcv.xyz/lpc/castorhead.png"}">
					<span class="${"flex ml-3 text-xl"}">LPC</span></a></div>
			<div class="${"-mr-2 -my-2 md:hidden"}"><button type="${"button"}" class="${[
      "bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500",
      ""
    ].join(" ").trim()}" aria-expanded="${"false"}"><span class="${"sr-only"}">Open menu</span>
					
					<svg class="${"h-6 w-6"}" xmlns="${"http://www.w3.org/2000/svg"}" fill="${"none"}" viewBox="${"0 0 24 24"}" stroke="${"currentColor"}" aria-hidden="${"true"}"><path stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" d="${"M4 6h16M4 12h16M4 18h16"}"></path></svg></button></div>
			<nav class="${"hidden md:flex space-x-10 pl-5 border-gray-100 py-2 border-l-2 border-gray-400"}"><div class="${"relative space-x-3"}"><a href="${"quizz"}" class="${"text-base font-medium text-gray-500 hover:text-gray-900"}">Quizz
					</a>
					<a href="${"fiches"}" class="${"text-base font-medium text-gray-500 hover:text-gray-900"}">Fiches
					</a>
					<a href="${"annales"}" class="${"text-base font-medium text-gray-500 hover:text-gray-900"}">Annales
					</a>
					<a href="${"forum"}" class="${"text-base font-medium text-gray-500 hover:text-gray-900"}">Forum
					</a>
					<a href="${"contact"}" class="${"text-base font-medium text-gray-500 hover:text-gray-900"}">Contact
					</a></div></nav>
			<div class="${"hidden md:flex items-center justify-end md:flex-1 lg:w-0"}"><button class="${"inline-flex items-center bg-gray-100 border-0 py-1 px-3 focus:outline-none hover:bg-gray-200 rounded text-base mt-4 md:mt-0 mr-1"}">Inscription
					<svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-4 h-4 ml-1"}" viewBox="${"0 0 24 24"}"><path d="${"M5 12h14M12 5l7 7-7 7"}"></path></svg></button>
				<button class="${"inline-flex items-center bg-gray-100 border-0 py-1 px-3 focus:outline-none hover:bg-gray-200 rounded text-base mt-4 md:mt-0"}">Connexion
					<svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-4 h-4 ml-1"}" viewBox="${"0 0 24 24"}"><path d="${"M5 12h14M12 5l7 7-7 7"}"></path></svg></button></div></div></div>
	${``}

	</div>`;
  } while (!$$settled);
  return $$rendered;
});
const Routes = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><title>LPC Accueil</title></head>

${validate_component(Header, "Header").$$render($$result, {}, {}, {})}

<section class="${"text-gray-600 body-font"}"><div class="${"container mx-auto flex flex-col min-h-screen justify-center items-center"}"><img class="${"lg:w-2/6 md:w-3/6 w-5/6 mb-10 object-cover object-center rounded"}" alt="${"Castor"}" src="${"https://team-rcv.xyz/lpc/Castor.png"}"></div></section>
<section class="${"text-gray-600 body-font bg-indigo-100 bg-opacity-50"}"><div class="${"container mx-auto flex flex-col px-5 pt-20 pb-10 justify-center items-center"}"><div class="${"w-full md:w-2/3 flex flex-col mb-1 items-center text-center"}"><h1 class="${"uppercase tracking-wide title-font sm:text-4xl text-3xl mb-4 font-medium text-gray-900"}">Votre meilleur moyen d&#39;\xE9tudier !
			</h1>
			<p class="${"mb-10 leading-relaxed"}">Les P\xE8res Castors est une application web vous permettant de travailler sans y penser !
				Notre site interactif vous permet de vous entrainer gr\xE2ce \xE0 des quizz valid\xE9s par la
				communaut\xE9 ! Des fiches, des annales et bient\xF4t un forum seront \xE9galement \xE0 votre
				disposition pour vous aider dans votre apprentissage. Vous pouvez participer au
				d\xE9veloppement de la communaut\xE9 en y apportant votre petit grain de sel et ajouter des quizz
				ou des fiches \xE0 notre site !
			</p>
			<h1 class="${"title-font sm:text-3xl text-2xl mb-4 font-medium text-gray-900"}">Apprenons tous ensembles !
			</h1>
			<p class="${"mb-10 leading-relaxed"}">Ce site comporte de nombreux onglets qui vous permettront d\u2019apprendre vos cours de
				diff\xE9rentes mani\xE8res ! Les quizz vous permettront de r\xE9viser d\u2019une mani\xE8re rapide et
				efficace, gr\xE2ce \xE0 leur simplicit\xE9 d\u2019utilisation presque d\xE9routante. Les fiches cr\xE9\xE9es par la
				communaut\xE9 pourront vous servir dans vos r\xE9visions et aborder toutes les notions que vous
				avez besoins. L\u2019onglet \xAB Annales \xBB est r\xE9serv\xE9e pour les copies d\u2019examens, il vous sera tr\xE8s
				utile pour avoir une id\xE9e de vos futures \xE9preuves !
			</p>
			<h1 class="${"title-font sm:text-3xl text-2xl mb-4 font-medium text-gray-900"}">A propos de nous !
			</h1>
			<p class="${"leading-relaxed"}">Les P\xE8res Castors est un projet qui a commenc\xE9 en 2021 par un petit groupe d\u2019\xE9tudiants en
				classe pr\xE9paratoire d\u2019\xE9cole d\u2019ing\xE9nieur. Notre objectif est de cr\xE9er un site qui permettrait
				\xE0 tous les \xE9tudiants, \xE0 commencer par notre \xE9cole, jusqu\u2019\xE0 plus tard toute la France,
				d\u2019apprendre plus facilement et de travailler en communaut\xE9 !
			</p></div></div></section>
<section class="${"text-gray-600 body-font -"}"><div class="${"container mx-auto flex flex-col px-5 py-24 justify-center items-center"}"><h1 class="${"uppercase tracking-wide title-font sm:text-4xl text-3xl mb-4 font-medium text-gray-900"}">Vid\xE9o Trailer
		</h1>
		<video src="${"https://team-rcv.xyz/lpc2/videoLPC.MP4"}" type="${"video/mp4"}" controls width="${"1270"}"></video></div></section>
<section class="${"text-gray-600 body-font"}"><div class="${"container mx-auto flex flex-col px-5 pb-10 justify-center items-center"}"><div class="${"flex"}"><button class="${"bg-gray-100 inline-flex py-3 px-5 rounded-lg items-center hover:bg-gray-200 focus:outline-none"}"><svg xmlns="${"http://www.w3.org/2000/svg"}" fill="${"currentColor"}" class="${"w-6 h-6"}" viewBox="${"0 0 512 512"}"><path d="${"M99.617 8.057a50.191 50.191 0 00-38.815-6.713l230.932 230.933 74.846-74.846L99.617 8.057zM32.139 20.116c-6.441 8.563-10.148 19.077-10.148 30.199v411.358c0 11.123 3.708 21.636 10.148 30.199l235.877-235.877L32.139 20.116zM464.261 212.087l-67.266-37.637-81.544 81.544 81.548 81.548 67.273-37.64c16.117-9.03 25.738-25.442 25.738-43.908s-9.621-34.877-25.749-43.907zM291.733 279.711L60.815 510.629c3.786.891 7.639 1.371 11.492 1.371a50.275 50.275 0 0027.31-8.07l266.965-149.372-74.849-74.847z"}"></path></svg>
				<span class="${"ml-4 flex items-start flex-col leading-none"}"><span class="${"text-xs text-gray-600 mb-1"}">Download on</span>
					<span class="${"title-font font-medium"}">Google Play</span></span></button>
			<button class="${"bg-gray-100 inline-flex py-3 px-5 rounded-lg items-center ml-4 hover:bg-gray-200 focus:outline-none"}"><svg xmlns="${"http://www.w3.org/2000/svg"}" fill="${"currentColor"}" class="${"w-6 h-6"}" viewBox="${"0 0 305 305"}"><path d="${"M40.74 112.12c-25.79 44.74-9.4 112.65 19.12 153.82C74.09 286.52 88.5 305 108.24 305c.37 0 .74 0 1.13-.02 9.27-.37 15.97-3.23 22.45-5.99 7.27-3.1 14.8-6.3 26.6-6.3 11.22 0 18.39 3.1 25.31 6.1 6.83 2.95 13.87 6 24.26 5.81 22.23-.41 35.88-20.35 47.92-37.94a168.18 168.18 0 0021-43l.09-.28a2.5 2.5 0 00-1.33-3.06l-.18-.08c-3.92-1.6-38.26-16.84-38.62-58.36-.34-33.74 25.76-51.6 31-54.84l.24-.15a2.5 2.5 0 00.7-3.51c-18-26.37-45.62-30.34-56.73-30.82a50.04 50.04 0 00-4.95-.24c-13.06 0-25.56 4.93-35.61 8.9-6.94 2.73-12.93 5.09-17.06 5.09-4.64 0-10.67-2.4-17.65-5.16-9.33-3.7-19.9-7.9-31.1-7.9l-.79.01c-26.03.38-50.62 15.27-64.18 38.86z"}"></path><path d="${"M212.1 0c-15.76.64-34.67 10.35-45.97 23.58-9.6 11.13-19 29.68-16.52 48.38a2.5 2.5 0 002.29 2.17c1.06.08 2.15.12 3.23.12 15.41 0 32.04-8.52 43.4-22.25 11.94-14.5 17.99-33.1 16.16-49.77A2.52 2.52 0 00212.1 0z"}"></path></svg>
				<span class="${"ml-4 flex items-start flex-col leading-none"}"><span class="${"text-xs text-gray-600 mb-1"}">Download on</span>
					<span class="${"title-font font-medium"}">App Store</span></span></button></div></div></section>`;
});
var index = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Routes
});
const Questionsquizzs = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><link href="${"../lib/styles.css"}" rel="${"stylesheet"}">
  <script defer src="${"../lib/script.js"}"></script>
  <title>Quizz</title></head>
<body><div class="${"container"}"><div id="${"question-container"}" class="${"hide"}"><div id="${"question"}">Question</div>
      <div id="${"answer-buttons"}" class="${"btn-grid"}"><button class="${"btn"}">Answer 1</button>
        <button class="${"btn"}">Answer 2</button>
        <button class="${"btn"}">Answer 3</button>
        <button class="${"btn"}">Answer 4</button></div></div>
    <div class="${"controls"}"><button id="${"start-btn"}" class="${"start-btn btn"}">Start</button>
      <button id="${"next-btn"}" class="${"next-btn btn hide"}">Next</button></div></div></body>`;
});
var questionsquizzs = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Questionsquizzs
});
const Formationgen = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><title>LPC Quizz FormationG</title></head>

${validate_component(Header, "Header").$$render($$result, {}, {}, {})}`;
});
var formationgen = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Formationgen
});
const Informatique = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><title>LPC Quizz Informatique</title></head>

${validate_component(Header, "Header").$$render($$result, {}, {}, {})}`;
});
var informatique = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Informatique
});
const Biologie = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><title>LPC Quizz Biologie</title></head>
${validate_component(Header, "Header").$$render($$result, {}, {}, {})}`;
});
var biologie = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Biologie
});
const Physique = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><title>LPC Quizz Physique</title></head>

${validate_component(Header, "Header").$$render($$result, {}, {}, {})}`;
});
var physique = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Physique
});
const Annales = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><title>LPC Annales</title></head>

${validate_component(Header, "Header").$$render($$result, {}, {}, {})}
Ici, les annales`;
});
var annales = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Annales
});
const Contact = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><title>LPC Contacts</title></head>

${validate_component(Header, "Header").$$render($$result, {}, {}, {})}
<section class="${"text-gray-600 body-font"}"><div class="${"container px-5 py-24 mx-auto"}"><div class="${"flex flex-col text-center w-full mb-20"}"><h1 class="${"text-2xl font-medium title-font mb-4 text-gray-900 tracking-widest"}">Notre \xE9quipe</h1>
        <p class="${"lg:w-2/3 mx-auto leading-relaxed text-base"}">Notre \xE9quipe est consitu\xE9 de merveilleuses personnes !</p></div>
      <div class="${"flex flex-wrap -m-4"}"><div class="${"p-4 lg:w-1/2"}"><div class="${"h-full flex sm:flex-row flex-col items-center sm:justify-start justify-center text-center sm:text-left"}"><img alt="${"team"}" class="${"flex-shrink-0 rounded-lg w-48 h-48 object-cover object-center sm:mb-0 mb-4"}" src="${"https://1fichier.com/?rea0gep6ky9z1uscu6sf"}">
            <div class="${"flex-grow sm:pl-8"}"><h2 class="${"title-font font-medium text-lg text-gray-900"}">Vincent Hong-Tuan</h2>
              <h3 class="${"text-gray-500 mb-3"}">D\xE9veloppeur IU &amp; Graphiste</h3>
              <p class="${"mb-4"}">Il a design\xE9 le mod\xE8le des pages et les illustrations</p>
              <span class="${"inline-flex"}"><a class="${"text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"}"></path></svg></a>
                <a class="${"ml-2 text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"}"></path></svg></a>
                <a class="${"ml-2 text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"}"></path></svg></a></span></div></div></div>
        <div class="${"p-4 lg:w-1/2"}"><div class="${"h-full flex sm:flex-row flex-col items-center sm:justify-start justify-center text-center sm:text-left"}"><img alt="${"team"}" class="${"flex-shrink-0 rounded-lg w-48 h-48 object-cover object-center sm:mb-0 mb-4"}" src="${"https://1fichier.com/?cg3rhm1opo3gyhoytzh1"}">
            <div class="${"flex-grow sm:pl-8"}"><h2 class="${"title-font font-medium text-lg text-gray-900"}">Elouarn de Kerros</h2>
              <h3 class="${"text-gray-500 mb-3"}">Programmeur en CHEF du projet</h3>
              <p class="${"mb-4"}">Il a mis en pratique les mod\xE8les graphiques de Vincent !</p>
              <span class="${"inline-flex"}"><a class="${"text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"}"></path></svg></a>
                <a class="${"ml-2 text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"}"></path></svg></a>
                <a class="${"ml-2 text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"}"></path></svg></a></span></div></div></div>
        <div class="${"p-4 lg:w-1/2"}"><div class="${"h-full flex sm:flex-row flex-col items-center sm:justify-start justify-center text-center sm:text-left"}"><img alt="${"team"}" class="${"flex-shrink-0 rounded-lg w-48 h-48 object-cover object-center sm:mb-0 mb-4"}" src="${"https://1fichier.com/?6e80nn1atrs0vzcoke2m"}">
            <div class="${"flex-grow sm:pl-8"}"><h2 class="${"title-font font-medium text-lg text-gray-900"}">Loic Tr\xE9hin</h2>
              <h3 class="${"text-gray-500 mb-3"}">Programmeur Base de Donn\xE9es</h3>
              <p class="${"mb-4"}">Il va cr\xE9er la base de donn\xE9e et la relier \xE0 l&#39;application !</p>
              <span class="${"inline-flex"}"><a class="${"text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"}"></path></svg></a>
                <a class="${"ml-2 text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"}"></path></svg></a>
                <a class="${"ml-2 text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"}"></path></svg></a></span></div></div></div>
        <div class="${"p-4 lg:w-1/2"}"><div class="${"h-full flex sm:flex-row flex-col items-center sm:justify-start justify-center text-center sm:text-left"}"><img alt="${"team"}" class="${"flex-shrink-0 rounded-lg w-48 h-48 object-cover object-center sm:mb-0 mb-4"}" src="${"https://1fichier.com/?wfhtdyvgqmfoami490l9"}">
            <div class="${"flex-grow sm:pl-8"}"><h2 class="${"title-font font-medium text-lg text-gray-900"}">Killian Graindorge</h2>
              <h3 class="${"text-gray-500 mb-3"}">D\xE9veloppeur fiches &amp; quizz</h3>
              <p class="${"mb-4"}">Pr\xEAt \xE0 tout pour vous cr\xE9er des quizzs et des fiches int\xE9ressants !</p>
              <span class="${"inline-flex"}"><a class="${"text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"}"></path></svg></a>
                <a class="${"ml-2 text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"}"></path></svg></a>
                <a class="${"ml-2 text-gray-500"}"><svg fill="${"none"}" stroke="${"currentColor"}" stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" class="${"w-5 h-5"}" viewBox="${"0 0 24 24"}"><path d="${"M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"}"></path></svg></a></span></div></div></div></div></div></section>`;
});
var contact = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Contact
});
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
function __awaiter$9(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}
function __generator(thisArg, body) {
  var _ = {label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: []}, f, y, t, g;
  return g = {next: verb(0), throw: verb(1), return: verb(2)}, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return {value: op[1], done: false};
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return {value: op[0] ? op[1] : void 0, done: true};
  }
}
function __read(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error2) {
    e = {error: error2};
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
}
function __spread() {
  for (var ar = [], i = 0; i < arguments.length; i++)
    ar = ar.concat(__read(arguments[i]));
  return ar;
}
var COMMON_MIME_TYPES = new Map([
  ["avi", "video/avi"],
  ["gif", "image/gif"],
  ["ico", "image/x-icon"],
  ["jpeg", "image/jpeg"],
  ["jpg", "image/jpeg"],
  ["mkv", "video/x-matroska"],
  ["mov", "video/quicktime"],
  ["mp4", "video/mp4"],
  ["pdf", "application/pdf"],
  ["png", "image/png"],
  ["zip", "application/zip"],
  ["doc", "application/msword"],
  ["docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]
]);
function toFileWithPath(file, path) {
  var f = withMimeType(file);
  if (typeof f.path !== "string") {
    var webkitRelativePath = file.webkitRelativePath;
    Object.defineProperty(f, "path", {
      value: typeof path === "string" ? path : typeof webkitRelativePath === "string" && webkitRelativePath.length > 0 ? webkitRelativePath : file.name,
      writable: false,
      configurable: false,
      enumerable: true
    });
  }
  return f;
}
function withMimeType(file) {
  var name2 = file.name;
  var hasExtension = name2 && name2.lastIndexOf(".") !== -1;
  if (hasExtension && !file.type) {
    var ext = name2.split(".").pop().toLowerCase();
    var type = COMMON_MIME_TYPES.get(ext);
    if (type) {
      Object.defineProperty(file, "type", {
        value: type,
        writable: false,
        configurable: false,
        enumerable: true
      });
    }
  }
  return file;
}
var FILES_TO_IGNORE = [
  ".DS_Store",
  "Thumbs.db"
];
function fromEvent(evt) {
  return __awaiter$9(this, void 0, void 0, function() {
    return __generator(this, function(_a) {
      return [2, isDragEvt(evt) && evt.dataTransfer ? getDataTransferFiles(evt.dataTransfer, evt.type) : getInputFiles(evt)];
    });
  });
}
function isDragEvt(value) {
  return !!value.dataTransfer;
}
function getInputFiles(evt) {
  var files = isInput(evt.target) ? evt.target.files ? fromList(evt.target.files) : [] : [];
  return files.map(function(file) {
    return toFileWithPath(file);
  });
}
function isInput(value) {
  return value !== null;
}
function getDataTransferFiles(dt, type) {
  return __awaiter$9(this, void 0, void 0, function() {
    var items, files;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (!dt.items)
            return [3, 2];
          items = fromList(dt.items).filter(function(item) {
            return item.kind === "file";
          });
          if (type !== "drop") {
            return [2, items];
          }
          return [4, Promise.all(items.map(toFilePromises))];
        case 1:
          files = _a.sent();
          return [2, noIgnoredFiles(flatten(files))];
        case 2:
          return [2, noIgnoredFiles(fromList(dt.files).map(function(file) {
            return toFileWithPath(file);
          }))];
      }
    });
  });
}
function noIgnoredFiles(files) {
  return files.filter(function(file) {
    return FILES_TO_IGNORE.indexOf(file.name) === -1;
  });
}
function fromList(items) {
  var files = [];
  for (var i = 0; i < items.length; i++) {
    var file = items[i];
    files.push(file);
  }
  return files;
}
function toFilePromises(item) {
  if (typeof item.webkitGetAsEntry !== "function") {
    return fromDataTransferItem(item);
  }
  var entry = item.webkitGetAsEntry();
  if (entry && entry.isDirectory) {
    return fromDirEntry(entry);
  }
  return fromDataTransferItem(item);
}
function flatten(items) {
  return items.reduce(function(acc, files) {
    return __spread(acc, Array.isArray(files) ? flatten(files) : [files]);
  }, []);
}
function fromDataTransferItem(item) {
  var file = item.getAsFile();
  if (!file) {
    return Promise.reject(item + " is not a File");
  }
  var fwp = toFileWithPath(file);
  return Promise.resolve(fwp);
}
function fromEntry(entry) {
  return __awaiter$9(this, void 0, void 0, function() {
    return __generator(this, function(_a) {
      return [2, entry.isDirectory ? fromDirEntry(entry) : fromFileEntry(entry)];
    });
  });
}
function fromDirEntry(entry) {
  var reader = entry.createReader();
  return new Promise(function(resolve2, reject) {
    var entries = [];
    function readEntries() {
      var _this = this;
      reader.readEntries(function(batch) {
        return __awaiter$9(_this, void 0, void 0, function() {
          var files, err_1, items;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                if (!!batch.length)
                  return [3, 5];
                _a.label = 1;
              case 1:
                _a.trys.push([1, 3, , 4]);
                return [4, Promise.all(entries)];
              case 2:
                files = _a.sent();
                resolve2(files);
                return [3, 4];
              case 3:
                err_1 = _a.sent();
                reject(err_1);
                return [3, 4];
              case 4:
                return [3, 6];
              case 5:
                items = Promise.all(batch.map(fromEntry));
                entries.push(items);
                readEntries();
                _a.label = 6;
              case 6:
                return [2];
            }
          });
        });
      }, function(err) {
        reject(err);
      });
    }
    readEntries();
  });
}
function fromFileEntry(entry) {
  return __awaiter$9(this, void 0, void 0, function() {
    return __generator(this, function(_a) {
      return [2, new Promise(function(resolve2, reject) {
        entry.file(function(file) {
          var fwp = toFileWithPath(file, entry.fullPath);
          resolve2(fwp);
        }, function(err) {
          reject(err);
        });
      })];
    });
  });
}
function onDocumentDragOver(event) {
  event.preventDefault();
}
var Dropzone_svelte = ".dropzone.svelte-817dg2{\n  flex:1;\n  display:flex;\n  flex-direction:column;\n  align-items:center;\n  padding:20px;\n  border-width:2px;\n  border-radius:2px;\n  border-color:#eeeeee;\n  border-style:dashed;\n  background-color:#fafafa;\n  color:#bdbdbd;\n  outline:none;\n  transition:border 0.24s ease-in-out\n}\n\n.dropzone.svelte-817dg2:focus{\n  border-color:#2196f3\n}";
const css$1 = {
  code: ".dropzone.svelte-817dg2{flex:1;display:flex;flex-direction:column;align-items:center;padding:20px;border-width:2px;border-radius:2px;border-color:#eeeeee;border-style:dashed;background-color:#fafafa;color:#bdbdbd;outline:none;transition:border 0.24s ease-in-out}.dropzone.svelte-817dg2:focus{border-color:#2196f3}",
  map: `{"version":3,"file":"Dropzone.svelte","sources":["Dropzone.svelte"],"sourcesContent":["<script>\\r\\n  import { fromEvent } from \\"file-selector\\";\\r\\n  import {\\r\\n    allFilesAccepted,\\r\\n    composeEventHandlers,\\r\\n    fileAccepted,\\r\\n    fileMatchSize,\\r\\n    isEvtWithFiles,\\r\\n    isIeOrEdge,\\r\\n    isPropagationStopped,\\r\\n    onDocumentDragOver,\\r\\n    TOO_MANY_FILES_REJECTION\\r\\n  } from \\"./../utils/index\\";\\r\\n  import { onMount, onDestroy, createEventDispatcher } from \\"svelte\\";\\r\\n\\r\\n  //props\\r\\n  /**\\r\\n   * Set accepted file types.\\r\\n   * See https://github.com/okonet/attr-accept for more information.\\r\\n   */\\r\\n  export let accept; // string or string[]\\r\\n  export let disabled = false;\\r\\n  export let getFilesFromEvent = fromEvent;\\r\\n  export let maxSize = Infinity;\\r\\n  export let minSize = 0;\\r\\n  export let multiple = true;\\r\\n  export let preventDropOnDocument = true;\\r\\n  export let noClick = false;\\r\\n  export let noKeyboard = false;\\r\\n  export let noDrag = false;\\r\\n  export let noDragEventsBubbling = false;\\r\\n  export let containerClasses = \\"\\";\\r\\n  export let containerStyles = \\"\\";\\r\\n  export let disableDefaultStyles = false;\\r\\n\\r\\n  const dispatch = createEventDispatcher();\\r\\n\\r\\n  //state\\r\\n\\r\\n  let state = {\\r\\n    isFocused: false,\\r\\n    isFileDialogActive: false,\\r\\n    isDragActive: false,\\r\\n    isDragAccept: false,\\r\\n    isDragReject: false,\\r\\n    draggedFiles: [],\\r\\n    acceptedFiles: [],\\r\\n    fileRejections: []\\r\\n  };\\r\\n\\r\\n  let rootRef;\\r\\n  let inputRef;\\r\\n\\r\\n  function resetState() {\\r\\n    state.isFileDialogActive = false;\\r\\n    state.isDragActive = false;\\r\\n    state.draggedFiles = [];\\r\\n    state.acceptedFiles = [];\\r\\n    state.fileRejections = [];\\r\\n  }\\r\\n\\r\\n  // Fn for opening the file dialog programmatically\\r\\n  function openFileDialog() {\\r\\n    if (inputRef) {\\r\\n      inputRef.value = null; // TODO check if null needs to be set\\r\\n      state.isFileDialogActive = true;\\r\\n      inputRef.click();\\r\\n    }\\r\\n  }\\r\\n\\r\\n  // Cb to open the file dialog when SPACE/ENTER occurs on the dropzone\\r\\n  function onKeyDownCb(event) {\\r\\n    // Ignore keyboard events bubbling up the DOM tree\\r\\n    if (!rootRef || !rootRef.isEqualNode(event.target)) {\\r\\n      return;\\r\\n    }\\r\\n\\r\\n    if (event.keyCode === 32 || event.keyCode === 13) {\\r\\n      event.preventDefault();\\r\\n      openFileDialog();\\r\\n    }\\r\\n  }\\r\\n\\r\\n  // Update focus state for the dropzone\\r\\n  function onFocusCb() {\\r\\n    state.isFocused = true;\\r\\n  }\\r\\n  function onBlurCb() {\\r\\n    state.isFocused = false;\\r\\n  }\\r\\n\\r\\n  // Cb to open the file dialog when click occurs on the dropzone\\r\\n  function onClickCb() {\\r\\n    if (noClick) {\\r\\n      return;\\r\\n    }\\r\\n\\r\\n    // In IE11/Edge the file-browser dialog is blocking, therefore, use setTimeout()\\r\\n    // to ensure React can handle state changes\\r\\n    // See: https://github.com/react-dropzone/react-dropzone/issues/450\\r\\n    if (isIeOrEdge()) {\\r\\n      setTimeout(openFileDialog, 0);\\r\\n    } else {\\r\\n      openFileDialog();\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function onDragEnterCb(event) {\\r\\n    event.preventDefault();\\r\\n    stopPropagation(event);\\r\\n\\r\\n    dragTargetsRef = [...dragTargetsRef, event.target];\\r\\n\\r\\n    if (isEvtWithFiles(event)) {\\r\\n      Promise.resolve(getFilesFromEvent(event)).then(draggedFiles => {\\r\\n        if (isPropagationStopped(event) && !noDragEventsBubbling) {\\r\\n          return;\\r\\n        }\\r\\n\\r\\n        state.draggedFiles = draggedFiles;\\r\\n        state.isDragActive = true;\\r\\n\\r\\n        dispatch(\\"dragenter\\", {\\r\\n          dragEvent: event\\r\\n        });\\r\\n      });\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function onDragOverCb(event) {\\r\\n    event.preventDefault();\\r\\n    stopPropagation(event);\\r\\n\\r\\n    if (event.dataTransfer) {\\r\\n      try {\\r\\n        event.dataTransfer.dropEffect = \\"copy\\";\\r\\n      } catch {} /* eslint-disable-line no-empty */\\r\\n    }\\r\\n\\r\\n    if (isEvtWithFiles(event)) {\\r\\n      dispatch(\\"dragover\\", {\\r\\n        dragEvent: event\\r\\n      });\\r\\n    }\\r\\n\\r\\n    return false;\\r\\n  }\\r\\n\\r\\n  function onDragLeaveCb(event) {\\r\\n    event.preventDefault();\\r\\n    stopPropagation(event);\\r\\n\\r\\n    // Only deactivate once the dropzone and all children have been left\\r\\n    const targets = dragTargetsRef.filter(\\r\\n      target => rootRef && rootRef.contains(target)\\r\\n    );\\r\\n    // Make sure to remove a target present multiple times only once\\r\\n    // (Firefox may fire dragenter/dragleave multiple times on the same element)\\r\\n    const targetIdx = targets.indexOf(event.target);\\r\\n    if (targetIdx !== -1) {\\r\\n      targets.splice(targetIdx, 1);\\r\\n    }\\r\\n    dragTargetsRef = targets;\\r\\n    if (targets.length > 0) {\\r\\n      return;\\r\\n    }\\r\\n\\r\\n    state.isDragActive = false;\\r\\n    state.draggedFiles = [];\\r\\n\\r\\n    if (isEvtWithFiles(event)) {\\r\\n      dispatch(\\"dragleave\\", {\\r\\n        dragEvent: event\\r\\n      });\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function onDropCb(event) {\\r\\n    event.preventDefault();\\r\\n    stopPropagation(event);\\r\\n\\r\\n    dragTargetsRef = [];\\r\\n\\r\\n    if (isEvtWithFiles(event)) {\\r\\n      Promise.resolve(getFilesFromEvent(event)).then(files => {\\r\\n        if (isPropagationStopped(event) && !noDragEventsBubbling) {\\r\\n          return;\\r\\n        }\\r\\n\\r\\n        const acceptedFiles = [];\\r\\n        const fileRejections = [];\\r\\n\\r\\n        files.forEach(file => {\\r\\n          const [accepted, acceptError] = fileAccepted(file, accept);\\r\\n          const [sizeMatch, sizeError] = fileMatchSize(file, minSize, maxSize);\\r\\n          if (accepted && sizeMatch) {\\r\\n            acceptedFiles.push(file);\\r\\n          } else {\\r\\n            const errors = [acceptError, sizeError].filter(e => e);\\r\\n            fileRejections.push({ file, errors });\\r\\n          }\\r\\n        });\\r\\n\\r\\n        if (!multiple && acceptedFiles.length > 1) {\\r\\n          // Reject everything and empty accepted files\\r\\n          acceptedFiles.forEach(file => {\\r\\n            fileRejections.push({ file, errors: [TOO_MANY_FILES_REJECTION] });\\r\\n          });\\r\\n          acceptedFiles.splice(0);\\r\\n        }\\r\\n\\r\\n        state.acceptedFiles = acceptedFiles;\\r\\n        state.fileRejections = fileRejections;\\r\\n\\r\\n        dispatch(\\"drop\\", {\\r\\n          acceptedFiles,\\r\\n          fileRejections,\\r\\n          event\\r\\n        });\\r\\n\\r\\n        if (fileRejections.length > 0) {\\r\\n          dispatch(\\"droprejected\\", {\\r\\n            fileRejections,\\r\\n            event\\r\\n          });\\r\\n        }\\r\\n\\r\\n        if (acceptedFiles.length > 0) {\\r\\n          dispatch(\\"dropaccepted\\", {\\r\\n            acceptedFiles,\\r\\n            event\\r\\n          });\\r\\n        }\\r\\n      });\\r\\n    }\\r\\n    resetState();\\r\\n  }\\r\\n\\r\\n  function composeHandler(fn) {\\r\\n    return disabled ? null : fn;\\r\\n  }\\r\\n\\r\\n  function composeKeyboardHandler(fn) {\\r\\n    return noKeyboard ? null : composeHandler(fn);\\r\\n  }\\r\\n\\r\\n  function composeDragHandler(fn) {\\r\\n    return noDrag ? null : composeHandler(fn);\\r\\n  }\\r\\n\\r\\n  function stopPropagation(event) {\\r\\n    if (noDragEventsBubbling) {\\r\\n      event.stopPropagation();\\r\\n    }\\r\\n  }\\r\\n\\r\\n  let dragTargetsRef = [];\\r\\n  function onDocumentDrop(event) {\\r\\n    if (rootRef && rootRef.contains(event.target)) {\\r\\n      // If we intercepted an event for our instance, let it propagate down to the instance's onDrop handler\\r\\n      return;\\r\\n    }\\r\\n    event.preventDefault();\\r\\n    dragTargetsRef = [];\\r\\n  }\\r\\n\\r\\n  // Update file dialog active state when the window is focused on\\r\\n  function onWindowFocus() {\\r\\n    // Execute the timeout only if the file dialog is opened in the browser\\r\\n    if (state.isFileDialogActive) {\\r\\n      setTimeout(() => {\\r\\n        if (inputRef) {\\r\\n          const { files } = inputRef;\\r\\n\\r\\n          if (!files.length) {\\r\\n            state.isFileDialogActive = false;\\r\\n            dispatch(\\"filedialogcancel\\");\\r\\n          }\\r\\n        }\\r\\n      }, 300);\\r\\n    }\\r\\n  }\\r\\n\\r\\n  onMount(() => {\\r\\n    window.addEventListener(\\"focus\\", onWindowFocus, false);\\r\\n    if (preventDropOnDocument) {\\r\\n      document.addEventListener(\\"dragover\\", onDocumentDragOver, false);\\r\\n      document.addEventListener(\\"drop\\", onDocumentDrop, false);\\r\\n    }\\r\\n  });\\r\\n\\r\\n  onDestroy(() => {\\r\\n    window.removeEventListener(\\"focus\\", onWindowFocus, false);\\r\\n    if (preventDropOnDocument) {\\r\\n      document.removeEventListener(\\"dragover\\", onDocumentDragOver);\\r\\n      document.removeEventListener(\\"drop\\", onDocumentDrop);\\r\\n    }\\r\\n  });\\r\\n\\r\\n  function onInputElementClick(event) {\\r\\n    event.stopPropagation();\\r\\n  }\\r\\n</script>\\r\\n\\r\\n<style>\\r\\n  .dropzone {\\r\\n    flex: 1;\\r\\n    display: flex;\\r\\n    flex-direction: column;\\r\\n    align-items: center;\\r\\n    padding: 20px;\\r\\n    border-width: 2px;\\r\\n    border-radius: 2px;\\r\\n    border-color: #eeeeee;\\r\\n    border-style: dashed;\\r\\n    background-color: #fafafa;\\r\\n    color: #bdbdbd;\\r\\n    outline: none;\\r\\n    transition: border 0.24s ease-in-out;\\r\\n  }\\r\\n  .dropzone:focus {\\r\\n    border-color: #2196f3;\\r\\n  }\\r\\n</style>\\r\\n\\r\\n<div\\r\\n  bind:this={rootRef}\\r\\n  tabindex=\\"0\\"\\r\\n  class=\\"{disableDefaultStyles ? '' : 'dropzone'}\\r\\n  {containerClasses}\\"\\r\\n  style={containerStyles}\\r\\n  on:keydown={composeKeyboardHandler(onKeyDownCb)}\\r\\n  on:focus={composeKeyboardHandler(onFocusCb)}\\r\\n  on:blur={composeKeyboardHandler(onBlurCb)}\\r\\n  on:click={composeHandler(onClickCb)}\\r\\n  on:dragenter={composeDragHandler(onDragEnterCb)}\\r\\n  on:dragover={composeDragHandler(onDragOverCb)}\\r\\n  on:dragleave={composeDragHandler(onDragLeaveCb)}\\r\\n  on:drop={composeDragHandler(onDropCb)}>\\r\\n  <input\\r\\n    {accept}\\r\\n    {multiple}\\r\\n    type=\\"file\\"\\r\\n    autocomplete=\\"off\\"\\r\\n    tabindex=\\"-1\\"\\r\\n    on:change={onDropCb}\\r\\n    on:click={onInputElementClick}\\r\\n    bind:this={inputRef}\\r\\n    style=\\"display: none;\\" />\\r\\n  <slot>\\r\\n    <p>Glissez-d\xE9posez quelques fichiers ici, ou cliquez pour s\xE9lectionner des fichiers</p>\\r\\n  </slot>\\r\\n</div>\\r\\n"],"names":[],"mappings":"AAiTE,SAAS,cAAC,CAAC,AACT,IAAI,CAAE,CAAC,CACP,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MAAM,CACnB,OAAO,CAAE,IAAI,CACb,YAAY,CAAE,GAAG,CACjB,aAAa,CAAE,GAAG,CAClB,YAAY,CAAE,OAAO,CACrB,YAAY,CAAE,MAAM,CACpB,gBAAgB,CAAE,OAAO,CACzB,KAAK,CAAE,OAAO,CACd,OAAO,CAAE,IAAI,CACb,UAAU,CAAE,MAAM,CAAC,KAAK,CAAC,WAAW,AACtC,CAAC,AACD,uBAAS,MAAM,AAAC,CAAC,AACf,YAAY,CAAE,OAAO,AACvB,CAAC"}`
};
const Dropzone = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let {accept} = $$props;
  let {disabled = false} = $$props;
  let {getFilesFromEvent = fromEvent} = $$props;
  let {maxSize = Infinity} = $$props;
  let {minSize = 0} = $$props;
  let {multiple = true} = $$props;
  let {preventDropOnDocument = true} = $$props;
  let {noClick = false} = $$props;
  let {noKeyboard = false} = $$props;
  let {noDrag = false} = $$props;
  let {noDragEventsBubbling = false} = $$props;
  let {containerClasses = ""} = $$props;
  let {containerStyles = ""} = $$props;
  let {disableDefaultStyles = false} = $$props;
  createEventDispatcher();
  let rootRef;
  function onDocumentDrop(event) {
    event.preventDefault();
  }
  function onWindowFocus() {
  }
  onMount(() => {
    window.addEventListener("focus", onWindowFocus, false);
    if (preventDropOnDocument) {
      document.addEventListener("dragover", onDocumentDragOver, false);
      document.addEventListener("drop", onDocumentDrop, false);
    }
  });
  onDestroy(() => {
    window.removeEventListener("focus", onWindowFocus, false);
    if (preventDropOnDocument) {
      document.removeEventListener("dragover", onDocumentDragOver);
      document.removeEventListener("drop", onDocumentDrop);
    }
  });
  if ($$props.accept === void 0 && $$bindings.accept && accept !== void 0)
    $$bindings.accept(accept);
  if ($$props.disabled === void 0 && $$bindings.disabled && disabled !== void 0)
    $$bindings.disabled(disabled);
  if ($$props.getFilesFromEvent === void 0 && $$bindings.getFilesFromEvent && getFilesFromEvent !== void 0)
    $$bindings.getFilesFromEvent(getFilesFromEvent);
  if ($$props.maxSize === void 0 && $$bindings.maxSize && maxSize !== void 0)
    $$bindings.maxSize(maxSize);
  if ($$props.minSize === void 0 && $$bindings.minSize && minSize !== void 0)
    $$bindings.minSize(minSize);
  if ($$props.multiple === void 0 && $$bindings.multiple && multiple !== void 0)
    $$bindings.multiple(multiple);
  if ($$props.preventDropOnDocument === void 0 && $$bindings.preventDropOnDocument && preventDropOnDocument !== void 0)
    $$bindings.preventDropOnDocument(preventDropOnDocument);
  if ($$props.noClick === void 0 && $$bindings.noClick && noClick !== void 0)
    $$bindings.noClick(noClick);
  if ($$props.noKeyboard === void 0 && $$bindings.noKeyboard && noKeyboard !== void 0)
    $$bindings.noKeyboard(noKeyboard);
  if ($$props.noDrag === void 0 && $$bindings.noDrag && noDrag !== void 0)
    $$bindings.noDrag(noDrag);
  if ($$props.noDragEventsBubbling === void 0 && $$bindings.noDragEventsBubbling && noDragEventsBubbling !== void 0)
    $$bindings.noDragEventsBubbling(noDragEventsBubbling);
  if ($$props.containerClasses === void 0 && $$bindings.containerClasses && containerClasses !== void 0)
    $$bindings.containerClasses(containerClasses);
  if ($$props.containerStyles === void 0 && $$bindings.containerStyles && containerStyles !== void 0)
    $$bindings.containerStyles(containerStyles);
  if ($$props.disableDefaultStyles === void 0 && $$bindings.disableDefaultStyles && disableDefaultStyles !== void 0)
    $$bindings.disableDefaultStyles(disableDefaultStyles);
  $$result.css.add(css$1);
  return `<div tabindex="${"0"}" class="${escape$1(disableDefaultStyles ? "" : "dropzone") + "\r\n  " + escape$1(containerClasses) + " svelte-817dg2"}"${add_attribute("style", containerStyles, 0)}${add_attribute("this", rootRef, 1)}><input${add_attribute("accept", accept, 0)} ${multiple ? "multiple" : ""} type="${"file"}" autocomplete="${"off"}" tabindex="${"-1"}" style="${"display: none;"}">
  ${slots.default ? slots.default({}) : `
    <p>Glissez-d\xE9posez quelques fichiers ici, ou cliquez pour s\xE9lectionner des fichiers</p>
  `}</div>`;
});
const Fiches = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let files = {accepted: [], rejected: []};
  return `<head><title>LPC Fiches</title></head>

${validate_component(Header, "Header").$$render($$result, {}, {}, {})}

<section class="${"text-gray-600 body-font min-h-screen"}"><div class="${"z-10 relative bg-white"}"><div class="${"max-w-full mx-auto p-5 mt-8 -mb-5 sm:p-5"}"><div class="${"flex inline-block sm:flex-col justify-center"}"><div class="${"absolute w-full flex justify-center"}"><input class="${" flex-shrink-0 relative flex w-1/3 items-center border-solid border-2 ring-offset-0 border-gray-500 placeholder-gray-500 rounded-sm focus:placeholder-gray-500"}" placeholder="${"Rechercher une fiche"}"></div>
				<div class="${"flex absolute inline-block justify-end w-1/6 right-0"}"><div class="${"flex w-auto"}"><button class="${"flex inline-flex font-semibold bg-gray-100 border-0 py-1 px-3 focus:outline-none hover:bg-gray-200 rounded text-base mt-4 md:mt-0 mr-1"}">Info ?
						</button></div>
					<div class="${"flex w-auto"}"><button class="${"flex inline-flex font-semibold bg-gray-100 border-0 py-1 px-3 focus:outline-none hover:bg-gray-200 rounded text-base mt-4 md:mt-0 mr-1"}">Upload
						</button></div></div></div></div>
		<div class="${"max-w-full mx-auto p-5 sm:p-5"}"><div class="${"flex inline-block sm:flex-col justify-center"}"><nav class="${"md:flex relative space-x-5 px-5 py-2 w-2/5"}"><div class="${"flex inline-block space-x-5 justify-center w-2/5 border-gray-100 border-2 border-gray-400 py-2 px-2 rounded "}"><a href="${"#"}" class="${"w-50 font-medium tracking-wide text-sm border-l-4 relative border-r-4 ring-offset-2 border-solid"}">Nouveau
						</a>
						<a href="${"#"}" class="${"w-50 font-medium tracking-wide text-sm border-l-4 relative border-r-4 ring-offset-2 border-solid"}">Vues
						</a>
						<a href="${"#"}" class="${"w-50 font-medium tracking-wide text-sm border-l-4 relative border-r-4 ring-offset-2 border-solid"}">Populaire
						</a></div>
					<div class="${"flex inline-block space-x-5 justify-center w-3/5 border-gray-100 border-2 border-gray-400 py-2 px-2 rounded "}"><a href="${"#"}" class="${"w-50 font-medium tracking-wide text-sm relative border-l-4 border-r-4 ring-offset-2 border-solid"}">Jour
						</a>
						<a href="${"#"}" class="${"w-50 font-medium tracking-wide text-sm relative border-l-4 border-r-4 ring-offset-2 border-solid"}">Semaine
						</a>
						<a href="${"#"}" class="${"w-50 font-medium tracking-wide text-sm relative border-l-4 border-r-4 ring-offset-2 border-solid"}">Mois
						</a>
						<a href="${"#"}" class="${"w-50 font-medium tracking-wide text-sm relative border-l-4 border-r-4 ring-offset-2 border-solid"}">Toujours
						</a></div></nav>
				<nav class="${"md:flex absolute top-5 right-0 px-5 w-3/5"}"><div class="${"flex grid justify-center grid-cols-5 gap-2 auto-rows-auto w-auto py-5"}"><a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">L1
						</a>
						<a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">L2
						</a>
						<a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">L3
						</a>
						<a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">M1
						</a>
						<a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">M2
						</a>
						<a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">Bio
						</a>
						<a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">G\xE9n\xE9ral
						</a>
						<a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">Info
						</a>
						<a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">Maths
						</a>
						<a href="${"#"}" class="${"w-50 rounded font-medium text-center tracking-wide text-sm relative border-2 ring-offset-2 border-solid border-black py-2"}">Physique
						</a></div></nav></div></div></div>
	<div class="${"z-10 relative bg-white"}"><div class="${"max-w-full min-h-screen mx-auto p-5 mt-8 -mb-5 sm:p-5"}">${validate_component(Dropzone, "Dropzone").$$render($$result, {}, {}, {})}
			<ol>${each(files.accepted, (item) => `<li>${escape$1(item.name)}</li>`)}</ol></div></div></section>`;
});
var fiches = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Fiches
});
const Forum = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><title>LPC Forum</title></head>
${validate_component(Header, "Header").$$render($$result, {}, {}, {})}
Ici, le forum`;
});
var forum = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Forum
});
const Quizz$1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let {title = "Titre"} = $$props;
  let {title_quizz} = $$props;
  let {description: description2} = $$props;
  if ($$props.title === void 0 && $$bindings.title && title !== void 0)
    $$bindings.title(title);
  if ($$props.title_quizz === void 0 && $$bindings.title_quizz && title_quizz !== void 0)
    $$bindings.title_quizz(title_quizz);
  if ($$props.description === void 0 && $$bindings.description && description2 !== void 0)
    $$bindings.description(description2);
  return `<a href="${"../routes/questionsquizzs.svelte"}"><div class="${"lg:w-1/5 sm:w-1/2 p-4"}"><div class="${"flex relative"}"><h1 class="${"title-font font-medium text-3xl text-gray-1000"}">${escape$1(title)}</h1>
			<div class="${"px-8 py-10 relative z-1 w-full border-4 border-gray-200 bg-white opacity-0 hover:opacity-100"}"><h1 class="${"title-font text-lg font-medium text-gray-900 mb-3"}">${escape$1(title_quizz)}</h1>
				<p class="${"leading-relaxed"}">${escape$1(description2)}</p></div></div></div></a>`;
});
const DEFAULT_HEADERS$1 = {};
var browserPonyfill = createCommonjsModule(function(module, exports) {
  var global2 = typeof self !== "undefined" ? self : commonjsGlobal;
  var __self__ = function() {
    function F() {
      this.fetch = false;
      this.DOMException = global2.DOMException;
    }
    F.prototype = global2;
    return new F();
  }();
  (function(self2) {
    (function(exports2) {
      var support = {
        searchParams: "URLSearchParams" in self2,
        iterable: "Symbol" in self2 && "iterator" in Symbol,
        blob: "FileReader" in self2 && "Blob" in self2 && function() {
          try {
            new Blob();
            return true;
          } catch (e) {
            return false;
          }
        }(),
        formData: "FormData" in self2,
        arrayBuffer: "ArrayBuffer" in self2
      };
      function isDataView(obj) {
        return obj && DataView.prototype.isPrototypeOf(obj);
      }
      if (support.arrayBuffer) {
        var viewClasses = [
          "[object Int8Array]",
          "[object Uint8Array]",
          "[object Uint8ClampedArray]",
          "[object Int16Array]",
          "[object Uint16Array]",
          "[object Int32Array]",
          "[object Uint32Array]",
          "[object Float32Array]",
          "[object Float64Array]"
        ];
        var isArrayBufferView = ArrayBuffer.isView || function(obj) {
          return obj && viewClasses.indexOf(Object.prototype.toString.call(obj)) > -1;
        };
      }
      function normalizeName(name2) {
        if (typeof name2 !== "string") {
          name2 = String(name2);
        }
        if (/[^a-z0-9\-#$%&'*+.^_`|~]/i.test(name2)) {
          throw new TypeError("Invalid character in header field name");
        }
        return name2.toLowerCase();
      }
      function normalizeValue(value) {
        if (typeof value !== "string") {
          value = String(value);
        }
        return value;
      }
      function iteratorFor(items) {
        var iterator = {
          next: function() {
            var value = items.shift();
            return {done: value === void 0, value};
          }
        };
        if (support.iterable) {
          iterator[Symbol.iterator] = function() {
            return iterator;
          };
        }
        return iterator;
      }
      function Headers2(headers) {
        this.map = {};
        if (headers instanceof Headers2) {
          headers.forEach(function(value, name2) {
            this.append(name2, value);
          }, this);
        } else if (Array.isArray(headers)) {
          headers.forEach(function(header) {
            this.append(header[0], header[1]);
          }, this);
        } else if (headers) {
          Object.getOwnPropertyNames(headers).forEach(function(name2) {
            this.append(name2, headers[name2]);
          }, this);
        }
      }
      Headers2.prototype.append = function(name2, value) {
        name2 = normalizeName(name2);
        value = normalizeValue(value);
        var oldValue = this.map[name2];
        this.map[name2] = oldValue ? oldValue + ", " + value : value;
      };
      Headers2.prototype["delete"] = function(name2) {
        delete this.map[normalizeName(name2)];
      };
      Headers2.prototype.get = function(name2) {
        name2 = normalizeName(name2);
        return this.has(name2) ? this.map[name2] : null;
      };
      Headers2.prototype.has = function(name2) {
        return this.map.hasOwnProperty(normalizeName(name2));
      };
      Headers2.prototype.set = function(name2, value) {
        this.map[normalizeName(name2)] = normalizeValue(value);
      };
      Headers2.prototype.forEach = function(callback, thisArg) {
        for (var name2 in this.map) {
          if (this.map.hasOwnProperty(name2)) {
            callback.call(thisArg, this.map[name2], name2, this);
          }
        }
      };
      Headers2.prototype.keys = function() {
        var items = [];
        this.forEach(function(value, name2) {
          items.push(name2);
        });
        return iteratorFor(items);
      };
      Headers2.prototype.values = function() {
        var items = [];
        this.forEach(function(value) {
          items.push(value);
        });
        return iteratorFor(items);
      };
      Headers2.prototype.entries = function() {
        var items = [];
        this.forEach(function(value, name2) {
          items.push([name2, value]);
        });
        return iteratorFor(items);
      };
      if (support.iterable) {
        Headers2.prototype[Symbol.iterator] = Headers2.prototype.entries;
      }
      function consumed(body) {
        if (body.bodyUsed) {
          return Promise.reject(new TypeError("Already read"));
        }
        body.bodyUsed = true;
      }
      function fileReaderReady(reader) {
        return new Promise(function(resolve2, reject) {
          reader.onload = function() {
            resolve2(reader.result);
          };
          reader.onerror = function() {
            reject(reader.error);
          };
        });
      }
      function readBlobAsArrayBuffer(blob) {
        var reader = new FileReader();
        var promise = fileReaderReady(reader);
        reader.readAsArrayBuffer(blob);
        return promise;
      }
      function readBlobAsText(blob) {
        var reader = new FileReader();
        var promise = fileReaderReady(reader);
        reader.readAsText(blob);
        return promise;
      }
      function readArrayBufferAsText(buf) {
        var view = new Uint8Array(buf);
        var chars2 = new Array(view.length);
        for (var i = 0; i < view.length; i++) {
          chars2[i] = String.fromCharCode(view[i]);
        }
        return chars2.join("");
      }
      function bufferClone(buf) {
        if (buf.slice) {
          return buf.slice(0);
        } else {
          var view = new Uint8Array(buf.byteLength);
          view.set(new Uint8Array(buf));
          return view.buffer;
        }
      }
      function Body2() {
        this.bodyUsed = false;
        this._initBody = function(body) {
          this._bodyInit = body;
          if (!body) {
            this._bodyText = "";
          } else if (typeof body === "string") {
            this._bodyText = body;
          } else if (support.blob && Blob.prototype.isPrototypeOf(body)) {
            this._bodyBlob = body;
          } else if (support.formData && FormData.prototype.isPrototypeOf(body)) {
            this._bodyFormData = body;
          } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
            this._bodyText = body.toString();
          } else if (support.arrayBuffer && support.blob && isDataView(body)) {
            this._bodyArrayBuffer = bufferClone(body.buffer);
            this._bodyInit = new Blob([this._bodyArrayBuffer]);
          } else if (support.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(body) || isArrayBufferView(body))) {
            this._bodyArrayBuffer = bufferClone(body);
          } else {
            this._bodyText = body = Object.prototype.toString.call(body);
          }
          if (!this.headers.get("content-type")) {
            if (typeof body === "string") {
              this.headers.set("content-type", "text/plain;charset=UTF-8");
            } else if (this._bodyBlob && this._bodyBlob.type) {
              this.headers.set("content-type", this._bodyBlob.type);
            } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
              this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
            }
          }
        };
        if (support.blob) {
          this.blob = function() {
            var rejected = consumed(this);
            if (rejected) {
              return rejected;
            }
            if (this._bodyBlob) {
              return Promise.resolve(this._bodyBlob);
            } else if (this._bodyArrayBuffer) {
              return Promise.resolve(new Blob([this._bodyArrayBuffer]));
            } else if (this._bodyFormData) {
              throw new Error("could not read FormData body as blob");
            } else {
              return Promise.resolve(new Blob([this._bodyText]));
            }
          };
          this.arrayBuffer = function() {
            if (this._bodyArrayBuffer) {
              return consumed(this) || Promise.resolve(this._bodyArrayBuffer);
            } else {
              return this.blob().then(readBlobAsArrayBuffer);
            }
          };
        }
        this.text = function() {
          var rejected = consumed(this);
          if (rejected) {
            return rejected;
          }
          if (this._bodyBlob) {
            return readBlobAsText(this._bodyBlob);
          } else if (this._bodyArrayBuffer) {
            return Promise.resolve(readArrayBufferAsText(this._bodyArrayBuffer));
          } else if (this._bodyFormData) {
            throw new Error("could not read FormData body as text");
          } else {
            return Promise.resolve(this._bodyText);
          }
        };
        if (support.formData) {
          this.formData = function() {
            return this.text().then(decode2);
          };
        }
        this.json = function() {
          return this.text().then(JSON.parse);
        };
        return this;
      }
      var methods = ["DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT"];
      function normalizeMethod(method) {
        var upcased = method.toUpperCase();
        return methods.indexOf(upcased) > -1 ? upcased : method;
      }
      function Request2(input, options) {
        options = options || {};
        var body = options.body;
        if (input instanceof Request2) {
          if (input.bodyUsed) {
            throw new TypeError("Already read");
          }
          this.url = input.url;
          this.credentials = input.credentials;
          if (!options.headers) {
            this.headers = new Headers2(input.headers);
          }
          this.method = input.method;
          this.mode = input.mode;
          this.signal = input.signal;
          if (!body && input._bodyInit != null) {
            body = input._bodyInit;
            input.bodyUsed = true;
          }
        } else {
          this.url = String(input);
        }
        this.credentials = options.credentials || this.credentials || "same-origin";
        if (options.headers || !this.headers) {
          this.headers = new Headers2(options.headers);
        }
        this.method = normalizeMethod(options.method || this.method || "GET");
        this.mode = options.mode || this.mode || null;
        this.signal = options.signal || this.signal;
        this.referrer = null;
        if ((this.method === "GET" || this.method === "HEAD") && body) {
          throw new TypeError("Body not allowed for GET or HEAD requests");
        }
        this._initBody(body);
      }
      Request2.prototype.clone = function() {
        return new Request2(this, {body: this._bodyInit});
      };
      function decode2(body) {
        var form = new FormData();
        body.trim().split("&").forEach(function(bytes) {
          if (bytes) {
            var split = bytes.split("=");
            var name2 = split.shift().replace(/\+/g, " ");
            var value = split.join("=").replace(/\+/g, " ");
            form.append(decodeURIComponent(name2), decodeURIComponent(value));
          }
        });
        return form;
      }
      function parseHeaders(rawHeaders) {
        var headers = new Headers2();
        var preProcessedHeaders = rawHeaders.replace(/\r?\n[\t ]+/g, " ");
        preProcessedHeaders.split(/\r?\n/).forEach(function(line) {
          var parts = line.split(":");
          var key = parts.shift().trim();
          if (key) {
            var value = parts.join(":").trim();
            headers.append(key, value);
          }
        });
        return headers;
      }
      Body2.call(Request2.prototype);
      function Response2(bodyInit, options) {
        if (!options) {
          options = {};
        }
        this.type = "default";
        this.status = options.status === void 0 ? 200 : options.status;
        this.ok = this.status >= 200 && this.status < 300;
        this.statusText = "statusText" in options ? options.statusText : "OK";
        this.headers = new Headers2(options.headers);
        this.url = options.url || "";
        this._initBody(bodyInit);
      }
      Body2.call(Response2.prototype);
      Response2.prototype.clone = function() {
        return new Response2(this._bodyInit, {
          status: this.status,
          statusText: this.statusText,
          headers: new Headers2(this.headers),
          url: this.url
        });
      };
      Response2.error = function() {
        var response = new Response2(null, {status: 0, statusText: ""});
        response.type = "error";
        return response;
      };
      var redirectStatuses = [301, 302, 303, 307, 308];
      Response2.redirect = function(url2, status) {
        if (redirectStatuses.indexOf(status) === -1) {
          throw new RangeError("Invalid status code");
        }
        return new Response2(null, {status, headers: {location: url2}});
      };
      exports2.DOMException = self2.DOMException;
      try {
        new exports2.DOMException();
      } catch (err) {
        exports2.DOMException = function(message, name2) {
          this.message = message;
          this.name = name2;
          var error2 = Error(message);
          this.stack = error2.stack;
        };
        exports2.DOMException.prototype = Object.create(Error.prototype);
        exports2.DOMException.prototype.constructor = exports2.DOMException;
      }
      function fetch2(input, init2) {
        return new Promise(function(resolve2, reject) {
          var request = new Request2(input, init2);
          if (request.signal && request.signal.aborted) {
            return reject(new exports2.DOMException("Aborted", "AbortError"));
          }
          var xhr = new XMLHttpRequest();
          function abortXhr() {
            xhr.abort();
          }
          xhr.onload = function() {
            var options = {
              status: xhr.status,
              statusText: xhr.statusText,
              headers: parseHeaders(xhr.getAllResponseHeaders() || "")
            };
            options.url = "responseURL" in xhr ? xhr.responseURL : options.headers.get("X-Request-URL");
            var body = "response" in xhr ? xhr.response : xhr.responseText;
            resolve2(new Response2(body, options));
          };
          xhr.onerror = function() {
            reject(new TypeError("Network request failed"));
          };
          xhr.ontimeout = function() {
            reject(new TypeError("Network request failed"));
          };
          xhr.onabort = function() {
            reject(new exports2.DOMException("Aborted", "AbortError"));
          };
          xhr.open(request.method, request.url, true);
          if (request.credentials === "include") {
            xhr.withCredentials = true;
          } else if (request.credentials === "omit") {
            xhr.withCredentials = false;
          }
          if ("responseType" in xhr && support.blob) {
            xhr.responseType = "blob";
          }
          request.headers.forEach(function(value, name2) {
            xhr.setRequestHeader(name2, value);
          });
          if (request.signal) {
            request.signal.addEventListener("abort", abortXhr);
            xhr.onreadystatechange = function() {
              if (xhr.readyState === 4) {
                request.signal.removeEventListener("abort", abortXhr);
              }
            };
          }
          xhr.send(typeof request._bodyInit === "undefined" ? null : request._bodyInit);
        });
      }
      fetch2.polyfill = true;
      if (!self2.fetch) {
        self2.fetch = fetch2;
        self2.Headers = Headers2;
        self2.Request = Request2;
        self2.Response = Response2;
      }
      exports2.Headers = Headers2;
      exports2.Request = Request2;
      exports2.Response = Response2;
      exports2.fetch = fetch2;
      Object.defineProperty(exports2, "__esModule", {value: true});
      return exports2;
    })({});
  })(__self__);
  __self__.fetch.ponyfill = true;
  delete __self__.fetch.polyfill;
  var ctx = __self__;
  exports = ctx.fetch;
  exports.default = ctx.fetch;
  exports.fetch = ctx.fetch;
  exports.Headers = ctx.Headers;
  exports.Request = ctx.Request;
  exports.Response = ctx.Response;
  module.exports = exports;
});
var fetch$1 = /* @__PURE__ */ getDefaultExportFromCjs(browserPonyfill);
var __awaiter$8 = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
const _getErrorMessage$1 = (err) => err.msg || err.message || err.error_description || err.error || JSON.stringify(err);
const handleError$1 = (error2, reject) => {
  if (typeof error2.json !== "function") {
    return reject(error2);
  }
  error2.json().then((err) => {
    return reject({
      message: _getErrorMessage$1(err),
      status: (error2 === null || error2 === void 0 ? void 0 : error2.status) || 500
    });
  });
};
const _getRequestParams$1 = (method, options, body) => {
  const params = {method, headers: (options === null || options === void 0 ? void 0 : options.headers) || {}};
  if (method === "GET") {
    return params;
  }
  params.headers = Object.assign({"Content-Type": "text/plain;charset=UTF-8"}, options === null || options === void 0 ? void 0 : options.headers);
  params.body = JSON.stringify(body);
  return params;
};
function _handleRequest$1(method, url2, options, body) {
  return __awaiter$8(this, void 0, void 0, function* () {
    return new Promise((resolve2, reject) => {
      fetch$1(url2, _getRequestParams$1(method, options, body)).then((result) => {
        if (!result.ok)
          throw result;
        if (options === null || options === void 0 ? void 0 : options.noResolveJson)
          return resolve2;
        return result.json();
      }).then((data) => resolve2(data)).catch((error2) => handleError$1(error2, reject));
    });
  });
}
function get$1(url2, options) {
  return __awaiter$8(this, void 0, void 0, function* () {
    return _handleRequest$1("GET", url2, options);
  });
}
function post$1(url2, body, options) {
  return __awaiter$8(this, void 0, void 0, function* () {
    return _handleRequest$1("POST", url2, options, body);
  });
}
function put(url2, body, options) {
  return __awaiter$8(this, void 0, void 0, function* () {
    return _handleRequest$1("PUT", url2, options, body);
  });
}
function remove$1(url2, body, options) {
  return __awaiter$8(this, void 0, void 0, function* () {
    return _handleRequest$1("DELETE", url2, options, body);
  });
}
const GOTRUE_URL = "http://localhost:9999";
const DEFAULT_HEADERS = {};
const STORAGE_KEY = "supabase.auth.token";
const COOKIE_OPTIONS = {
  name: "sb:token",
  lifetime: 60 * 60 * 8,
  domain: "",
  path: "/",
  sameSite: "lax"
};
function serialize(name2, val, options) {
  const opt = options || {};
  const enc = encodeURIComponent;
  const fieldContentRegExp = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name2)) {
    throw new TypeError("argument name is invalid");
  }
  const value = enc(val);
  if (value && !fieldContentRegExp.test(value)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name2 + "=" + value;
  if (opt.maxAge != null) {
    const maxAge = opt.maxAge - 0;
    if (isNaN(maxAge) || !isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (typeof opt.expires.toUTCString !== "function") {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case "lax":
        str += "; SameSite=Lax";
        break;
      case "strict":
        str += "; SameSite=Strict";
        break;
      case "none":
        str += "; SameSite=None";
        break;
      default:
        throw new TypeError("option sameSite is invalid");
    }
  }
  return str;
}
function isSecureEnvironment(req) {
  if (!req || !req.headers || !req.headers.host) {
    throw new Error('The "host" request header is not available');
  }
  const host = req.headers.host.indexOf(":") > -1 && req.headers.host.split(":")[0] || req.headers.host;
  if (["localhost", "127.0.0.1"].indexOf(host) > -1 || host.endsWith(".local")) {
    return false;
  }
  return true;
}
function serializeCookie(cookie, secure) {
  var _a, _b, _c;
  return serialize(cookie.name, cookie.value, {
    maxAge: cookie.maxAge,
    expires: new Date(Date.now() + cookie.maxAge * 1e3),
    httpOnly: true,
    secure,
    path: (_a = cookie.path) !== null && _a !== void 0 ? _a : "/",
    domain: (_b = cookie.domain) !== null && _b !== void 0 ? _b : "",
    sameSite: (_c = cookie.sameSite) !== null && _c !== void 0 ? _c : "lax"
  });
}
function setCookies(req, res, cookies) {
  const strCookies = cookies.map((c) => serializeCookie(c, isSecureEnvironment(req)));
  const previousCookies = res.getHeader("Set-Cookie");
  if (previousCookies) {
    if (previousCookies instanceof Array) {
      Array.prototype.push.apply(strCookies, previousCookies);
    } else if (typeof previousCookies === "string") {
      strCookies.push(previousCookies);
    }
  }
  res.setHeader("Set-Cookie", strCookies);
}
function setCookie(req, res, cookie) {
  setCookies(req, res, [cookie]);
}
function deleteCookie(req, res, name2) {
  setCookie(req, res, {
    name: name2,
    value: "",
    maxAge: -1
  });
}
function expiresAt(expiresIn) {
  const timeNow = Math.round(Date.now() / 1e3);
  return timeNow + expiresIn;
}
function uuid() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
const isBrowser$1 = () => typeof window !== "undefined";
function getParameterByName(name2, url2) {
  if (!url2)
    url2 = window.location.href;
  name2 = name2.replace(/[\[\]]/g, "\\$&");
  var regex = new RegExp("[?&#]" + name2 + "(=([^&#]*)|&|#|$)"), results = regex.exec(url2);
  if (!results)
    return null;
  if (!results[2])
    return "";
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}
class LocalStorage {
  constructor(localStorage) {
    this.localStorage = localStorage || globalThis.localStorage;
  }
  clear() {
    return this.localStorage.clear();
  }
  key(index2) {
    return this.localStorage.key(index2);
  }
  setItem(key, value) {
    return this.localStorage.setItem(key, value);
  }
  getItem(key) {
    return this.localStorage.getItem(key);
  }
  removeItem(key) {
    return this.localStorage.removeItem(key);
  }
}
var __awaiter$7 = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
class GoTrueApi {
  constructor({url: url2 = "", headers = {}, cookieOptions}) {
    this.url = url2;
    this.headers = headers;
    this.cookieOptions = Object.assign(Object.assign({}, COOKIE_OPTIONS), cookieOptions);
  }
  signUpWithEmail(email, password, options = {}) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        let headers = Object.assign({}, this.headers);
        if (options.redirectTo) {
          headers["referer"] = options.redirectTo;
        }
        const data = yield post$1(`${this.url}/signup`, {email, password}, {headers});
        let session = Object.assign({}, data);
        if (session.expires_in)
          session.expires_at = expiresAt(data.expires_in);
        return {data: session, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  signInWithEmail(email, password, options = {}) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        let headers = Object.assign({}, this.headers);
        if (options.redirectTo) {
          headers["referer"] = options.redirectTo;
        }
        const data = yield post$1(`${this.url}/token?grant_type=password`, {email, password}, {headers});
        let session = Object.assign({}, data);
        if (session.expires_in)
          session.expires_at = expiresAt(data.expires_in);
        return {data: session, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  sendMagicLinkEmail(email, options = {}) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        let headers = Object.assign({}, this.headers);
        if (options.redirectTo) {
          headers["referer"] = options.redirectTo;
        }
        const data = yield post$1(`${this.url}/magiclink`, {email}, {headers});
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  inviteUserByEmail(email, options = {}) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        let headers = Object.assign({}, this.headers);
        if (options.redirectTo) {
          headers["referer"] = options.redirectTo;
        }
        const data = yield post$1(`${this.url}/invite`, {email}, {headers});
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  resetPasswordForEmail(email, options = {}) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        let headers = Object.assign({}, this.headers);
        if (options.redirectTo) {
          headers["referer"] = options.redirectTo;
        }
        const data = yield post$1(`${this.url}/recover`, {email}, {headers});
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  _createRequestHeaders(jwt) {
    const headers = Object.assign({}, this.headers);
    headers["Authorization"] = `Bearer ${jwt}`;
    return headers;
  }
  signOut(jwt) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        yield post$1(`${this.url}/logout`, {}, {headers: this._createRequestHeaders(jwt), noResolveJson: true});
        return {error: null};
      } catch (error2) {
        return {error: error2};
      }
    });
  }
  getUrlForProvider(provider, options) {
    let urlParams = [`provider=${provider}`];
    if (options === null || options === void 0 ? void 0 : options.redirectTo) {
      urlParams.push(`redirect_to=${options.redirectTo}`);
    }
    if (options === null || options === void 0 ? void 0 : options.scopes) {
      urlParams.push(`scopes=${options.scopes}`);
    }
    return `${this.url}/authorize?${urlParams.join("&")}`;
  }
  getUser(jwt) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        const data = yield get$1(`${this.url}/user`, {headers: this._createRequestHeaders(jwt)});
        return {user: data, data, error: null};
      } catch (error2) {
        return {user: null, data: null, error: error2};
      }
    });
  }
  updateUser(jwt, attributes) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        const data = yield put(`${this.url}/user`, attributes, {
          headers: this._createRequestHeaders(jwt)
        });
        return {user: data, data, error: null};
      } catch (error2) {
        return {user: null, data: null, error: error2};
      }
    });
  }
  deleteUser(uid, jwt) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        const data = yield remove$1(`${this.url}/admin/users/${uid}`, {}, {
          headers: this._createRequestHeaders(jwt)
        });
        return {user: data, data, error: null};
      } catch (error2) {
        return {user: null, data: null, error: error2};
      }
    });
  }
  refreshAccessToken(refreshToken) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        const data = yield post$1(`${this.url}/token?grant_type=refresh_token`, {refresh_token: refreshToken}, {headers: this.headers});
        let session = Object.assign({}, data);
        if (session.expires_in)
          session.expires_at = expiresAt(data.expires_in);
        return {data: session, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  setAuthCookie(req, res) {
    if (req.method !== "POST") {
      res.setHeader("Allow", "POST");
      res.status(405).end("Method Not Allowed");
    }
    const {event, session} = req.body;
    if (!event)
      throw new Error("Auth event missing!");
    if (event === "SIGNED_IN") {
      if (!session)
        throw new Error("Auth session missing!");
      setCookie(req, res, {
        name: this.cookieOptions.name,
        value: session.access_token,
        domain: this.cookieOptions.domain,
        maxAge: this.cookieOptions.lifetime,
        path: this.cookieOptions.path,
        sameSite: this.cookieOptions.sameSite
      });
    }
    if (event === "SIGNED_OUT")
      deleteCookie(req, res, this.cookieOptions.name);
    res.status(200).json({});
  }
  getUserByCookie(req) {
    return __awaiter$7(this, void 0, void 0, function* () {
      try {
        if (!req.cookies)
          throw new Error("Not able to parse cookies! When using Express make sure the cookie-parser middleware is in use!");
        if (!req.cookies[this.cookieOptions.name])
          throw new Error("No cookie found!");
        const token = req.cookies[this.cookieOptions.name];
        const {user, error: error2} = yield this.getUser(token);
        if (error2)
          throw error2;
        return {user, data: user, error: null};
      } catch (error2) {
        return {user: null, data: null, error: error2};
      }
    });
  }
}
function polyfillGlobalThis() {
  if (typeof globalThis === "object")
    return;
  try {
    Object.defineProperty(Object.prototype, "__magic__", {
      get: function() {
        return this;
      },
      configurable: true
    });
    __magic__.globalThis = __magic__;
    delete Object.prototype.__magic__;
  } catch (e) {
    if (typeof self !== "undefined") {
      self.globalThis = self;
    }
  }
}
var __awaiter$6 = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
polyfillGlobalThis();
const DEFAULT_OPTIONS$1 = {
  url: GOTRUE_URL,
  autoRefreshToken: true,
  persistSession: true,
  localStorage: globalThis.localStorage,
  detectSessionInUrl: true,
  headers: DEFAULT_HEADERS
};
class GoTrueClient {
  constructor(options) {
    this.stateChangeEmitters = new Map();
    const settings = Object.assign(Object.assign({}, DEFAULT_OPTIONS$1), options);
    this.currentUser = null;
    this.currentSession = null;
    this.autoRefreshToken = settings.autoRefreshToken;
    this.persistSession = settings.persistSession;
    this.localStorage = new LocalStorage(settings.localStorage);
    this.api = new GoTrueApi({
      url: settings.url,
      headers: settings.headers,
      cookieOptions: settings.cookieOptions
    });
    this._recoverSession();
    this._recoverAndRefresh();
    try {
      if (settings.detectSessionInUrl && isBrowser$1() && !!getParameterByName("access_token")) {
        this.getSessionFromUrl({storeSession: true});
      }
    } catch (error2) {
      console.log("Error getting session from URL.");
    }
  }
  signUp({email, password}, options = {}) {
    return __awaiter$6(this, void 0, void 0, function* () {
      try {
        this._removeSession();
        const {data, error: error2} = yield this.api.signUpWithEmail(email, password, {
          redirectTo: options.redirectTo
        });
        if (error2) {
          throw error2;
        }
        if (!data) {
          throw "An error occurred on sign up.";
        }
        let session = null;
        let user = null;
        if (data.access_token) {
          session = data;
          user = session.user;
          this._saveSession(session);
          this._notifyAllSubscribers("SIGNED_IN");
        }
        if (data.id) {
          user = data;
        }
        return {data, user, session, error: null};
      } catch (error2) {
        return {data: null, user: null, session: null, error: error2};
      }
    });
  }
  signIn({email, password, provider}, options = {}) {
    return __awaiter$6(this, void 0, void 0, function* () {
      try {
        this._removeSession();
        if (email && !password) {
          const {error: error2} = yield this.api.sendMagicLinkEmail(email, {
            redirectTo: options.redirectTo
          });
          return {data: null, user: null, session: null, error: error2};
        }
        if (email && password) {
          return this._handleEmailSignIn(email, password, {
            redirectTo: options.redirectTo
          });
        }
        if (provider) {
          return this._handleProviderSignIn(provider, {
            redirectTo: options.redirectTo,
            scopes: options.scopes
          });
        }
        throw new Error(`You must provide either an email or a third-party provider.`);
      } catch (error2) {
        return {data: null, user: null, session: null, error: error2};
      }
    });
  }
  user() {
    return this.currentUser;
  }
  session() {
    return this.currentSession;
  }
  refreshSession() {
    var _a;
    return __awaiter$6(this, void 0, void 0, function* () {
      try {
        if (!((_a = this.currentSession) === null || _a === void 0 ? void 0 : _a.access_token))
          throw new Error("Not logged in.");
        const {error: error2} = yield this._callRefreshToken();
        if (error2)
          throw error2;
        return {data: this.currentSession, user: this.currentUser, error: null};
      } catch (error2) {
        return {data: null, user: null, error: error2};
      }
    });
  }
  update(attributes) {
    var _a;
    return __awaiter$6(this, void 0, void 0, function* () {
      try {
        if (!((_a = this.currentSession) === null || _a === void 0 ? void 0 : _a.access_token))
          throw new Error("Not logged in.");
        const {user, error: error2} = yield this.api.updateUser(this.currentSession.access_token, attributes);
        if (error2)
          throw error2;
        if (!user)
          throw Error("Invalid user data.");
        const session = Object.assign(Object.assign({}, this.currentSession), {user});
        this._saveSession(session);
        this._notifyAllSubscribers("USER_UPDATED");
        return {data: user, user, error: null};
      } catch (error2) {
        return {data: null, user: null, error: error2};
      }
    });
  }
  setSession(refresh_token) {
    return __awaiter$6(this, void 0, void 0, function* () {
      try {
        if (!refresh_token) {
          throw new Error("No current session.");
        }
        const {data, error: error2} = yield this.api.refreshAccessToken(refresh_token);
        if (error2) {
          return {session: null, error: error2};
        }
        if (!data) {
          return {
            session: null,
            error: {name: "Invalid refresh_token", message: "JWT token provided is Invalid"}
          };
        }
        this._saveSession(data);
        this._notifyAllSubscribers("SIGNED_IN");
        return {session: data, error: null};
      } catch (error2) {
        return {error: error2, session: null};
      }
    });
  }
  setAuth(access_token) {
    this.currentSession = Object.assign(Object.assign({}, this.currentSession), {access_token, token_type: "bearer", user: null});
    return this.currentSession;
  }
  getSessionFromUrl(options) {
    return __awaiter$6(this, void 0, void 0, function* () {
      try {
        if (!isBrowser$1())
          throw new Error("No browser detected.");
        const error_description = getParameterByName("error_description");
        if (error_description)
          throw new Error(error_description);
        const provider_token = getParameterByName("provider_token");
        const access_token = getParameterByName("access_token");
        if (!access_token)
          throw new Error("No access_token detected.");
        const expires_in = getParameterByName("expires_in");
        if (!expires_in)
          throw new Error("No expires_in detected.");
        const refresh_token = getParameterByName("refresh_token");
        if (!refresh_token)
          throw new Error("No refresh_token detected.");
        const token_type = getParameterByName("token_type");
        if (!token_type)
          throw new Error("No token_type detected.");
        const timeNow = Math.round(Date.now() / 1e3);
        const expires_at = timeNow + parseInt(expires_in);
        const {user, error: error2} = yield this.api.getUser(access_token);
        if (error2)
          throw error2;
        const session = {
          provider_token,
          access_token,
          expires_in: parseInt(expires_in),
          expires_at,
          refresh_token,
          token_type,
          user
        };
        if (options === null || options === void 0 ? void 0 : options.storeSession) {
          this._saveSession(session);
          this._notifyAllSubscribers("SIGNED_IN");
          if (getParameterByName("type") === "recovery") {
            this._notifyAllSubscribers("PASSWORD_RECOVERY");
          }
        }
        window.location.hash = "";
        return {data: session, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  signOut() {
    var _a;
    return __awaiter$6(this, void 0, void 0, function* () {
      const accessToken = (_a = this.currentSession) === null || _a === void 0 ? void 0 : _a.access_token;
      this._removeSession();
      this._notifyAllSubscribers("SIGNED_OUT");
      if (accessToken) {
        const {error: error2} = yield this.api.signOut(accessToken);
        if (error2)
          return {error: error2};
      }
      return {error: null};
    });
  }
  onAuthStateChange(callback) {
    try {
      const id = uuid();
      const self2 = this;
      const subscription = {
        id,
        callback,
        unsubscribe: () => {
          self2.stateChangeEmitters.delete(id);
        }
      };
      this.stateChangeEmitters.set(id, subscription);
      return {data: subscription, error: null};
    } catch (error2) {
      return {data: null, error: error2};
    }
  }
  _handleEmailSignIn(email, password, options = {}) {
    var _a;
    return __awaiter$6(this, void 0, void 0, function* () {
      try {
        const {data, error: error2} = yield this.api.signInWithEmail(email, password, {
          redirectTo: options.redirectTo
        });
        if (error2 || !data)
          return {data: null, user: null, session: null, error: error2};
        if ((_a = data === null || data === void 0 ? void 0 : data.user) === null || _a === void 0 ? void 0 : _a.confirmed_at) {
          this._saveSession(data);
          this._notifyAllSubscribers("SIGNED_IN");
        }
        return {data, user: data.user, session: data, error: null};
      } catch (error2) {
        return {data: null, user: null, session: null, error: error2};
      }
    });
  }
  _handleProviderSignIn(provider, options = {}) {
    const url2 = this.api.getUrlForProvider(provider, {
      redirectTo: options.redirectTo,
      scopes: options.scopes
    });
    try {
      if (isBrowser$1()) {
        window.location.href = url2;
      }
      return {provider, url: url2, data: null, session: null, user: null, error: null};
    } catch (error2) {
      if (!!url2)
        return {provider, url: url2, data: null, session: null, user: null, error: null};
      return {data: null, user: null, session: null, error: error2};
    }
  }
  _recoverSession() {
    var _a;
    try {
      const json = isBrowser$1() && ((_a = this.localStorage) === null || _a === void 0 ? void 0 : _a.getItem(STORAGE_KEY));
      if (!json || typeof json !== "string") {
        return null;
      }
      const data = JSON.parse(json);
      const {currentSession, expiresAt: expiresAt2} = data;
      const timeNow = Math.round(Date.now() / 1e3);
      if (expiresAt2 >= timeNow && (currentSession === null || currentSession === void 0 ? void 0 : currentSession.user)) {
        this._saveSession(currentSession);
        this._notifyAllSubscribers("SIGNED_IN");
      }
    } catch (error2) {
      console.log("error", error2);
    }
  }
  _recoverAndRefresh() {
    return __awaiter$6(this, void 0, void 0, function* () {
      try {
        const json = isBrowser$1() && (yield this.localStorage.getItem(STORAGE_KEY));
        if (!json) {
          return null;
        }
        const data = JSON.parse(json);
        const {currentSession, expiresAt: expiresAt2} = data;
        const timeNow = Math.round(Date.now() / 1e3);
        if (expiresAt2 < timeNow) {
          if (this.autoRefreshToken && currentSession.refresh_token) {
            const {error: error2} = yield this._callRefreshToken(currentSession.refresh_token);
            if (error2) {
              console.log(error2.message);
              yield this._removeSession();
            }
          } else {
            this._removeSession();
          }
        } else if (!currentSession || !currentSession.user) {
          console.log("Current session is missing data.");
          this._removeSession();
        } else {
          this._saveSession(currentSession);
          this._notifyAllSubscribers("SIGNED_IN");
        }
      } catch (err) {
        console.error(err);
        return null;
      }
    });
  }
  _callRefreshToken(refresh_token) {
    var _a;
    if (refresh_token === void 0) {
      refresh_token = (_a = this.currentSession) === null || _a === void 0 ? void 0 : _a.refresh_token;
    }
    return __awaiter$6(this, void 0, void 0, function* () {
      try {
        if (!refresh_token) {
          throw new Error("No current session.");
        }
        const {data, error: error2} = yield this.api.refreshAccessToken(refresh_token);
        if (error2)
          throw error2;
        if (!data)
          throw Error("Invalid session data.");
        this._saveSession(data);
        this._notifyAllSubscribers("SIGNED_IN");
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  _notifyAllSubscribers(event) {
    this.stateChangeEmitters.forEach((x) => x.callback(event, this.currentSession));
  }
  _saveSession(session) {
    this.currentSession = session;
    this.currentUser = session.user;
    const expiresAt2 = session.expires_at;
    const timeNow = Math.round(Date.now() / 1e3);
    if (expiresAt2)
      this._startAutoRefreshToken((expiresAt2 - timeNow - 60) * 1e3);
    if (this.persistSession && session.expires_at) {
      this._persistSession(this.currentSession);
    }
  }
  _persistSession(currentSession) {
    const data = {currentSession, expiresAt: currentSession.expires_at};
    isBrowser$1() && this.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }
  _removeSession() {
    return __awaiter$6(this, void 0, void 0, function* () {
      this.currentSession = null;
      this.currentUser = null;
      if (this.refreshTokenTimer)
        clearTimeout(this.refreshTokenTimer);
      isBrowser$1() && (yield this.localStorage.removeItem(STORAGE_KEY));
    });
  }
  _startAutoRefreshToken(value) {
    if (this.refreshTokenTimer)
      clearTimeout(this.refreshTokenTimer);
    if (!value || !this.autoRefreshToken)
      return;
    this.refreshTokenTimer = setTimeout(() => this._callRefreshToken(), value);
  }
}
class SupabaseAuthClient extends GoTrueClient {
  constructor(options) {
    super(options);
  }
}
var __awaiter$5 = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
class PostgrestBuilder {
  constructor(builder) {
    Object.assign(this, builder);
  }
  then(onfulfilled, onrejected) {
    if (typeof this.schema === "undefined")
      ;
    else if (["GET", "HEAD"].includes(this.method)) {
      this.headers["Accept-Profile"] = this.schema;
    } else {
      this.headers["Content-Profile"] = this.schema;
    }
    if (this.method !== "GET" && this.method !== "HEAD") {
      this.headers["Content-Type"] = "application/json";
    }
    return fetch$1(this.url.toString(), {
      method: this.method,
      headers: this.headers,
      body: JSON.stringify(this.body)
    }).then((res) => __awaiter$5(this, void 0, void 0, function* () {
      var _a, _b, _c;
      let error2 = null;
      let data = null;
      let count = null;
      if (res.ok) {
        const isReturnMinimal = (_a = this.headers["Prefer"]) === null || _a === void 0 ? void 0 : _a.split(",").includes("return=minimal");
        if (this.method !== "HEAD" && !isReturnMinimal) {
          const text = yield res.text();
          if (text && text !== "")
            data = JSON.parse(text);
        }
        const countHeader = (_b = this.headers["Prefer"]) === null || _b === void 0 ? void 0 : _b.match(/count=(exact|planned|estimated)/);
        const contentRange = (_c = res.headers.get("content-range")) === null || _c === void 0 ? void 0 : _c.split("/");
        if (countHeader && contentRange && contentRange.length > 1) {
          count = parseInt(contentRange[1]);
        }
      } else {
        error2 = yield res.json();
      }
      const postgrestResponse = {
        error: error2,
        data,
        count,
        status: res.status,
        statusText: res.statusText,
        body: data
      };
      return postgrestResponse;
    })).then(onfulfilled, onrejected);
  }
}
class PostgrestTransformBuilder extends PostgrestBuilder {
  select(columns = "*") {
    let quoted = false;
    const cleanedColumns = columns.split("").map((c) => {
      if (/\s/.test(c) && !quoted) {
        return "";
      }
      if (c === '"') {
        quoted = !quoted;
      }
      return c;
    }).join("");
    this.url.searchParams.set("select", cleanedColumns);
    return this;
  }
  order(column, {ascending = true, nullsFirst = false, foreignTable} = {}) {
    const key = typeof foreignTable === "undefined" ? "order" : `${foreignTable}.order`;
    const existingOrder = this.url.searchParams.get(key);
    this.url.searchParams.set(key, `${existingOrder ? `${existingOrder},` : ""}${column}.${ascending ? "asc" : "desc"}.${nullsFirst ? "nullsfirst" : "nullslast"}`);
    return this;
  }
  limit(count, {foreignTable} = {}) {
    const key = typeof foreignTable === "undefined" ? "limit" : `${foreignTable}.limit`;
    this.url.searchParams.set(key, `${count}`);
    return this;
  }
  range(from, to, {foreignTable} = {}) {
    const keyOffset = typeof foreignTable === "undefined" ? "offset" : `${foreignTable}.offset`;
    const keyLimit = typeof foreignTable === "undefined" ? "limit" : `${foreignTable}.limit`;
    this.url.searchParams.set(keyOffset, `${from}`);
    this.url.searchParams.set(keyLimit, `${to - from + 1}`);
    return this;
  }
  single() {
    this.headers["Accept"] = "application/vnd.pgrst.object+json";
    return this;
  }
}
class PostgrestFilterBuilder extends PostgrestTransformBuilder {
  constructor() {
    super(...arguments);
    this.cs = this.contains;
    this.cd = this.containedBy;
    this.sl = this.rangeLt;
    this.sr = this.rangeGt;
    this.nxl = this.rangeGte;
    this.nxr = this.rangeLte;
    this.adj = this.rangeAdjacent;
    this.ov = this.overlaps;
  }
  not(column, operator, value) {
    this.url.searchParams.append(`${column}`, `not.${operator}.${value}`);
    return this;
  }
  or(filters, {foreignTable} = {}) {
    const key = typeof foreignTable === "undefined" ? "or" : `${foreignTable}.or`;
    this.url.searchParams.append(key, `(${filters})`);
    return this;
  }
  eq(column, value) {
    this.url.searchParams.append(`${column}`, `eq.${value}`);
    return this;
  }
  neq(column, value) {
    this.url.searchParams.append(`${column}`, `neq.${value}`);
    return this;
  }
  gt(column, value) {
    this.url.searchParams.append(`${column}`, `gt.${value}`);
    return this;
  }
  gte(column, value) {
    this.url.searchParams.append(`${column}`, `gte.${value}`);
    return this;
  }
  lt(column, value) {
    this.url.searchParams.append(`${column}`, `lt.${value}`);
    return this;
  }
  lte(column, value) {
    this.url.searchParams.append(`${column}`, `lte.${value}`);
    return this;
  }
  like(column, pattern) {
    this.url.searchParams.append(`${column}`, `like.${pattern}`);
    return this;
  }
  ilike(column, pattern) {
    this.url.searchParams.append(`${column}`, `ilike.${pattern}`);
    return this;
  }
  is(column, value) {
    this.url.searchParams.append(`${column}`, `is.${value}`);
    return this;
  }
  in(column, values) {
    const cleanedValues = values.map((s2) => {
      if (typeof s2 === "string" && new RegExp("[,()]").test(s2))
        return `"${s2}"`;
      else
        return `${s2}`;
    }).join(",");
    this.url.searchParams.append(`${column}`, `in.(${cleanedValues})`);
    return this;
  }
  contains(column, value) {
    if (typeof value === "string") {
      this.url.searchParams.append(`${column}`, `cs.${value}`);
    } else if (Array.isArray(value)) {
      this.url.searchParams.append(`${column}`, `cs.{${value.join(",")}}`);
    } else {
      this.url.searchParams.append(`${column}`, `cs.${JSON.stringify(value)}`);
    }
    return this;
  }
  containedBy(column, value) {
    if (typeof value === "string") {
      this.url.searchParams.append(`${column}`, `cd.${value}`);
    } else if (Array.isArray(value)) {
      this.url.searchParams.append(`${column}`, `cd.{${value.join(",")}}`);
    } else {
      this.url.searchParams.append(`${column}`, `cd.${JSON.stringify(value)}`);
    }
    return this;
  }
  rangeLt(column, range) {
    this.url.searchParams.append(`${column}`, `sl.${range}`);
    return this;
  }
  rangeGt(column, range) {
    this.url.searchParams.append(`${column}`, `sr.${range}`);
    return this;
  }
  rangeGte(column, range) {
    this.url.searchParams.append(`${column}`, `nxl.${range}`);
    return this;
  }
  rangeLte(column, range) {
    this.url.searchParams.append(`${column}`, `nxr.${range}`);
    return this;
  }
  rangeAdjacent(column, range) {
    this.url.searchParams.append(`${column}`, `adj.${range}`);
    return this;
  }
  overlaps(column, value) {
    if (typeof value === "string") {
      this.url.searchParams.append(`${column}`, `ov.${value}`);
    } else {
      this.url.searchParams.append(`${column}`, `ov.{${value.join(",")}}`);
    }
    return this;
  }
  textSearch(column, query, {config: config2, type = null} = {}) {
    let typePart = "";
    if (type === "plain") {
      typePart = "pl";
    } else if (type === "phrase") {
      typePart = "ph";
    } else if (type === "websearch") {
      typePart = "w";
    }
    const configPart = config2 === void 0 ? "" : `(${config2})`;
    this.url.searchParams.append(`${column}`, `${typePart}fts${configPart}.${query}`);
    return this;
  }
  fts(column, query, {config: config2} = {}) {
    const configPart = typeof config2 === "undefined" ? "" : `(${config2})`;
    this.url.searchParams.append(`${column}`, `fts${configPart}.${query}`);
    return this;
  }
  plfts(column, query, {config: config2} = {}) {
    const configPart = typeof config2 === "undefined" ? "" : `(${config2})`;
    this.url.searchParams.append(`${column}`, `plfts${configPart}.${query}`);
    return this;
  }
  phfts(column, query, {config: config2} = {}) {
    const configPart = typeof config2 === "undefined" ? "" : `(${config2})`;
    this.url.searchParams.append(`${column}`, `phfts${configPart}.${query}`);
    return this;
  }
  wfts(column, query, {config: config2} = {}) {
    const configPart = typeof config2 === "undefined" ? "" : `(${config2})`;
    this.url.searchParams.append(`${column}`, `wfts${configPart}.${query}`);
    return this;
  }
  filter(column, operator, value) {
    this.url.searchParams.append(`${column}`, `${operator}.${value}`);
    return this;
  }
  match(query) {
    Object.keys(query).forEach((key) => {
      this.url.searchParams.append(`${key}`, `eq.${query[key]}`);
    });
    return this;
  }
}
class PostgrestQueryBuilder extends PostgrestBuilder {
  constructor(url2, {headers = {}, schema} = {}) {
    super({});
    this.url = new URL(url2);
    this.headers = Object.assign({}, headers);
    this.schema = schema;
  }
  select(columns = "*", {head = false, count = null} = {}) {
    this.method = "GET";
    let quoted = false;
    const cleanedColumns = columns.split("").map((c) => {
      if (/\s/.test(c) && !quoted) {
        return "";
      }
      if (c === '"') {
        quoted = !quoted;
      }
      return c;
    }).join("");
    this.url.searchParams.set("select", cleanedColumns);
    if (count) {
      this.headers["Prefer"] = `count=${count}`;
    }
    if (head) {
      this.method = "HEAD";
    }
    return new PostgrestFilterBuilder(this);
  }
  insert(values, {upsert = false, onConflict, returning = "representation", count = null} = {}) {
    this.method = "POST";
    const prefersHeaders = [`return=${returning}`];
    if (upsert)
      prefersHeaders.push("resolution=merge-duplicates");
    if (upsert && onConflict !== void 0)
      this.url.searchParams.set("on_conflict", onConflict);
    this.body = values;
    if (count) {
      prefersHeaders.push(`count=${count}`);
    }
    this.headers["Prefer"] = prefersHeaders.join(",");
    if (Array.isArray(values)) {
      const columns = values.reduce((acc, x) => acc.concat(Object.keys(x)), []);
      if (columns.length > 0) {
        const uniqueColumns = [...new Set(columns)];
        this.url.searchParams.set("columns", uniqueColumns.join(","));
      }
    }
    return new PostgrestFilterBuilder(this);
  }
  upsert(values, {onConflict, returning = "representation", count = null} = {}) {
    this.method = "POST";
    const prefersHeaders = ["resolution=merge-duplicates", `return=${returning}`];
    if (onConflict !== void 0)
      this.url.searchParams.set("on_conflict", onConflict);
    this.body = values;
    if (count) {
      prefersHeaders.push(`count=${count}`);
    }
    this.headers["Prefer"] = prefersHeaders.join(",");
    return new PostgrestFilterBuilder(this);
  }
  update(values, {returning = "representation", count = null} = {}) {
    this.method = "PATCH";
    const prefersHeaders = [`return=${returning}`];
    this.body = values;
    if (count) {
      prefersHeaders.push(`count=${count}`);
    }
    this.headers["Prefer"] = prefersHeaders.join(",");
    return new PostgrestFilterBuilder(this);
  }
  delete({returning = "representation", count = null} = {}) {
    this.method = "DELETE";
    const prefersHeaders = [`return=${returning}`];
    if (count) {
      prefersHeaders.push(`count=${count}`);
    }
    this.headers["Prefer"] = prefersHeaders.join(",");
    return new PostgrestFilterBuilder(this);
  }
}
class PostgrestRpcBuilder extends PostgrestBuilder {
  constructor(url2, {headers = {}, schema} = {}) {
    super({});
    this.url = new URL(url2);
    this.headers = Object.assign({}, headers);
    this.schema = schema;
  }
  rpc(params, {count = null} = {}) {
    this.method = "POST";
    this.body = params;
    if (count) {
      if (this.headers["Prefer"] !== void 0)
        this.headers["Prefer"] += `,count=${count}`;
      else
        this.headers["Prefer"] = `count=${count}`;
    }
    return new PostgrestFilterBuilder(this);
  }
}
class PostgrestClient {
  constructor(url2, {headers = {}, schema} = {}) {
    this.url = url2;
    this.headers = headers;
    this.schema = schema;
  }
  auth(token) {
    this.headers["Authorization"] = `Bearer ${token}`;
    return this;
  }
  from(table) {
    const url2 = `${this.url}/${table}`;
    return new PostgrestQueryBuilder(url2, {headers: this.headers, schema: this.schema});
  }
  rpc(fn, params, {count = null} = {}) {
    const url2 = `${this.url}/rpc/${fn}`;
    return new PostgrestRpcBuilder(url2, {
      headers: this.headers,
      schema: this.schema
    }).rpc(params, {count});
  }
}
var PostgresTypes;
(function(PostgresTypes2) {
  PostgresTypes2["abstime"] = "abstime";
  PostgresTypes2["bool"] = "bool";
  PostgresTypes2["date"] = "date";
  PostgresTypes2["daterange"] = "daterange";
  PostgresTypes2["float4"] = "float4";
  PostgresTypes2["float8"] = "float8";
  PostgresTypes2["int2"] = "int2";
  PostgresTypes2["int4"] = "int4";
  PostgresTypes2["int4range"] = "int4range";
  PostgresTypes2["int8"] = "int8";
  PostgresTypes2["int8range"] = "int8range";
  PostgresTypes2["json"] = "json";
  PostgresTypes2["jsonb"] = "jsonb";
  PostgresTypes2["money"] = "money";
  PostgresTypes2["numeric"] = "numeric";
  PostgresTypes2["oid"] = "oid";
  PostgresTypes2["reltime"] = "reltime";
  PostgresTypes2["time"] = "time";
  PostgresTypes2["timestamp"] = "timestamp";
  PostgresTypes2["timestamptz"] = "timestamptz";
  PostgresTypes2["timetz"] = "timetz";
  PostgresTypes2["tsrange"] = "tsrange";
  PostgresTypes2["tstzrange"] = "tstzrange";
})(PostgresTypes || (PostgresTypes = {}));
const convertChangeData = (columns, records, options = {}) => {
  let result = {};
  let skipTypes = typeof options.skipTypes !== "undefined" ? options.skipTypes : [];
  Object.entries(records).map(([key, value]) => {
    result[key] = convertColumn(key, columns, records, skipTypes);
  });
  return result;
};
const convertColumn = (columnName, columns, records, skipTypes) => {
  let column = columns.find((x) => x.name == columnName);
  if (!column || skipTypes.includes(column.type)) {
    return noop$1(records[columnName]);
  } else {
    return convertCell(column.type, records[columnName]);
  }
};
const convertCell = (type, stringValue) => {
  try {
    if (stringValue === null)
      return null;
    if (type.charAt(0) === "_") {
      let arrayValue = type.slice(1, type.length);
      return toArray(stringValue, arrayValue);
    }
    switch (type) {
      case PostgresTypes.abstime:
        return noop$1(stringValue);
      case PostgresTypes.bool:
        return toBoolean(stringValue);
      case PostgresTypes.date:
        return noop$1(stringValue);
      case PostgresTypes.daterange:
        return toDateRange(stringValue);
      case PostgresTypes.float4:
        return toFloat(stringValue);
      case PostgresTypes.float8:
        return toFloat(stringValue);
      case PostgresTypes.int2:
        return toInt(stringValue);
      case PostgresTypes.int4:
        return toInt(stringValue);
      case PostgresTypes.int4range:
        return toIntRange(stringValue);
      case PostgresTypes.int8:
        return toInt(stringValue);
      case PostgresTypes.int8range:
        return toIntRange(stringValue);
      case PostgresTypes.json:
        return toJson(stringValue);
      case PostgresTypes.jsonb:
        return toJson(stringValue);
      case PostgresTypes.money:
        return toFloat(stringValue);
      case PostgresTypes.numeric:
        return toFloat(stringValue);
      case PostgresTypes.oid:
        return toInt(stringValue);
      case PostgresTypes.reltime:
        return noop$1(stringValue);
      case PostgresTypes.time:
        return noop$1(stringValue);
      case PostgresTypes.timestamp:
        return toTimestampString(stringValue);
      case PostgresTypes.timestamptz:
        return noop$1(stringValue);
      case PostgresTypes.timetz:
        return noop$1(stringValue);
      case PostgresTypes.tsrange:
        return toDateRange(stringValue);
      case PostgresTypes.tstzrange:
        return toDateRange(stringValue);
      default:
        return noop$1(stringValue);
    }
  } catch (error2) {
    console.log(`Could not convert cell of type ${type} and value ${stringValue}`);
    console.log(`This is the error: ${error2}`);
    return stringValue;
  }
};
const noop$1 = (stringValue) => {
  return stringValue;
};
const toBoolean = (stringValue) => {
  switch (stringValue) {
    case "t":
      return true;
    case "f":
      return false;
    default:
      return null;
  }
};
const toDateRange = (stringValue) => {
  let arr = JSON.parse(stringValue);
  return [new Date(arr[0]), new Date(arr[1])];
};
const toFloat = (stringValue) => {
  return parseFloat(stringValue);
};
const toInt = (stringValue) => {
  return parseInt(stringValue);
};
const toIntRange = (stringValue) => {
  let arr = JSON.parse(stringValue);
  return [parseInt(arr[0]), parseInt(arr[1])];
};
const toJson = (stringValue) => {
  return JSON.parse(stringValue);
};
const toArray = (stringValue, type) => {
  let stringEnriched = stringValue.slice(1, stringValue.length - 1);
  let stringArray = stringEnriched.length > 0 ? stringEnriched.split(",") : [];
  let array = stringArray.map((string) => {
    return convertCell(type, string);
  });
  return array;
};
const toTimestampString = (stringValue) => {
  return stringValue.replace(" ", "T");
};
const VSN = "1.0.0";
const DEFAULT_TIMEOUT = 1e4;
const WS_CLOSE_NORMAL = 1e3;
var SOCKET_STATES;
(function(SOCKET_STATES2) {
  SOCKET_STATES2[SOCKET_STATES2["connecting"] = 0] = "connecting";
  SOCKET_STATES2[SOCKET_STATES2["open"] = 1] = "open";
  SOCKET_STATES2[SOCKET_STATES2["closing"] = 2] = "closing";
  SOCKET_STATES2[SOCKET_STATES2["closed"] = 3] = "closed";
})(SOCKET_STATES || (SOCKET_STATES = {}));
var CHANNEL_STATES;
(function(CHANNEL_STATES2) {
  CHANNEL_STATES2["closed"] = "closed";
  CHANNEL_STATES2["errored"] = "errored";
  CHANNEL_STATES2["joined"] = "joined";
  CHANNEL_STATES2["joining"] = "joining";
  CHANNEL_STATES2["leaving"] = "leaving";
})(CHANNEL_STATES || (CHANNEL_STATES = {}));
var CHANNEL_EVENTS;
(function(CHANNEL_EVENTS2) {
  CHANNEL_EVENTS2["close"] = "phx_close";
  CHANNEL_EVENTS2["error"] = "phx_error";
  CHANNEL_EVENTS2["join"] = "phx_join";
  CHANNEL_EVENTS2["reply"] = "phx_reply";
  CHANNEL_EVENTS2["leave"] = "phx_leave";
})(CHANNEL_EVENTS || (CHANNEL_EVENTS = {}));
var TRANSPORTS;
(function(TRANSPORTS2) {
  TRANSPORTS2["websocket"] = "websocket";
})(TRANSPORTS || (TRANSPORTS = {}));
class Timer {
  constructor(callback, timerCalc) {
    this.callback = callback;
    this.timerCalc = timerCalc;
    this.timer = void 0;
    this.tries = 0;
    this.callback = callback;
    this.timerCalc = timerCalc;
  }
  reset() {
    this.tries = 0;
    clearTimeout(this.timer);
  }
  scheduleTimeout() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.tries = this.tries + 1;
      this.callback();
    }, this.timerCalc(this.tries + 1));
  }
}
class Push {
  constructor(channel, event, payload = {}, timeout = DEFAULT_TIMEOUT) {
    this.channel = channel;
    this.event = event;
    this.payload = payload;
    this.timeout = timeout;
    this.sent = false;
    this.timeoutTimer = void 0;
    this.ref = "";
    this.receivedResp = null;
    this.recHooks = [];
    this.refEvent = null;
  }
  resend(timeout) {
    this.timeout = timeout;
    this._cancelRefEvent();
    this.ref = "";
    this.refEvent = null;
    this.receivedResp = null;
    this.sent = false;
    this.send();
  }
  send() {
    if (this._hasReceived("timeout")) {
      return;
    }
    this.startTimeout();
    this.sent = true;
    this.channel.socket.push({
      topic: this.channel.topic,
      event: this.event,
      payload: this.payload,
      ref: this.ref
    });
  }
  receive(status, callback) {
    var _a;
    if (this._hasReceived(status)) {
      callback((_a = this.receivedResp) === null || _a === void 0 ? void 0 : _a.response);
    }
    this.recHooks.push({status, callback});
    return this;
  }
  startTimeout() {
    if (this.timeoutTimer) {
      return;
    }
    this.ref = this.channel.socket.makeRef();
    this.refEvent = this.channel.replyEventName(this.ref);
    this.channel.on(this.refEvent, (payload) => {
      this._cancelRefEvent();
      this._cancelTimeout();
      this.receivedResp = payload;
      this._matchReceive(payload);
    });
    this.timeoutTimer = setTimeout(() => {
      this.trigger("timeout", {});
    }, this.timeout);
  }
  trigger(status, response) {
    if (this.refEvent)
      this.channel.trigger(this.refEvent, {status, response});
  }
  _cancelRefEvent() {
    if (!this.refEvent) {
      return;
    }
    this.channel.off(this.refEvent);
  }
  _cancelTimeout() {
    clearTimeout(this.timeoutTimer);
    this.timeoutTimer = void 0;
  }
  _matchReceive({status, response}) {
    this.recHooks.filter((h) => h.status === status).forEach((h) => h.callback(response));
  }
  _hasReceived(status) {
    return this.receivedResp && this.receivedResp.status === status;
  }
}
class RealtimeSubscription {
  constructor(topic, params = {}, socket) {
    this.topic = topic;
    this.params = params;
    this.socket = socket;
    this.bindings = [];
    this.state = CHANNEL_STATES.closed;
    this.joinedOnce = false;
    this.pushBuffer = [];
    this.timeout = this.socket.timeout;
    this.joinPush = new Push(this, CHANNEL_EVENTS.join, this.params, this.timeout);
    this.rejoinTimer = new Timer(() => this.rejoinUntilConnected(), this.socket.reconnectAfterMs);
    this.joinPush.receive("ok", () => {
      this.state = CHANNEL_STATES.joined;
      this.rejoinTimer.reset();
      this.pushBuffer.forEach((pushEvent) => pushEvent.send());
      this.pushBuffer = [];
    });
    this.onClose(() => {
      this.rejoinTimer.reset();
      this.socket.log("channel", `close ${this.topic} ${this.joinRef()}`);
      this.state = CHANNEL_STATES.closed;
      this.socket.remove(this);
    });
    this.onError((reason) => {
      if (this.isLeaving() || this.isClosed()) {
        return;
      }
      this.socket.log("channel", `error ${this.topic}`, reason);
      this.state = CHANNEL_STATES.errored;
      this.rejoinTimer.scheduleTimeout();
    });
    this.joinPush.receive("timeout", () => {
      if (!this.isJoining()) {
        return;
      }
      this.socket.log("channel", `timeout ${this.topic}`, this.joinPush.timeout);
      this.state = CHANNEL_STATES.errored;
      this.rejoinTimer.scheduleTimeout();
    });
    this.on(CHANNEL_EVENTS.reply, (payload, ref) => {
      this.trigger(this.replyEventName(ref), payload);
    });
  }
  rejoinUntilConnected() {
    this.rejoinTimer.scheduleTimeout();
    if (this.socket.isConnected()) {
      this.rejoin();
    }
  }
  subscribe(timeout = this.timeout) {
    if (this.joinedOnce) {
      throw `tried to subscribe multiple times. 'subscribe' can only be called a single time per channel instance`;
    } else {
      this.joinedOnce = true;
      this.rejoin(timeout);
      return this.joinPush;
    }
  }
  onClose(callback) {
    this.on(CHANNEL_EVENTS.close, callback);
  }
  onError(callback) {
    this.on(CHANNEL_EVENTS.error, (reason) => callback(reason));
  }
  on(event, callback) {
    this.bindings.push({event, callback});
  }
  off(event) {
    this.bindings = this.bindings.filter((bind2) => bind2.event !== event);
  }
  canPush() {
    return this.socket.isConnected() && this.isJoined();
  }
  push(event, payload, timeout = this.timeout) {
    if (!this.joinedOnce) {
      throw `tried to push '${event}' to '${this.topic}' before joining. Use channel.subscribe() before pushing events`;
    }
    let pushEvent = new Push(this, event, payload, timeout);
    if (this.canPush()) {
      pushEvent.send();
    } else {
      pushEvent.startTimeout();
      this.pushBuffer.push(pushEvent);
    }
    return pushEvent;
  }
  unsubscribe(timeout = this.timeout) {
    this.state = CHANNEL_STATES.leaving;
    let onClose = () => {
      this.socket.log("channel", `leave ${this.topic}`);
      this.trigger(CHANNEL_EVENTS.close, "leave", this.joinRef());
    };
    let leavePush = new Push(this, CHANNEL_EVENTS.leave, {}, timeout);
    leavePush.receive("ok", () => onClose()).receive("timeout", () => onClose());
    leavePush.send();
    if (!this.canPush()) {
      leavePush.trigger("ok", {});
    }
    return leavePush;
  }
  onMessage(event, payload, ref) {
    return payload;
  }
  isMember(topic) {
    return this.topic === topic;
  }
  joinRef() {
    return this.joinPush.ref;
  }
  sendJoin(timeout) {
    this.state = CHANNEL_STATES.joining;
    this.joinPush.resend(timeout);
  }
  rejoin(timeout = this.timeout) {
    if (this.isLeaving()) {
      return;
    }
    this.sendJoin(timeout);
  }
  trigger(event, payload, ref) {
    let {close, error: error2, leave, join} = CHANNEL_EVENTS;
    let events = [close, error2, leave, join];
    if (ref && events.indexOf(event) >= 0 && ref !== this.joinRef()) {
      return;
    }
    let handledPayload = this.onMessage(event, payload, ref);
    if (payload && !handledPayload) {
      throw "channel onMessage callbacks must return the payload, modified or unmodified";
    }
    this.bindings.filter((bind2) => {
      if (bind2.event === "*") {
        return event === (payload === null || payload === void 0 ? void 0 : payload.type);
      } else {
        return bind2.event === event;
      }
    }).map((bind2) => bind2.callback(handledPayload, ref));
  }
  replyEventName(ref) {
    return `chan_reply_${ref}`;
  }
  isClosed() {
    return this.state === CHANNEL_STATES.closed;
  }
  isErrored() {
    return this.state === CHANNEL_STATES.errored;
  }
  isJoined() {
    return this.state === CHANNEL_STATES.joined;
  }
  isJoining() {
    return this.state === CHANNEL_STATES.joining;
  }
  isLeaving() {
    return this.state === CHANNEL_STATES.leaving;
  }
}
var naiveFallback = function() {
  if (typeof self === "object" && self)
    return self;
  if (typeof window === "object" && window)
    return window;
  throw new Error("Unable to resolve global `this`");
};
var global$1 = function() {
  if (this)
    return this;
  if (typeof globalThis === "object" && globalThis)
    return globalThis;
  try {
    Object.defineProperty(Object.prototype, "__global__", {
      get: function() {
        return this;
      },
      configurable: true
    });
  } catch (error2) {
    return naiveFallback();
  }
  try {
    if (!__global__)
      return naiveFallback();
    return __global__;
  } finally {
    delete Object.prototype.__global__;
  }
}();
const _from = "websocket@^1.0.34";
const _id = "websocket@1.0.34";
const _inBundle = false;
const _integrity = "sha512-PRDso2sGwF6kM75QykIesBijKSVceR6jL2G8NGYyq2XrItNC2P5/qL5XeR056GhA+Ly7JMFvJb9I312mJfmqnQ==";
const _location = "/websocket";
const _phantomChildren = {};
const _requested = {
  type: "range",
  registry: true,
  raw: "websocket@^1.0.34",
  name: "websocket",
  escapedName: "websocket",
  rawSpec: "^1.0.34",
  saveSpec: null,
  fetchSpec: "^1.0.34"
};
const _requiredBy = [
  "/@supabase/realtime-js"
];
const _resolved = "https://registry.npmjs.org/websocket/-/websocket-1.0.34.tgz";
const _shasum = "2bdc2602c08bf2c82253b730655c0ef7dcab3111";
const _spec = "websocket@^1.0.34";
const _where = "C:\\Users\\eloua\\Documents\\Projet_Transverse\\Test\\Les-Peres-Castors-\\node_modules\\@supabase\\realtime-js";
const author = {
  name: "Brian McKelvey",
  email: "theturtle32@gmail.com",
  url: "https://github.com/theturtle32"
};
const browser$1 = "lib/browser.js";
const bugs = {
  url: "https://github.com/theturtle32/WebSocket-Node/issues"
};
const bundleDependencies = false;
const config = {
  verbose: false
};
const contributors = [
  {
    name: "I\xF1aki Baz Castillo",
    email: "ibc@aliax.net",
    url: "http://dev.sipdoc.net"
  }
];
const dependencies = {
  bufferutil: "^4.0.1",
  debug: "^2.2.0",
  "es5-ext": "^0.10.50",
  "typedarray-to-buffer": "^3.1.5",
  "utf-8-validate": "^5.0.2",
  yaeti: "^0.0.6"
};
const deprecated = false;
const description = "Websocket Client & Server Library implementing the WebSocket protocol as specified in RFC 6455.";
const devDependencies = {
  "buffer-equal": "^1.0.0",
  gulp: "^4.0.2",
  "gulp-jshint": "^2.0.4",
  jshint: "^2.0.0",
  "jshint-stylish": "^2.2.1",
  tape: "^4.9.1"
};
const directories = {
  lib: "./lib"
};
const engines = {
  node: ">=4.0.0"
};
const homepage = "https://github.com/theturtle32/WebSocket-Node";
const keywords = [
  "websocket",
  "websockets",
  "socket",
  "networking",
  "comet",
  "push",
  "RFC-6455",
  "realtime",
  "server",
  "client"
];
const license = "Apache-2.0";
const main = "index";
const name = "websocket";
const repository = {
  type: "git",
  url: "git+https://github.com/theturtle32/WebSocket-Node.git"
};
const scripts = {
  gulp: "gulp",
  test: "tape test/unit/*.js"
};
const version$1 = "1.0.34";
var require$$0 = {
  _from,
  _id,
  _inBundle,
  _integrity,
  _location,
  _phantomChildren,
  _requested,
  _requiredBy,
  _resolved,
  _shasum,
  _spec,
  _where,
  author,
  browser: browser$1,
  bugs,
  bundleDependencies,
  config,
  contributors,
  dependencies,
  deprecated,
  description,
  devDependencies,
  directories,
  engines,
  homepage,
  keywords,
  license,
  main,
  name,
  repository,
  scripts,
  version: version$1
};
var version = require$$0.version;
var _globalThis;
if (typeof globalThis === "object") {
  _globalThis = globalThis;
} else {
  try {
    _globalThis = global$1;
  } catch (error2) {
  } finally {
    if (!_globalThis && typeof window !== "undefined") {
      _globalThis = window;
    }
    if (!_globalThis) {
      throw new Error("Could not determine global this");
    }
  }
}
var NativeWebSocket = _globalThis.WebSocket || _globalThis.MozWebSocket;
function W3CWebSocket(uri, protocols) {
  var native_instance;
  if (protocols) {
    native_instance = new NativeWebSocket(uri, protocols);
  } else {
    native_instance = new NativeWebSocket(uri);
  }
  return native_instance;
}
if (NativeWebSocket) {
  ["CONNECTING", "OPEN", "CLOSING", "CLOSED"].forEach(function(prop) {
    Object.defineProperty(W3CWebSocket, prop, {
      get: function() {
        return NativeWebSocket[prop];
      }
    });
  });
}
var browser = {
  w3cwebsocket: NativeWebSocket ? W3CWebSocket : null,
  version
};
var __awaiter$4 = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
const noop = () => {
};
class RealtimeClient {
  constructor(endPoint, options) {
    this.channels = [];
    this.endPoint = "";
    this.headers = {};
    this.params = {};
    this.timeout = DEFAULT_TIMEOUT;
    this.transport = browser.w3cwebsocket;
    this.heartbeatIntervalMs = 3e4;
    this.longpollerTimeout = 2e4;
    this.heartbeatTimer = void 0;
    this.pendingHeartbeatRef = null;
    this.ref = 0;
    this.logger = noop;
    this.conn = null;
    this.sendBuffer = [];
    this.stateChangeCallbacks = {
      open: [],
      close: [],
      error: [],
      message: []
    };
    this.endPoint = `${endPoint}/${TRANSPORTS.websocket}`;
    if (options === null || options === void 0 ? void 0 : options.params)
      this.params = options.params;
    if (options === null || options === void 0 ? void 0 : options.headers)
      this.headers = options.headers;
    if (options === null || options === void 0 ? void 0 : options.timeout)
      this.timeout = options.timeout;
    if (options === null || options === void 0 ? void 0 : options.logger)
      this.logger = options.logger;
    if (options === null || options === void 0 ? void 0 : options.transport)
      this.transport = options.transport;
    if (options === null || options === void 0 ? void 0 : options.heartbeatIntervalMs)
      this.heartbeatIntervalMs = options.heartbeatIntervalMs;
    if (options === null || options === void 0 ? void 0 : options.longpollerTimeout)
      this.longpollerTimeout = options.longpollerTimeout;
    this.reconnectAfterMs = (options === null || options === void 0 ? void 0 : options.reconnectAfterMs) ? options.reconnectAfterMs : (tries) => {
      return [1e3, 2e3, 5e3, 1e4][tries - 1] || 1e4;
    };
    this.encode = (options === null || options === void 0 ? void 0 : options.encode) ? options.encode : (payload, callback) => {
      return callback(JSON.stringify(payload));
    };
    this.decode = (options === null || options === void 0 ? void 0 : options.decode) ? options.decode : (payload, callback) => {
      return callback(JSON.parse(payload));
    };
    this.reconnectTimer = new Timer(() => __awaiter$4(this, void 0, void 0, function* () {
      yield this.disconnect();
      this.connect();
    }), this.reconnectAfterMs);
  }
  connect() {
    if (this.conn) {
      return;
    }
    this.conn = new this.transport(this.endPointURL(), [], null, this.headers);
    if (this.conn) {
      this.conn.onopen = () => this._onConnOpen();
      this.conn.onerror = (error2) => this._onConnError(error2);
      this.conn.onmessage = (event) => this.onConnMessage(event);
      this.conn.onclose = (event) => this._onConnClose(event);
    }
  }
  disconnect(code, reason) {
    return new Promise((resolve2, _reject) => {
      try {
        if (this.conn) {
          this.conn.onclose = function() {
          };
          if (code) {
            this.conn.close(code, reason || "");
          } else {
            this.conn.close();
          }
          this.conn = null;
        }
        resolve2({error: null, data: true});
      } catch (error2) {
        resolve2({error: error2, data: false});
      }
    });
  }
  log(kind, msg, data) {
    this.logger(kind, msg, data);
  }
  onOpen(callback) {
    this.stateChangeCallbacks.open.push(callback);
  }
  onClose(callback) {
    this.stateChangeCallbacks.close.push(callback);
  }
  onError(callback) {
    this.stateChangeCallbacks.error.push(callback);
  }
  onMessage(callback) {
    this.stateChangeCallbacks.message.push(callback);
  }
  connectionState() {
    switch (this.conn && this.conn.readyState) {
      case SOCKET_STATES.connecting:
        return "connecting";
      case SOCKET_STATES.open:
        return "open";
      case SOCKET_STATES.closing:
        return "closing";
      default:
        return "closed";
    }
  }
  isConnected() {
    return this.connectionState() === "open";
  }
  remove(channel) {
    this.channels = this.channels.filter((c) => c.joinRef() !== channel.joinRef());
  }
  channel(topic, chanParams = {}) {
    let chan = new RealtimeSubscription(topic, chanParams, this);
    this.channels.push(chan);
    return chan;
  }
  push(data) {
    let {topic, event, payload, ref} = data;
    let callback = () => {
      this.encode(data, (result) => {
        var _a;
        (_a = this.conn) === null || _a === void 0 ? void 0 : _a.send(result);
      });
    };
    this.log("push", `${topic} ${event} (${ref})`, payload);
    if (this.isConnected()) {
      callback();
    } else {
      this.sendBuffer.push(callback);
    }
  }
  onConnMessage(rawMessage) {
    this.decode(rawMessage.data, (msg) => {
      let {topic, event, payload, ref} = msg;
      if (ref && ref === this.pendingHeartbeatRef) {
        this.pendingHeartbeatRef = null;
      }
      this.log("receive", `${payload.status || ""} ${topic} ${event} ${ref && "(" + ref + ")" || ""}`, payload);
      this.channels.filter((channel) => channel.isMember(topic)).forEach((channel) => channel.trigger(event, payload, ref));
      this.stateChangeCallbacks.message.forEach((callback) => callback(msg));
    });
  }
  endPointURL() {
    return this._appendParams(this.endPoint, Object.assign({}, this.params, {vsn: VSN}));
  }
  makeRef() {
    let newRef = this.ref + 1;
    if (newRef === this.ref) {
      this.ref = 0;
    } else {
      this.ref = newRef;
    }
    return this.ref.toString();
  }
  _onConnOpen() {
    this.log("transport", `connected to ${this.endPointURL()}`);
    this._flushSendBuffer();
    this.reconnectTimer.reset();
    clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = setInterval(() => this._sendHeartbeat(), this.heartbeatIntervalMs);
    this.stateChangeCallbacks.open.forEach((callback) => callback());
  }
  _onConnClose(event) {
    this.log("transport", "close", event);
    this._triggerChanError();
    clearInterval(this.heartbeatTimer);
    this.reconnectTimer.scheduleTimeout();
    this.stateChangeCallbacks.close.forEach((callback) => callback(event));
  }
  _onConnError(error2) {
    this.log("transport", error2.message);
    this._triggerChanError();
    this.stateChangeCallbacks.error.forEach((callback) => callback(error2));
  }
  _triggerChanError() {
    this.channels.forEach((channel) => channel.trigger(CHANNEL_EVENTS.error));
  }
  _appendParams(url2, params) {
    if (Object.keys(params).length === 0) {
      return url2;
    }
    const prefix = url2.match(/\?/) ? "&" : "?";
    const query = new URLSearchParams(params);
    return `${url2}${prefix}${query}`;
  }
  _flushSendBuffer() {
    if (this.isConnected() && this.sendBuffer.length > 0) {
      this.sendBuffer.forEach((callback) => callback());
      this.sendBuffer = [];
    }
  }
  _sendHeartbeat() {
    var _a;
    if (!this.isConnected()) {
      return;
    }
    if (this.pendingHeartbeatRef) {
      this.pendingHeartbeatRef = null;
      this.log("transport", "heartbeat timeout. Attempting to re-establish connection");
      (_a = this.conn) === null || _a === void 0 ? void 0 : _a.close(WS_CLOSE_NORMAL, "hearbeat timeout");
      return;
    }
    this.pendingHeartbeatRef = this.makeRef();
    this.push({
      topic: "phoenix",
      event: "heartbeat",
      payload: {},
      ref: this.pendingHeartbeatRef
    });
  }
}
class SupabaseRealtimeClient {
  constructor(socket, schema, tableName) {
    const topic = tableName === "*" ? `realtime:${schema}` : `realtime:${schema}:${tableName}`;
    this.subscription = socket.channel(topic);
  }
  getPayloadRecords(payload) {
    const records = {
      new: {},
      old: {}
    };
    if (payload.type === "INSERT" || payload.type === "UPDATE") {
      records.new = convertChangeData(payload.columns, payload.record);
    }
    if (payload.type === "UPDATE" || payload.type === "DELETE") {
      records.old = convertChangeData(payload.columns, payload.old_record);
    }
    return records;
  }
  on(event, callback) {
    this.subscription.on(event, (payload) => {
      let enrichedPayload = {
        schema: payload.schema,
        table: payload.table,
        commit_timestamp: payload.commit_timestamp,
        eventType: payload.type,
        new: {},
        old: {}
      };
      enrichedPayload = Object.assign(Object.assign({}, enrichedPayload), this.getPayloadRecords(payload));
      callback(enrichedPayload);
    });
    return this;
  }
  subscribe(callback = () => {
  }) {
    this.subscription.onError((e) => callback("SUBSCRIPTION_ERROR", e));
    this.subscription.onClose(() => callback("CLOSED"));
    this.subscription.subscribe().receive("ok", () => callback("SUBSCRIBED")).receive("error", (e) => callback("SUBSCRIPTION_ERROR", e)).receive("timeout", () => callback("RETRYING_AFTER_TIMEOUT"));
    return this.subscription;
  }
}
class SupabaseQueryBuilder extends PostgrestQueryBuilder {
  constructor(url2, {headers = {}, schema, realtime, table}) {
    super(url2, {headers, schema});
    this._subscription = new SupabaseRealtimeClient(realtime, schema, table);
    this._realtime = realtime;
  }
  on(event, callback) {
    if (!this._realtime.isConnected()) {
      this._realtime.connect();
    }
    return this._subscription.on(event, callback);
  }
}
var __awaiter$3 = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
const _getErrorMessage = (err) => err.msg || err.message || err.error_description || err.error || JSON.stringify(err);
const handleError = (error2, reject) => {
  if (typeof error2.json !== "function") {
    return reject(error2);
  }
  error2.json().then((err) => {
    return reject({
      message: _getErrorMessage(err),
      status: (error2 === null || error2 === void 0 ? void 0 : error2.status) || 500
    });
  });
};
const _getRequestParams = (method, options, parameters, body) => {
  const params = {method, headers: (options === null || options === void 0 ? void 0 : options.headers) || {}};
  if (method === "GET") {
    return params;
  }
  params.headers = Object.assign({"Content-Type": "application/json"}, options === null || options === void 0 ? void 0 : options.headers);
  params.body = JSON.stringify(body);
  return Object.assign(Object.assign({}, params), parameters);
};
function _handleRequest(method, url2, options, parameters, body) {
  return __awaiter$3(this, void 0, void 0, function* () {
    return new Promise((resolve2, reject) => {
      fetch$1(url2, _getRequestParams(method, options, parameters, body)).then((result) => {
        if (!result.ok)
          throw result;
        if (options === null || options === void 0 ? void 0 : options.noResolveJson)
          return resolve2(result);
        return result.json();
      }).then((data) => resolve2(data)).catch((error2) => handleError(error2, reject));
    });
  });
}
function get(url2, options, parameters) {
  return __awaiter$3(this, void 0, void 0, function* () {
    return _handleRequest("GET", url2, options, parameters);
  });
}
function post(url2, body, options, parameters) {
  return __awaiter$3(this, void 0, void 0, function* () {
    return _handleRequest("POST", url2, options, parameters, body);
  });
}
function remove(url2, body, options, parameters) {
  return __awaiter$3(this, void 0, void 0, function* () {
    return _handleRequest("DELETE", url2, options, parameters, body);
  });
}
var __awaiter$2 = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
class StorageBucketApi {
  constructor(url2, headers = {}) {
    this.url = url2;
    this.headers = headers;
  }
  listBuckets() {
    return __awaiter$2(this, void 0, void 0, function* () {
      try {
        const data = yield get(`${this.url}/bucket`, {headers: this.headers});
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  getBucket(id) {
    return __awaiter$2(this, void 0, void 0, function* () {
      try {
        const data = yield get(`${this.url}/bucket/${id}`, {headers: this.headers});
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  createBucket(id) {
    return __awaiter$2(this, void 0, void 0, function* () {
      try {
        const data = yield post(`${this.url}/bucket`, {id, name: id}, {headers: this.headers});
        return {data: data.name, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  emptyBucket(id) {
    return __awaiter$2(this, void 0, void 0, function* () {
      try {
        const data = yield post(`${this.url}/bucket/${id}/empty`, {}, {headers: this.headers});
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  deleteBucket(id) {
    return __awaiter$2(this, void 0, void 0, function* () {
      try {
        const data = yield remove(`${this.url}/bucket/${id}`, {}, {headers: this.headers});
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
}
const isBrowser = () => typeof window !== "undefined";
var __awaiter$1 = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
const DEFAULT_SEARCH_OPTIONS = {
  limit: 100,
  offset: 0,
  sortBy: {
    column: "name",
    order: "asc"
  }
};
const DEFAULT_FILE_OPTIONS = {
  cacheControl: "3600"
};
class StorageFileApi {
  constructor(url2, headers = {}, bucketId) {
    this.url = url2;
    this.headers = headers;
    this.bucketId = bucketId;
  }
  upload(path, file, fileOptions) {
    return __awaiter$1(this, void 0, void 0, function* () {
      try {
        if (!isBrowser())
          throw new Error("No browser detected.");
        const formData = new FormData();
        const options = Object.assign(Object.assign({}, DEFAULT_FILE_OPTIONS), fileOptions);
        formData.append("cacheControl", options.cacheControl);
        formData.append("", file, file.name);
        const _path = this._getFinalPath(path);
        const res = yield fetch(`${this.url}/object/${_path}`, {
          method: "POST",
          body: formData,
          headers: Object.assign({}, this.headers)
        });
        if (res.ok) {
          return {data: {Key: _path}, error: null};
        } else {
          const error2 = yield res.json();
          return {data: null, error: error2};
        }
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  update(path, file, fileOptions) {
    return __awaiter$1(this, void 0, void 0, function* () {
      try {
        if (!isBrowser())
          throw new Error("No browser detected.");
        const formData = new FormData();
        const options = Object.assign(Object.assign({}, DEFAULT_FILE_OPTIONS), fileOptions);
        formData.append("cacheControl", options.cacheControl);
        formData.append("", file, file.name);
        const _path = this._getFinalPath(path);
        const res = yield fetch(`${this.url}/object/${_path}`, {
          method: "PUT",
          body: formData,
          headers: Object.assign({}, this.headers)
        });
        if (res.ok) {
          return {data: {Key: _path}, error: null};
        } else {
          const error2 = yield res.json();
          return {data: null, error: error2};
        }
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  move(fromPath, toPath) {
    return __awaiter$1(this, void 0, void 0, function* () {
      try {
        const data = yield post(`${this.url}/object/move`, {bucketId: this.bucketId, sourceKey: fromPath, destinationKey: toPath}, {headers: this.headers});
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  createSignedUrl(path, expiresIn) {
    return __awaiter$1(this, void 0, void 0, function* () {
      try {
        const _path = this._getFinalPath(path);
        let data = yield post(`${this.url}/object/sign/${_path}`, {expiresIn}, {headers: this.headers});
        const signedURL = `${this.url}${data.signedURL}`;
        data = {signedURL};
        return {data, error: null, signedURL};
      } catch (error2) {
        return {data: null, error: error2, signedURL: null};
      }
    });
  }
  download(path) {
    return __awaiter$1(this, void 0, void 0, function* () {
      try {
        const _path = this._getFinalPath(path);
        const res = yield get(`${this.url}/object/${_path}`, {
          headers: this.headers,
          noResolveJson: true
        });
        const data = yield res.blob();
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  remove(paths) {
    return __awaiter$1(this, void 0, void 0, function* () {
      try {
        const data = yield remove(`${this.url}/object/${this.bucketId}`, {prefixes: paths}, {headers: this.headers});
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  list(path, options, parameters) {
    return __awaiter$1(this, void 0, void 0, function* () {
      try {
        const body = Object.assign(Object.assign(Object.assign({}, DEFAULT_SEARCH_OPTIONS), options), {prefix: path || ""});
        const data = yield post(`${this.url}/object/list/${this.bucketId}`, body, {headers: this.headers}, parameters);
        return {data, error: null};
      } catch (error2) {
        return {data: null, error: error2};
      }
    });
  }
  _getFinalPath(path) {
    return `${this.bucketId}/${path}`;
  }
}
class SupabaseStorageClient extends StorageBucketApi {
  constructor(url2, headers = {}) {
    super(url2, headers);
  }
  from(id) {
    return new StorageFileApi(this.url, this.headers, id);
  }
}
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve2) {
      resolve2(value);
    });
  }
  return new (P || (P = Promise))(function(resolve2, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
const DEFAULT_OPTIONS = {
  schema: "public",
  autoRefreshToken: true,
  persistSession: true,
  detectSessionInUrl: true,
  localStorage: globalThis.localStorage,
  headers: DEFAULT_HEADERS$1
};
class SupabaseClient {
  constructor(supabaseUrl, supabaseKey, options) {
    this.supabaseUrl = supabaseUrl;
    this.supabaseKey = supabaseKey;
    if (!supabaseUrl)
      throw new Error("supabaseUrl is required.");
    if (!supabaseKey)
      throw new Error("supabaseKey is required.");
    const settings = Object.assign(Object.assign({}, DEFAULT_OPTIONS), options);
    this.restUrl = `${supabaseUrl}/rest/v1`;
    this.realtimeUrl = `${supabaseUrl}/realtime/v1`.replace("http", "ws");
    this.authUrl = `${supabaseUrl}/auth/v1`;
    this.storageUrl = `${supabaseUrl}/storage/v1`;
    this.schema = settings.schema;
    this.auth = this._initSupabaseAuthClient(settings);
    this.realtime = this._initRealtimeClient();
  }
  get storage() {
    return new SupabaseStorageClient(this.storageUrl, this._getAuthHeaders());
  }
  from(table) {
    const url2 = `${this.restUrl}/${table}`;
    return new SupabaseQueryBuilder(url2, {
      headers: this._getAuthHeaders(),
      schema: this.schema,
      realtime: this.realtime,
      table
    });
  }
  rpc(fn, params) {
    const rest = this._initPostgRESTClient();
    return rest.rpc(fn, params);
  }
  removeSubscription(subscription) {
    return new Promise((resolve2) => __awaiter(this, void 0, void 0, function* () {
      try {
        yield this._closeSubscription(subscription);
        const openSubscriptions = this.getSubscriptions().length;
        if (!openSubscriptions) {
          const {error: error2} = yield this.realtime.disconnect();
          if (error2)
            return resolve2({error: error2});
        }
        return resolve2({error: null, data: {openSubscriptions}});
      } catch (error2) {
        return resolve2({error: error2});
      }
    }));
  }
  _closeSubscription(subscription) {
    return __awaiter(this, void 0, void 0, function* () {
      if (!subscription.isClosed()) {
        yield this._closeChannel(subscription);
      }
    });
  }
  getSubscriptions() {
    return this.realtime.channels;
  }
  _initSupabaseAuthClient({autoRefreshToken, persistSession, detectSessionInUrl, localStorage}) {
    return new SupabaseAuthClient({
      url: this.authUrl,
      headers: {
        Authorization: `Bearer ${this.supabaseKey}`,
        apikey: `${this.supabaseKey}`
      },
      autoRefreshToken,
      persistSession,
      detectSessionInUrl,
      localStorage
    });
  }
  _initRealtimeClient() {
    return new RealtimeClient(this.realtimeUrl, {
      params: {apikey: this.supabaseKey}
    });
  }
  _initPostgRESTClient() {
    return new PostgrestClient(this.restUrl, {
      headers: this._getAuthHeaders(),
      schema: this.schema
    });
  }
  _getAuthHeaders() {
    var _a, _b;
    const headers = {};
    const authBearer = (_b = (_a = this.auth.session()) === null || _a === void 0 ? void 0 : _a.access_token) !== null && _b !== void 0 ? _b : this.supabaseKey;
    headers["apikey"] = this.supabaseKey;
    headers["Authorization"] = `Bearer ${authBearer}`;
    return headers;
  }
  _closeChannel(subscription) {
    return new Promise((resolve2, reject) => {
      subscription.unsubscribe().receive("ok", () => {
        this.realtime.remove(subscription);
        return resolve2(true);
      }).receive("error", (e) => reject(e));
    });
  }
}
const createClient = (supabaseUrl, supabaseKey, options) => {
  return new SupabaseClient(supabaseUrl, supabaseKey, options);
};
const supabase = createClient("https://xsyuqgolfcibacpclpfg.supabase.co", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlhdCI6MTYyMTg1MzA1NywiZXhwIjoxOTM3NDI5MDU3fQ.-1JBurDqcri9zVvPmZ0lx31o0Dry2nqGsgOXvH_AHGE");
const Maths = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let matieres = [];
  let quizzs = [];
  onMount(() => {
    getquizzmatieres();
    getquizzs();
  });
  async function getquizzmatieres() {
    await supabase.from("quizzs").select("mati\xE8res (*)").then((res) => {
      matieres = res.data;
    });
    console.log(matieres);
  }
  async function getquizzs() {
    await supabase.from("quizzs").select().then((res) => {
      quizzs = res.data;
    });
    console.log(quizzs);
  }
  return `<head><title>LPC Quizz Maths</title></head>

${validate_component(Header, "Header").$$render($$result, {}, {}, {})}
<div class="${"flex flex-col text-center w-full mb-5"}"><h3 class="${"text-xl text-base font-semibold tracking-wide no-underline mb-5"}">Les quizzs de maths
	</h3>
	<div class="${"flex flex-wrap -m-4"}">${each(quizzs, (q) => `${validate_component(Quizz$1, "Quizz").$$render($$result, {
    title_quizz: q.nom,
    description: q.description
  }, {}, {})}`)}</div></div>`;
});
var maths = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Maths
});
const Niveau = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let {src: src2} = $$props;
  let {id} = $$props;
  let {href} = $$props;
  if ($$props.src === void 0 && $$bindings.src && src2 !== void 0)
    $$bindings.src(src2);
  if ($$props.id === void 0 && $$bindings.id && id !== void 0)
    $$bindings.id(id);
  if ($$props.href === void 0 && $$bindings.href && href !== void 0)
    $$bindings.href(href);
  return `<div${add_attribute("id", id, 0)} class="${"lg:w-1/5 sm:w-1/2 p-4"}"><div class="${"flex relative flex-col"}"><a${add_attribute("href", href, 0)} class="${"relative w-full"}"><img alt="${"gallery"}" class="${"rounded-md relative inset-0 w-full h-full object-cover object-center"}"${add_attribute("src", src2, 0)}></a></div></div>`;
});
const Formation = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let {src: src2} = $$props;
  let {id} = $$props;
  let {href} = $$props;
  if ($$props.src === void 0 && $$bindings.src && src2 !== void 0)
    $$bindings.src(src2);
  if ($$props.id === void 0 && $$bindings.id && id !== void 0)
    $$bindings.id(id);
  if ($$props.href === void 0 && $$bindings.href && href !== void 0)
    $$bindings.href(href);
  return `<div${add_attribute("id", id, 0)} class="${"lg:w-1/5 sm:w-1/2 p-4"}"><div class="${"flex relative flex-col"}"><a${add_attribute("href", href, 0)} class="${"relative w-full"}"><img alt="${"gallery"}" class="${"rounded-md relative inset-0 w-full h-full object-cover object-center"}"${add_attribute("src", src2, 0)}></a></div></div>`;
});
const Quizz = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<head><title>LPC Quizz</title></head>

${validate_component(Header, "Header").$$render($$result, {}, {}, {})}
<section class="${"text-gray-600 body-font"}"><div class="${"container px-5 pt-20 pb-10 mx-auto"}"><div class="${"flex flex-col text-center w-full mb-10"}"><h1 class="${"uppercase sm:text-3xl text-2xl font-medium title-font mb-4 text-gray-900"}">Quizzs en pagailles !
			</h1>
			<p class="${"lg:w-2/3 mx-auto leading-relaxed text-base"}">Selectionnez un quizz pour avoir acc\xE8s \xE0 son contenu. Regardez, t\xE9l\xE9chargez, likez !
			</p></div>
		<div class="${"flex justify-center elative mb-10"}"><input class="${"w-1/4 border-solid border-2 ring-offset-0 border-gray-500 placeholder-gray-500 rounded-md focus:placeholder-gray-500"}" placeholder="${"Rechercher un quizz"}"></div>
		<div class="${"flex flex-col text-center w-full mb-5"}"><h3 class="${"text-xl text-base font-semibold tracking-wide no-underline mb-5"}">Veuillez saisir un niveau d&#39;\xE9tude
			</h3>
			<div class="${"flex flex-wrap -m-4"}">${validate_component(Niveau, "Niveau").$$render($$result, {
    href: "#L1",
    id: "l1",
    src: "https://1fichier.com/?fd04rvgyd610hwzwlvnm"
  }, {}, {})}
				${validate_component(Niveau, "Niveau").$$render($$result, {
    href: "#L2",
    id: "l2",
    src: "https://1fichier.com/?fewgwxa6nb9v8rz10o8r"
  }, {}, {})}
				${validate_component(Niveau, "Niveau").$$render($$result, {
    href: "#L3",
    id: "l3",
    src: "https://1fichier.com/?okkolyzfsi8a1slavxhh"
  }, {}, {})}
				${validate_component(Niveau, "Niveau").$$render($$result, {
    href: "#M1",
    id: "m1",
    src: "https://1fichier.com/?ya6g1b6s791eyk4z9ow4"
  }, {}, {})}
				${validate_component(Niveau, "Niveau").$$render($$result, {
    href: "#M2",
    id: "m2",
    src: "https://1fichier.com/?yl87lxbnsaal9oe2wnjf"
  }, {}, {})}</div></div></div>
	${`<div class="${"container px-5 pt-5 pb-10 mx-auto"}"><div class="${"flex flex-col text-center w-full mb-20"}"><h3 class="${"text-xl text-base font-semibold tracking-wide no-underline mb-5"}">Veuillez saisir un module
				</h3>
				<div class="${"flex flex-wrap -m-4"}">${validate_component(Formation, "Formation").$$render($$result, {
    id: "biologie",
    src: "https://1fichier.com/?uq3cqu6js481g2rzxbbn",
    href: "biologie"
  }, {}, {})}
					${validate_component(Formation, "Formation").$$render($$result, {
    id: "general",
    src: "https://1fichier.com/?742iwwj2b4lkkplqk4k3",
    href: "formationgen"
  }, {}, {})}
					${validate_component(Formation, "Formation").$$render($$result, {
    id: "informatique",
    src: "https://1fichier.com/?z7uqpa516rzhyuvee8gw",
    href: "informatique"
  }, {}, {})}
					${validate_component(Formation, "Formation").$$render($$result, {
    id: "maths",
    src: "https://1fichier.com/?qppjwfejucgylpe4x5xm",
    href: "maths"
  }, {}, {})}
					${validate_component(Formation, "Formation").$$render($$result, {
    id: "physique",
    src: "https://1fichier.com/?p2zfs6psb1rwhjdygqzl",
    href: "physique"
  }, {}, {})}</div></div></div>`}</section>`;
});
var quizz = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: Quizz
});
var app = ":root {\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell,\n		'Open Sans', 'Helvetica Neue', sans-serif;\n}\n";
var $layout_svelte = "/*! tailwindcss v2.1.0 | MIT License | https://tailwindcss.com */\n\n/*! modern-normalize v1.0.0 | MIT License | https://github.com/sindresorhus/modern-normalize */\n\n/*\nDocument\n========\n*/\n\n/**\nUse a better box model (opinionated).\n*/\n\n*,\n*::before,\n*::after {\n  box-sizing: border-box;\n}\n\n/**\nUse a more readable tab size (opinionated).\n*/\n\n:root {\n  -moz-tab-size: 4;\n  -o-tab-size: 4;\n     tab-size: 4;\n}\n\n/**\n1. Correct the line height in all browsers.\n2. Prevent adjustments of font size after orientation changes in iOS.\n*/\n\nhtml {\n  line-height: 1.15; /* 1 */\n  -webkit-text-size-adjust: 100%; /* 2 */\n}\n\n/*\nSections\n========\n*/\n\n/**\nRemove the margin in all browsers.\n*/\n\nbody {\n  margin: 0;\n}\n\n/**\nImprove consistency of default fonts in all browsers. (https://github.com/sindresorhus/modern-normalize/issues/3)\n*/\n\nbody {\n  font-family:\n		system-ui,\n		-apple-system, /* Firefox supports this but not yet `system-ui` */\n		'Segoe UI',\n		Roboto,\n		Helvetica,\n		Arial,\n		sans-serif,\n		'Apple Color Emoji',\n		'Segoe UI Emoji';\n}\n\n/*\nGrouping content\n================\n*/\n\n/**\n1. Add the correct height in Firefox.\n2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)\n*/\n\nhr {\n  height: 0; /* 1 */\n  color: inherit; /* 2 */\n}\n\n/*\nText-level semantics\n====================\n*/\n\n/**\nAdd the correct text decoration in Chrome, Edge, and Safari.\n*/\n\nabbr[title] {\n  -webkit-text-decoration: underline dotted;\n          text-decoration: underline dotted;\n}\n\n/**\nAdd the correct font weight in Edge and Safari.\n*/\n\nb,\nstrong {\n  font-weight: bolder;\n}\n\n/**\n1. Improve consistency of default fonts in all browsers. (https://github.com/sindresorhus/modern-normalize/issues/3)\n2. Correct the odd 'em' font sizing in all browsers.\n*/\n\ncode,\nkbd,\nsamp,\npre {\n  font-family:\n		ui-monospace,\n		SFMono-Regular,\n		Consolas,\n		'Liberation Mono',\n		Menlo,\n		monospace; /* 1 */\n  font-size: 1em; /* 2 */\n}\n\n/**\nAdd the correct font size in all browsers.\n*/\n\nsmall {\n  font-size: 80%;\n}\n\n/**\nPrevent 'sub' and 'sup' elements from affecting the line height in all browsers.\n*/\n\nsub,\nsup {\n  font-size: 75%;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline;\n}\n\nsub {\n  bottom: -0.25em;\n}\n\nsup {\n  top: -0.5em;\n}\n\n/*\nTabular data\n============\n*/\n\n/**\n1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)\n2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)\n*/\n\ntable {\n  text-indent: 0; /* 1 */\n  border-color: inherit; /* 2 */\n}\n\n/*\nForms\n=====\n*/\n\n/**\n1. Change the font styles in all browsers.\n2. Remove the margin in Firefox and Safari.\n*/\n\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: inherit; /* 1 */\n  font-size: 100%; /* 1 */\n  line-height: 1.15; /* 1 */\n  margin: 0; /* 2 */\n}\n\n/**\nRemove the inheritance of text transform in Edge and Firefox.\n1. Remove the inheritance of text transform in Firefox.\n*/\n\nbutton,\nselect { /* 1 */\n  text-transform: none;\n}\n\n/**\nCorrect the inability to style clickable types in iOS and Safari.\n*/\n\nbutton,\n[type='button'] {\n  -webkit-appearance: button;\n}\n\n/**\nRemove the inner border and padding in Firefox.\n*/\n\n/**\nRestore the focus styles unset by the previous rule.\n*/\n\n/**\nRemove the additional ':invalid' styles in Firefox.\nSee: https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737\n*/\n\n/**\nRemove the padding so developers are not caught out when they zero out 'fieldset' elements in all browsers.\n*/\n\nlegend {\n  padding: 0;\n}\n\n/**\nAdd the correct vertical alignment in Chrome and Firefox.\n*/\n\nprogress {\n  vertical-align: baseline;\n}\n\n/**\nCorrect the cursor style of increment and decrement buttons in Safari.\n*/\n\n/**\n1. Correct the odd appearance in Chrome and Safari.\n2. Correct the outline style in Safari.\n*/\n\n/**\nRemove the inner padding in Chrome and Safari on macOS.\n*/\n\n/**\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Change font properties to 'inherit' in Safari.\n*/\n\n/*\nInteractive\n===========\n*/\n\n/*\nAdd the correct display in Chrome and Safari.\n*/\n\nsummary {\n  display: list-item;\n}\n\n/**\n * Manually forked from SUIT CSS Base: https://github.com/suitcss/base\n * A thin layer on top of normalize.css that provides a starting point more\n * suitable for web applications.\n */\n\n/**\n * Removes the default spacing and border for appropriate elements.\n */\n\nblockquote,\ndl,\ndd,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6,\nhr,\nfigure,\np,\npre {\n  margin: 0;\n}\n\nbutton {\n  background-color: transparent;\n  background-image: none;\n}\n\n/**\n * Work around a Firefox/IE bug where the transparent `button` background\n * results in a loss of the default `button` focus styles.\n */\n\nbutton:focus {\n  outline: 1px dotted;\n  outline: 5px auto -webkit-focus-ring-color;\n}\n\nfieldset {\n  margin: 0;\n  padding: 0;\n}\n\nol,\nul {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n\n/**\n * Tailwind custom reset styles\n */\n\n/**\n * 1. Use the user's configured `sans` font-family (with Tailwind's default\n *    sans-serif font stack as a fallback) as a sane default.\n * 2. Use Tailwind's default \"normal\" line-height so the user isn't forced\n *    to override it to ensure consistency even when using the default theme.\n */\n\nhtml {\n  font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, \"Noto Sans\", sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"; /* 1 */\n  line-height: 1.5; /* 2 */\n}\n\n/**\n * Inherit font-family and line-height from `html` so users can set them as\n * a class directly on the `html` element.\n */\n\nbody {\n  font-family: inherit;\n  line-height: inherit;\n}\n\n/**\n * 1. Prevent padding and border from affecting element width.\n *\n *    We used to set this in the html element and inherit from\n *    the parent element for everything else. This caused issues\n *    in shadow-dom-enhanced elements like <details> where the content\n *    is wrapped by a div with box-sizing set to `content-box`.\n *\n *    https://github.com/mozdevs/cssremedy/issues/4\n *\n *\n * 2. Allow adding a border to an element by just adding a border-width.\n *\n *    By default, the way the browser specifies that an element should have no\n *    border is by setting it's border-style to `none` in the user-agent\n *    stylesheet.\n *\n *    In order to easily add borders to elements by just setting the `border-width`\n *    property, we change the default border-style for all elements to `solid`, and\n *    use border-width to hide them instead. This way our `border` utilities only\n *    need to set the `border-width` property instead of the entire `border`\n *    shorthand, making our border utilities much more straightforward to compose.\n *\n *    https://github.com/tailwindcss/tailwindcss/pull/116\n */\n\n*,\n::before,\n::after {\n  box-sizing: border-box; /* 1 */\n  border-width: 0; /* 2 */\n  border-style: solid; /* 2 */\n  border-color: #e5e7eb; /* 2 */\n}\n\n/*\n * Ensure horizontal rules are visible by default\n */\n\nhr {\n  border-top-width: 1px;\n}\n\n/**\n * Undo the `border-style: none` reset that Normalize applies to images so that\n * our `border-{width}` utilities have the expected effect.\n *\n * The Normalize reset is unnecessary for us since we default the border-width\n * to 0 on all elements.\n *\n * https://github.com/tailwindcss/tailwindcss/issues/362\n */\n\nimg {\n  border-style: solid;\n}\n\ntextarea {\n  resize: vertical;\n}\n\ninput::-moz-placeholder, textarea::-moz-placeholder {\n  opacity: 1;\n  color: #9ca3af;\n}\n\ninput:-ms-input-placeholder, textarea:-ms-input-placeholder {\n  opacity: 1;\n  color: #9ca3af;\n}\n\ninput::placeholder,\ntextarea::placeholder {\n  opacity: 1;\n  color: #9ca3af;\n}\n\nbutton {\n  cursor: pointer;\n}\n\ntable {\n  border-collapse: collapse;\n}\n\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  font-size: inherit;\n  font-weight: inherit;\n}\n\n/**\n * Reset links to optimize for opt-in styling instead of\n * opt-out.\n */\n\na {\n  color: inherit;\n  text-decoration: inherit;\n}\n\n/**\n * Reset form element properties that are easy to forget to\n * style explicitly so you don't inadvertently introduce\n * styles that deviate from your design system. These styles\n * supplement a partial reset that is already applied by\n * normalize.css.\n */\n\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  padding: 0;\n  line-height: inherit;\n  color: inherit;\n}\n\n/**\n * Use the configured 'mono' font family for elements that\n * are expected to be rendered with a monospace font, falling\n * back to the system monospace stack if there is no configured\n * 'mono' font family.\n */\n\npre,\ncode,\nkbd,\nsamp {\n  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace;\n}\n\n/**\n * Make replaced elements `display: block` by default as that's\n * the behavior you want almost all of the time. Inspired by\n * CSS Remedy, with `svg` added as well.\n *\n * https://github.com/mozdevs/cssremedy/issues/14\n */\n\nimg,\nsvg,\nvideo,\ncanvas,\naudio,\niframe,\nembed,\nobject {\n  display: block;\n  vertical-align: middle;\n}\n\n/**\n * Constrain images and videos to the parent width and preserve\n * their intrinsic aspect ratio.\n *\n * https://github.com/mozdevs/cssremedy/issues/14\n */\n\nimg,\nvideo {\n  max-width: 100%;\n  height: auto;\n}\n\n.table {\n  display: table;\n}\n\n* {\n  --tw-shadow: 0 0 #0000;\n}\n\n* {\n  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);\n  --tw-ring-offset-width: 0px;\n  --tw-ring-offset-color: #fff;\n  --tw-ring-color: rgba(59, 130, 246, 0.5);\n  --tw-ring-offset-shadow: 0 0 #0000;\n  --tw-ring-shadow: 0 0 #0000;\n}\n\n@-webkit-keyframes spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n@keyframes spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n@-webkit-keyframes ping {\n  75%, 100% {\n    transform: scale(2);\n    opacity: 0;\n  }\n}\n\n@keyframes ping {\n  75%, 100% {\n    transform: scale(2);\n    opacity: 0;\n  }\n}\n\n@-webkit-keyframes pulse {\n  50% {\n    opacity: .5;\n  }\n}\n\n@keyframes pulse {\n  50% {\n    opacity: .5;\n  }\n}\n\n@-webkit-keyframes bounce {\n  0%, 100% {\n    transform: translateY(-25%);\n    -webkit-animation-timing-function: cubic-bezier(0.8,0,1,1);\n            animation-timing-function: cubic-bezier(0.8,0,1,1);\n  }\n\n  50% {\n    transform: none;\n    -webkit-animation-timing-function: cubic-bezier(0,0,0.2,1);\n            animation-timing-function: cubic-bezier(0,0,0.2,1);\n  }\n}\n\n@keyframes bounce {\n  0%, 100% {\n    transform: translateY(-25%);\n    -webkit-animation-timing-function: cubic-bezier(0.8,0,1,1);\n            animation-timing-function: cubic-bezier(0.8,0,1,1);\n  }\n\n  50% {\n    transform: none;\n    -webkit-animation-timing-function: cubic-bezier(0,0,0.2,1);\n            animation-timing-function: cubic-bezier(0,0,0.2,1);\n  }\n}\n\n@media (min-width: 640px) {\n}\n\n@media (min-width: 768px) {\n}\n\n@media (min-width: 1024px) {\n}\n\n@media (min-width: 1280px) {\n}\n\n@media (min-width: 1536px) {\n}";
const css = {
  code: "@tailwind base;@tailwind components;@tailwind utilities;",
  map: `{"version":3,"file":"$layout.svelte","sources":["$layout.svelte"],"sourcesContent":["<script>\\n\\timport '../app.css';\\n</script>\\n\\n<main>\\n\\t<slot />\\n</main>\\n\\n<style global lang=\\"postcss\\">\\n\\t@tailwind base;\\n\\t@tailwind components;\\n\\t@tailwind utilities;\\n</style>\\n"],"names":[],"mappings":"AASC,UAAU,IAAI,CAAC,AACf,UAAU,UAAU,CAAC,AACrB,UAAU,SAAS,CAAC"}`
};
const $layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<main>${slots.default ? slots.default({}) : ``}
</main>`;
});
var $layout$1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  [Symbol.toStringTag]: "Module",
  default: $layout
});
export {init, render};
