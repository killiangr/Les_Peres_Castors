import * as layout from "..\\..\\..\\src\\routes\\$layout.svelte";

const components = [
	() => import("..\\..\\..\\src\\routes\\index.svelte"),
	() => import("..\\..\\..\\src\\routes\\quizzquestions.svelte"),
	() => import("..\\..\\..\\src\\routes\\formationgen.svelte"),
	() => import("..\\..\\..\\src\\routes\\informatique.svelte"),
	() => import("..\\..\\..\\src\\routes\\biologie.svelte"),
	() => import("..\\..\\..\\src\\routes\\physique.svelte"),
	() => import("..\\..\\..\\src\\routes\\annales.svelte"),
	() => import("..\\..\\..\\src\\routes\\contact.svelte"),
	() => import("..\\..\\..\\src\\routes\\fiches.svelte"),
	() => import("..\\..\\..\\src\\routes\\forum.svelte"),
	() => import("..\\..\\..\\src\\routes\\maths.svelte"),
	() => import("..\\..\\..\\src\\routes\\quizz.svelte")
];

const d = decodeURIComponent;
const empty = () => ({});

export const routes = [
	// src/routes/index.svelte
[/^\/$/, [components[0]]],

// src/routes/quizzquestions.svelte
[/^\/quizzquestions\/?$/, [components[1]]],

// src/routes/formationgen.svelte
[/^\/formationgen\/?$/, [components[2]]],

// src/routes/informatique.svelte
[/^\/informatique\/?$/, [components[3]]],

// src/routes/biologie.svelte
[/^\/biologie\/?$/, [components[4]]],

// src/routes/physique.svelte
[/^\/physique\/?$/, [components[5]]],

// src/routes/annales.svelte
[/^\/annales\/?$/, [components[6]]],

// src/routes/contact.svelte
[/^\/contact\/?$/, [components[7]]],

// src/routes/fiches.svelte
[/^\/fiches\/?$/, [components[8]]],

// src/routes/forum.svelte
[/^\/forum\/?$/, [components[9]]],

// src/routes/maths.svelte
[/^\/maths\/?$/, [components[10]]],

// src/routes/quizz.svelte
[/^\/quizz\/?$/, [components[11]]]
];

export { layout };