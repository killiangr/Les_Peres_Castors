<script>
	import Header from '../lib/Header.svelte';
</script>

<head>
	<title>LPC Annales</title>
</head>

<Header />
<section class="min-h-screen">
	<div class="z-10 relative bg-white">
		<iframe
			class="relative min-h-screen"
			title="Gestionnaire Annales"
			width="100%"
			height="100%"
			src="https://team-rcv.xyz/lpc/fichiers/"
		/>
	</div>
</section>
