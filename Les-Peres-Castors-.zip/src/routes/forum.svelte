<script>
	import Header from "../lib/Header.svelte"
</script>

<head>
	<title>LPC Forum</title>
</head>
<Header />
Ici, le forum