<script>
    import Header from '../lib/Header.svelte';
</script>

<head>
	<title>LPC Quizz FormationG</title>
</head>

<Header/>
<div class="flex flex-col text-center w-full mb-5">
	<h3 class="text-xl text-base font-semibold tracking-wide no-underline mb-5">
		Les quizzs de formation générale
	</h3>
</div>